﻿--[[Command: Saldo ]]

Moedas = {}

MOEDACOMMAND = "/saldo"
local MOEDAS_SWITCH = 1

function CommandMoedas(aIndex)
	if MOEDAS_SWITCH == 0
	then
		return
	end
	
	local player = User.new(aIndex)
	local nome = player:getName()
	local acc = player:getAccountID()
	
	local Cashs = DataBase.GetValue("MEMB_INFO", "cash", "memb___id", acc)
	local Cashs = DataBase.GetValue("MEMB_INFO", "gold", "memb___id", acc)
	local HorasOnline = DataBase.GetValue("MEMB_INFO", "HorasOn", "memb___id", acc)
	
	SendMessage(string.format("Voce possui: (%d) Cash's", Cashs), aIndex, 1)
	SendMessage(string.format("Voce possui: (%d) Gold's", Cashs), aIndex, 1)
	SendMessage(string.format("Voce ja jogou o servidor por: (%d) horas.", HorasOnline), aIndex, 1)
	
end

Commands.Register(MOEDACOMMAND, CommandMoedas)

return Moedas