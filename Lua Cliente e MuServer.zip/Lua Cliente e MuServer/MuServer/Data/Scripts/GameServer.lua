--[[
declare global var
--]]

command = Command.new()

--[[
Initial System
]]--
OpenExtension('LuaSystem')
OpenExtension('Utils')
OpenExtension('Configs\\Commands')
OpenExtension('Configs')
OpenExtension('Shop\\ShopConfig')
OpenExtension('Shop\\Shop')
OpenExtension('Character')
OpenExtension('Systems')
OpenExtension('Commands')
OpenProtectExtension('PCustoms')


function GameServer()
	LogAddC(1,"Lua Carregado com sucesso!")
	
	DataBase.Connect(3, "MuOnline", "sa", ";7#7hE3m8B3u")
end