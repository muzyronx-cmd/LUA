Shop = {}

function Shop.Init()
    if Shop_Config.Enabled then
        GameServerFunctions.GameServerProtocol(Shop.Protocol)

        Timer.TimeOut(2, Shop.CreateLog)
    end
end

function Shop.CreateLog()
	CreateDirectory("LOGS\\SHOP_LOG")
end

function Shop.Checkout(aIndex, playerInfo, CoinID, TotalPrice, ItemList)
    local PacketName = string.format("4-%s-%d", playerInfo[1], aIndex)
    CreatePacket(PacketName, Shop_Config.Packet)
    local checkoutReturn = 3
    if Shop_Config.Coins[CoinID] == nil then
        checkoutReturn = 2
    else
        local coin = Shop_Config.Coins[CoinID]
        local saldo = DataBase.GetValue(coin.Table, coin.Column, coin.Where, playerInfo[coin.IdType])

        if saldo < TotalPrice then
            checkoutReturn = 2
            goto fim
        end

        local codigo = GuardiaoBrindes.GerarCodigo()
        if codigo == "-1" then
            checkoutReturn = 4
            goto fim
        end

        GuardiaoBrindes.RegistrarCodigo(Shop_Config.Message[playerInfo[3]][1], playerInfo[0], codigo, 0, 0)
        GuardiaoBrindes.RegistrarItens(codigo, ItemList)

        Timer.TimeOut(1, Shop.AddLog, playerInfo, ItemList, codigo)

        DataBaseAsync.SetDecreaseValue(coin.Table, coin.Column, TotalPrice, coin.Where, playerInfo[coin.IdType])
    
        checkoutReturn = 3
    end

    ::fim::
    SetBytePacket(PacketName, checkoutReturn)
    SendPacket(PacketName, aIndex)
    ClearPacket(PacketName)
end

function Shop.AddLog(playerInfo, Itens, codigo)
    local dia = os.date("%Y-%m-%d")
	local hora = os.date("%H:%M:%S")
	local file = io.open(string.format("LOGS\\SHOP_LOG\\%s.txt", dia), 'a')
	file:write(string.format("\n%s [%s][%s] Codigo de compra: %s", hora, playerInfo[0], playerInfo[1], codigo))
	
	for i in ipairs (Itens) do
		file:write(string.format("\n	Nome: %s, Section: %d, Index: %d, Level: %d, Skill: %d, Luck: %d, JoL: %d, Exc: %d", Itens[i].Nome, Itens[i].Section, Itens[i].Id, Itens[i].Level, Itens[i].Skill, Itens[i].Luck, Itens[i].Opt, Itens[i].Excelente))
	end
	
	file:write(string.format("\n"))
	file:close()
end

function Shop.Protocol(aIndex, Packet, PacketName)
    if Packet ~= Shop_Config.Packet then return false end

    LUA_BUSY = true

    local player = User.new(aIndex)
    local playerInfo = Utils.GetPlayerInfo(player)

    if PacketName == string.format("1-%s-%d", playerInfo[1], aIndex) then
        ClearPacket(PacketName)
        local map = player:getMapNumber()
		local x = player:getX()
		local y = player:getY()
		local atr = GetMapAttr(map, x, y, 1)
        local tp = 0
		if atr == 0 then
			tp = 1
		end

        local packetName = string.format("2-%s-%d", playerInfo[1], aIndex)
        CreatePacket(packetName, Shop_Config.Packet)
        SetBytePacket(packetName, tp)
        SendPacket(packetName, aIndex)
        ClearPacket(packetName)
        LUA_BUSY = false
        return true
    end

    

    if PacketName == string.format("3-%s-%d", playerInfo[1], aIndex) then
        local itemList = {}
        local coin = GetBytePacket(PacketName, -1)
        local price = GetDwordPacket(PacketName, -1)
        local qtd = GetBytePacket(PacketName, -1)

        for x = 1, qtd do
            local len = GetBytePacket(PacketName, -1)
            local name = GetCharPacketLength(PacketName, -1, len)
            local section = GetBytePacket(PacketName, -1)
            local index = GetWordPacket(PacketName, -1)
            local level = GetBytePacket(PacketName, -1)
            local skill = GetBytePacket(PacketName, -1)
            local luck = GetBytePacket(PacketName, -1)
            local option = GetBytePacket(PacketName, -1)
            local exc = 0
            local excCount = 1
            for z = 1, 6 do
                local temp = GetBytePacket(PacketName, -1)
                if temp == 1 then
                    exc = exc + excCount
                end
                excCount = excCount*2
            end

            local dur = 255
            if section == 15 and index == 39 then
                dur = 0
            end

            if section == 14 then
                if index == 208 or index == 207 or index == 206 or index == 203 then
                    dur = 0
                end
            end

            local item = {Nome = name, Section = section, Id = index, Level = level, Durabilidade = dur, Skill = skill, Luck = luck, Opt = option, Excelente = exc, Dias = 0}
            table.insert(itemList, item)
        end

        ClearPacket(PacketName)
        Shop.Checkout(aIndex, playerInfo, coin, price, itemList)
        LUA_BUSY = false
        return true
    end
end

Shop.Init()

return Shop