-- BootSystem v2: recupera personagens pelo GameServer, inclusive apos reload completo.
-- Configuracao em Scripts/Configs/BootSystemConfig.lua.
-- Invalida callbacks da versao anterior quando o reload preserva globais.
if type(BootSystemState) == "table" then BootSystemState.generation = {} end
local previous = BootSystemRuntime
local baseTimer = TimerSystem
if previous and baseTimer == previous.wrapper then baseTimer = previous.baseTimer end
local runtime = {baseTimer = baseTimer}
BootSystemRuntime = runtime
local system = {}
BootSystem = system

local function active()
    return BootSystemRuntime == runtime and BOOT_SYSTEM_SWITCH == 1
end
local function key(value)
    if type(value) ~= "string" then return "" end
    return (value:gsub("%z.*", ""):gsub("%s+$", "")):lower()
end
local function log(message)
    LogAddC(2, "[BootSystem] " .. message)
end
local function positive(value, default)
    if type(value) == "number" and value >= 1 then return math.floor(value) end
    return default
end
local options = BOOT_SYSTEM_CONFIG or {}
local retrySeconds = positive(options.ReconnectSeconds, 30)
local timeoutSeconds = positive(options.LoginTimeoutSeconds, 30)
local delaySeconds = positive(options.CharacterDelaySeconds, 2)
local summarySeconds = positive(options.SummarySeconds, 60)
local records, byAccount = {}, {}
for _, config in ipairs(InjectPlayers or {}) do
    local account = type(config) == "table" and key(config.Account) or ""
    local name = type(config) == "table" and key(config.Character) or ""
    if account == "" or name == "" or type(config.Password) ~= "string" then
        log("Entrada invalida na configuracao; ignorada.")
    elseif byAccount[account] then
        log("Conta repetida para " .. config.Character .. "; entrada ignorada.")
    else
        local record = {config = config, account = account, name = name, retryAt = 0}
        records[#records + 1] = record
        byAccount[account] = record
    end
end
local function note(record, message, now)
    if record.message ~= message or now >= (record.messageAt or 0) + summarySeconds then
        log(record.config.Character .. ": " .. message)
        record.message, record.messageAt = message, now
    end
end
local function pulse(player)
    local tick = GetTick()
    player:setCheckSumTime(tick)
    player:setConnectCheckTime(tick)
end
local function release(record, now)
    record.index, record.phase, record.sent = nil, nil, nil
    record.retryAt = now + retrySeconds
end
local function attach(record, row, now)
    if record.index ~= row.index or record.phase == nil then
        record.index, record.phase, record.sent = row.index, "login", false
        record.deadline, record.characterAt = now + timeoutSeconds, now + delaySeconds
    end
end
local function snapshot()
    local accounts, slots = {}, {}
    for index = OBJECT_START_USER, MAX_OBJECT do
        local player = User.new(index)
        if player:getConnected() ~= 0 then
            local row = {index = index, player = player, account = key(player:getAccountID()),
                name = key(player:getName()), connected = player:getConnected()}
            slots[index] = row
            if byAccount[row.account] then
                accounts[row.account] = accounts[row.account] or {}
                table.insert(accounts[row.account], row)
            end
        end
    end
    return accounts, slots
end
local function process(record, rows, slots, now)
    local row = rows and rows[1]
    if rows then
        for _, candidate in ipairs(rows) do
            if candidate.name == record.name then row = candidate; break end
        end
    end
    if row then
        if row.name ~= "" and row.name ~= record.name then
            record.index, record.phase = nil, "occupied"
            note(record, "conta ocupada por outro personagem; aguardando.", now)
            return
        end
        attach(record, row, now)
        pulse(row.player)
        if row.name == record.name and gObjIsConnectedGP(row.index) ~= 0 then
            if record.phase ~= "online" then note(record, "online; conexao recuperada.", now) end
            record.phase = "online"
            return
        end
        if record.phase == "online" then
            record.phase, record.sent = "login", row.name ~= ""
            record.deadline, record.characterAt = now + timeoutSeconds, now + delaySeconds
        end
        if now >= record.deadline then
            -- So encerra login incompleto de uma conta configurada, nunca outro personagem.
            local player = User.new(row.index)
            if key(player:getAccountID()) == record.account
                and (key(player:getName()) == "" or key(player:getName()) == record.name)
                and gObjIsConnectedGP(row.index) == 0 then
                gObjDel(row.index)
            end
            release(record, now)
            note(record, "login expirou; nova tentativa apos o intervalo configurado.", now)
        elseif row.connected == 2 and not record.sent
            and now >= record.characterAt then
            record.sent = true
            CharacterInfoSend(row.index, record.config.Character, record.config.Account)
        end
        return
    end
    if record.index then
        local pending = slots[record.index]
        if record.phase == "login" and pending and pending.account == "" then
            -- Slot reservado por nos, ainda sem resposta do JoinServer.
            if now < record.deadline then
                pulse(pending.player)
            else
                note(record, "slot sem resposta de autenticacao; aguardando liberacao pelo servidor.", now)
            end
            return
        end
        release(record, now)
        note(record, "conexao caiu; reconexao agendada.", now)
    end
end
local cursor, nextSummary = 1, 0
function system.Checking()
    if not active() then return end
    local now = os.time()
    local accounts, slots = snapshot()
    local loginPending = false
    for _, record in ipairs(records) do
        local ok = pcall(process, record, accounts[record.account], slots, now)
        if not ok then
            -- Nao imprime a excecao: APIs podem incluir credenciais em suas mensagens.
            note(record, "falha ao atualizar; confira as APIs do GameServer. Demais bots continuam.", now)
            record.retryAt = now + retrySeconds
        end
        if record.phase == "login" and record.deadline and now < record.deadline then
            loginPending = true
        end
    end
    -- Autentica uma conta por vez para nao disparar todos os logins juntos.
    if not loginPending then
        for offset = 0, #records - 1 do
            local position = ((cursor + offset - 1) % #records) + 1
            local record = records[position]
            if not record.index and not accounts[record.account] and now >= record.retryAt then
                cursor = position % #records + 1
                record.retryAt = now + retrySeconds
                local ok = pcall(function()
                    local index = SearchIndex(0, "127.0.0.1")
                    if type(index) ~= "number" or index < OBJECT_START_USER or index > MAX_OBJECT then
                        note(record, "sem slot livre; aguardando.", now)
                        return
                    end
                    record.index, record.phase, record.sent = index, "login", false
                    record.deadline, record.characterAt = now + timeoutSeconds, now + delaySeconds
                    gObjAdd(0, "127.0.0.1", index)
                    local player = User.new(index)
                    player:setLoginMessageSend(1)
                    player:setLoginMessageCount(1)
                    pulse(player)
                    AccountInfoSend(index, record.config.Account, record.config.Password)
                    note(record, "autenticando.", now)
                end)
                if not ok then note(record, "falha ao iniciar login; confira as APIs do GameServer.", now) end
                break
            end
        end
    end
    if now >= nextSummary then
        local online = 0
        for _, record in ipairs(records) do
            if record.phase == "online" then online = online + 1 end
        end
        log(string.format("Online: %d/%d. Recuperacao automatica ativa.", online, #records))
        nextSummary = now + summarySeconds
    end
end
function system.IsBoot(index)
    if not active() then return -1 end
    local player = User.new(index)
    local record = byAccount[key(player:getAccountID())]
    if record and key(player:getName()) == record.name and gObjIsConnectedGP(index) ~= 0 then
        return 1
    end
    return -1
end
function system.CharacterMove(index, map, x, y)
    if system.IsBoot(index) ~= 1 then return end
    local player = User.new(index)
    player:setX(x)
    player:setTX(x)
    player:setY(y)
    player:setTY(y)
    player:setMapNumber(map)
    player:setTeleport(0)
    player:setPathCount(0)
    player:setRegenMapNumber(map)
    player:setRegenMapX(x)
    player:setRegenMapY(y)
    player:setRegenTime(0)
    ViewportCreate(index)
    return 1
end
local function guardedCheck()
    if not active() then return end
    local ok = pcall(system.Checking)
    if not ok then
        local now = os.time()
        if now >= (runtime.errorAt or 0) then
            log("Falha na varredura; confira User/GetTick e limites de objetos do GameServer.")
            runtime.errorAt = now + summarySeconds
        end
    end
end
-- TimerSystem e chamado pelo GameServer a cada segundo. Executa antes dos
-- timers comuns: erro em outro callback nao interrompe o keepalive dos bots.
if type(baseTimer) == "function" then
    runtime.wrapper = function(...)
        guardedCheck()
        return baseTimer(...)
    end
    TimerSystem = runtime.wrapper
    GameServerFunctions.CharacterMove(system.CharacterMove)
    log("v2 carregada. Recuperando a lista diretamente do GameServer.")
    guardedCheck()
else
    log("ERRO: TimerSystem nao carregado. Confira a ordem LuaSystem antes de Systems.")
end
return system
