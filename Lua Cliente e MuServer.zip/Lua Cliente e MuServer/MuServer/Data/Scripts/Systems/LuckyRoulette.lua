LuckyRoulette = {}
local R, C = LuckyRoulette, LuckyRouletteConfig
local sessions, serial = {}, 0
local function log(message) LogAddC(2,'[LuckyRoulette] '..message) end
local function debug(message) if C.Debug then log(message) end end
if not C then
    log('ERRO: carregue Configs/LuckyRoulette.lua antes de Systems/LuckyRoulette.lua.')
    return R
end
local function quote(s) return "'"..tostring(s):gsub("'", "''").."'" end
local function ident(s)
    assert(type(s)=="string" and s:match("^[%a_][%w_]*$"), "Identificador SQL invalido")
    return "["..s.."]"
end
local function integer(n, max) return type(n)=="number" and n==math.floor(n) and n>=0 and n<=max end
function R.Validate()
    local n=assert(C.NPC,'Configure NPC em Configs/LuckyRoulette.lua')
    assert(integer(n.Class,65535),'NPC.Class deve ser o numero do Monster.txt')
    assert(integer(n.Map,255) and integer(n.X,255) and integer(n.Y,255),'Configure NPC.Map, X e Y')
    n.Distance=n.Distance or 5
    n.PositionTolerance=n.PositionTolerance or 2
    assert(integer(n.Distance,10) and n.Distance>0,'NPC.Distance deve ser de 1 a 10')
    assert(integer(n.PositionTolerance,10),'NPC.PositionTolerance deve ser de 0 a 10')
    assert(#C.Roulettes>0 and #C.Roulettes<=32)
    local ids={}
    for _,r in ipairs(C.Roulettes) do
        assert(integer(r.ID,255) and r.ID>0 and not ids[r.ID]); ids[r.ID]=true
        assert(#r.Name<=64 and integer(r.Price,2147483647) and integer(r.Cooldown,31536000))
        local c=assert(C.Currency[r.Currency]); ident(c.Table); ident(c.Column); ident(c.Key)
        assert(#c.Name<=32 and #r.Items>0 and #r.Items<=64)
        local total=0
        for i,p in ipairs(r.Items) do
            local label='Roleta '..r.ID..', premio '..i..': '
            if p.Section~=nil or p.Index~=nil then
                assert(integer(p.Section,15),label..'Section (categoria) deve ser de 0 a 15')
                assert(integer(p.Index,511),label..'Index deve ser de 0 a 511')
                p.Item=p.Section*512+p.Index
            end
            p.Weight=p.Weight or 1
            assert(type(p.Name)=='string' and #p.Name<=64 and integer(p.Item,8191),label..'configure Name, Section e Index')
            assert(integer(p.Weight,1000000) and p.Weight>0,label..'Weight deve ser positivo')
            for _,k in ipairs({'Level','Durability','Skill','Luck','Option','Excellent'}) do
                if p[k]==nil then p[k]=k=='Durability' and 255 or 0 end
                assert(integer(p[k],255),label..k..' invalido')
            end
            total=total+p.Weight
        end
        r.TotalWeight=total
    end
end
local function query(sql, fields)
    local d=DataBase.getDb()
    if d:exec(sql)==0 then d:clear(); return nil,false end
    if d:fetch()==100 then d:clear(); return nil,true end
    local row={}
    for _,k in ipairs(fields) do row[k]=k=='PrizeName' and d:getStr(k) or d:getInt(k) end
    d:clear(); return row,true
end
local fields={'ID','Roulette','Prize','PrizeName','Item','Level','Durability','Skill','Luck','Opt','Excellent'}
function R.Pending(p)
    return query('SELECT TOP 1 * FROM dbo.LuckyRouletteReward WHERE Account='..quote(p:getAccountID())..' AND State=0 ORDER BY ID',fields)
end
local function str(n,s) SetBytePacket(n,#s); SetCharPacketLength(n,s,#s) end
local function itemData(n,v)
    SetWordPacket(n,v.Item); SetBytePacket(n,v.Level)
    SetBytePacket(n,v.Durability); SetBytePacket(n,v.Skill); SetBytePacket(n,v.Luck)
    SetBytePacket(n,v.Option or v.Opt or 0); SetBytePacket(n,v.Excellent)
end
local function packet(p,kind,write)
    local n='LR-'..p:getName(); CreatePacket(n,C.Packet); SetBytePacket(n,kind)
    write(n); SendPacket(n,p:getIndex()); ClearPacket(n)
end
local function token(s) serial=serial%2147483646+1; s.Token=serial end
function R.Status(p,message,result,readOK)
    local s=sessions[p:getIndex()]; if not s then return end
    packet(p,3,function(n)
        SetDwordPacket(n,s.Token); str(n,message or '')
        SetBytePacket(n,result and 1 or 0)
        if result then SetBytePacket(n,result.Roulette); SetBytePacket(n,result.Prize); str(n,result.PrizeName); itemData(n,result) end
        SetBytePacket(n,readOK==false and 1 or 0)
    end)
end
local function near(p,n)
    return p:getMapNumber()==n:getMapNumber() and math.abs(p:getX()-n:getX())<=C.NPC.Distance and math.abs(p:getY()-n:getY())<=C.NPC.Distance
end
local function npc(n)
    local c=C.NPC
    return n:getConnected()>0 and n:getClass()==c.Class and n:getMapNumber()==c.Map
        and math.abs(n:getX()-c.X)<=c.PositionTolerance and math.abs(n:getY()-c.Y)<=c.PositionTolerance
end
local lastNPCCount
function R.PrepareNPC()
    local count,candidate=0,nil
    -- Same object range and setType(3) used by the repository's GiroDaSorte.
    for i=0,12000 do
        local n=User.new(i)
        if npc(n) then
            n:setType(3)
            count=count+1
        elseif not candidate and n:getConnected()>0 and n:getClass()==C.NPC.Class then
            candidate=string.format(' Classe encontrada em Map=%d X=%d Y=%d.',n:getMapNumber(),n:getX(),n:getY())
        end
    end
    if count~=lastNPCCount then
        if count>0 then
            log(string.format('NPC habilitado: Class=%d Map=%d X=%d Y=%d; encontrados=%d.',C.NPC.Class,C.NPC.Map,C.NPC.X,C.NPC.Y,count))
        else
            log('NPC nao encontrado. Confira MonsterSetBase, Class, Map, X e Y.'..(candidate or ''))
        end
        lastNPCCount=count
    end
end
function R.NpcTalk(ni,pi)
    local n,p=User.new(ni),User.new(pi)
    if not npc(n) then return 0 end
    if not near(p,n) then return 1 end
    local old=sessions[pi]
    if old and os.time()-old.Opened<2 then return 1 end
    local s={NPC=ni,Account=p:getAccountID(),Name=p:getName(),Opened=os.time(),LastSeen=os.time()}; token(s); sessions[pi]=s
    debug('Clique recebido; enviando janela para '..p:getName()..'.')
    packet(p,1,function(name) SetBytePacket(name,#C.Roulettes) end)
    for _,r in ipairs(C.Roulettes) do
        packet(p,2,function(name)
            SetBytePacket(name,r.ID); str(name,r.Name); str(name,C.Currency[r.Currency].Name)
            SetDwordPacket(name,r.Price); SetBytePacket(name,#r.Items)
            for _,v in ipairs(r.Items) do str(name,v.Name); itemData(name,v) end
        end)
    end
    R.Status(p,'Escolha sua roleta.',R.Pending(p))
    Timer.TimeOut(5,function()
        if sessions[pi]~=s or s.ClientReady then return end
        local player=User.new(pi)
        if player:getConnected()<3 or player:getAccountID()~=s.Account or player:getName()~=s.Name then return end
        log('Janela enviada, mas o cliente nao confirmou o desenho. Confira o Lua do cliente e pacote '..C.Packet..'.')
        ChatTargetSend(ni,'Roleta enviada. Confira a atualizacao Lua do cliente.',pi)
    end)
    return 1
end
function R.Draw(r)
    local value=GetRand(1,r.TotalWeight)
    for i,p in ipairs(r.Items) do value=value-p.Weight; if value<=0 then return i,p end end
end
function R.Spin(p,r)
    local pending,readOK=R.Pending(p)
    if not readOK then return R.Status(p,'Banco indisponivel. Use ATUALIZAR.',nil,false) end
    if pending then return R.Status(p,'Resgate seu premio pendente.',pending) end
    local i,v=R.Draw(r); local c=C.Currency[r.Currency]
    local account=quote(p:getAccountID()); local key=quote(c.Character and p:getName() or p:getAccountID())
    -- The account lock serializes all roulette currencies and GameServers.
    local sql="SET NOCOUNT ON; SET XACT_ABORT ON; BEGIN TRY BEGIN TRAN; DECLARE @l int; EXEC @l=sys.sp_getapplock @Resource="..quote('LuckyRoulette:'..p:getAccountID())..", @LockMode='Exclusive', @LockOwner='Transaction', @LockTimeout=3000; IF @l<0 RAISERROR('lock',16,1); "
    sql=sql.."IF EXISTS(SELECT 1 FROM dbo.LuckyRouletteReward WHERE Account="..account.." AND (State=0 OR (Roulette="..r.ID.." AND CreatedAt>DATEADD(second,-"..r.Cooldown..",GETUTCDATE())))) BEGIN ROLLBACK; SELECT -2 AS Result; RETURN; END; "
    if r.Price>0 then
        sql=sql..'UPDATE '..ident(c.Table)..' SET '..ident(c.Column)..'='..ident(c.Column)..'-'..r.Price..' WHERE '..ident(c.Key)..'='..key..' AND '..ident(c.Column)..'>='..r.Price..'; IF @@ROWCOUNT<>1 BEGIN ROLLBACK; SELECT -3 AS Result; RETURN; END; '
    end
    sql=sql..'INSERT dbo.LuckyRouletteReward(Account,Character,Roulette,Prize,PrizeName,Item,Level,Durability,Skill,Luck,Opt,Excellent) VALUES('..account..','..quote(p:getName())..','..r.ID..','..i..','..quote(v.Name)..','..v.Item..','..v.Level..','..v.Durability..','..v.Skill..','..v.Luck..','..v.Option..','..v.Excellent..'); COMMIT; SELECT 1 AS Result; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; SELECT -1 AS Result; END CATCH;'
    local result=query(sql,{'Result'})
    local message='Banco indisponivel. Aguarde e use ATUALIZAR.'
    if result then message=({[1]='Premio sorteado!',[-2]='Aguarde o intervalo ou resgate seu premio.',[-3]='Saldo insuficiente.'})[result.Result] or message end
    local pending,readOK=R.Pending(p)
    R.Status(p,message,pending,result~=nil and result.Result~=-1 and readOK)
end
function R.Claim(p)
    local v,readOK=R.Pending(p)
    if not readOK then return R.Status(p,'Banco indisponivel. Use ATUALIZAR.',nil,false) end
    if not v then return R.Status(p,'Nenhum premio pendente.') end
    if InventoryCheckSpaceByItem(p:getIndex(),v.Item)~=1 then return R.Status(p,'Libere espaco no inventario.',v) end
    local q=query('SET NOCOUNT ON; UPDATE dbo.LuckyRouletteReward SET State=1,ClaimAt=GETUTCDATE() OUTPUT inserted.ID WHERE ID='..v.ID..' AND State=0',{'ID'})
    if not q then return R.Status(p,'Nao foi possivel reservar o resgate.',R.Pending(p)) end
    -- Native API has no documented delivery acknowledgement: never auto-retry this call.
    LogAddC(2,'[LuckyRoulette] Entrega solicitada ID='..v.ID)
    local ok=pcall(ItemSerialCreateComplete,p:getIndex(),236,0,0,v.Item,v.Level,v.Durability,v.Skill,v.Luck,v.Opt,p:getIndex(),v.Excellent,0,0)
    R.Status(p,ok and 'Entrega solicitada. Confira seu inventario.' or 'Falha na entrega. Informe o administrador: '..v.ID)
end
function R.Protocol(index,id,name)
    if id~=C.Packet then return false end
    local p=User.new(index)
    if name~='LRQ-'..p:getName() then ClearPacket(name); return true end
    local action,t,rid=GetBytePacket(name,-1),GetDwordPacket(name,-1),GetBytePacket(name,-1)
    ClearPacket(name)
    local s=sessions[index]
    if p:getConnected()<3 then return true end
    if not s or s.Account~=p:getAccountID() or s.Name~=p:getName() then
        packet(p,4,function() end)
        return true
    end
    -- A delayed close from an older window must not discard the new session.
    if action==0 then
        if t==s.Token then sessions[index]=nil end
        return true
    end
    local n=User.new(s.NPC)
    if os.time()-s.LastSeen>600 or not npc(n) or not near(p,n) then
        sessions[index]=nil
        packet(p,4,function() end)
        ChatTargetSend(s.NPC,'Roleta fechada: aproxime-se do NPC para abrir novamente.',index)
        return true
    end
    -- Recover a lost response/stale token by reading the authoritative pending reward.
    -- This path cannot charge currency, roll a prize or deliver an item.
    if action==4 or t~=s.Token then
        s.LastSeen=os.time()
        local pending,readOK=R.Pending(p)
        R.Status(p,readOK and 'Dados atualizados.' or 'Banco indisponivel. Use ATUALIZAR.',pending,readOK)
        return true
    end
    s.LastSeen=os.time()
    if action==3 then
        if not s.ClientReady then debug('Cliente confirmou o desenho da janela: '..p:getName()..'.') end
        s.ClientReady=true
        return true
    end
    if p:getInterfaceUse()~=0 or p:getState()==32 or p:getDieRegen()~=0 or p:getTeleport()~=0 then
        R.Status(p,'Feche outras interfaces antes de continuar.',R.Pending(p)); return true
    end
    token(s)
    if action==2 then R.Claim(p)
    elseif action==1 then
        for _,r in ipairs(C.Roulettes) do if r.ID==rid then R.Spin(p,r); return true end end
        R.Status(p,'Roleta invalida.',R.Pending(p))
    else R.Status(p,'Acao invalida.',R.Pending(p)) end
    return true
end
if C.Enabled then
    local valid,err=pcall(R.Validate)
    if not valid then log('ERRO na configuracao: '..tostring(err)); return R end
    GameServerFunctions.NpcTalk(R.NpcTalk)
    GameServerFunctions.GameServerProtocol(R.Protocol)
    GameServerFunctions.MonsterReload(R.PrepareNPC)
    GameServerFunctions.PlayerLogout(function(i) sessions[i]=nil end)
    Timer.TimeOut(2,R.PrepareNPC)
    Timer.Interval(60,R.PrepareNPC)
    local old=GiroDaSorte_Config
    if old and old.Enabled then
        for _,n in ipairs(old.Npc or {}) do
            if n.Class==C.NPC.Class and n.Map==C.NPC.Map
                and math.abs(n.PosX-C.NPC.X)<=C.NPC.PositionTolerance and math.abs(n.PosY-C.NPC.Y)<=C.NPC.PositionTolerance then
                log('CONFLITO: GiroDaSorte usa este NPC. Desative-o em Configs/GiroDaSorte.lua ou escolha outro NPC/posicao.')
            end
        end
    end
    log('Carregado (itens/tooltip v4). Execute SQL/LuckyRoulette.sql antes de usar.')
end
return R
