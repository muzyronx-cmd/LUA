-- Le o estado do Systems/Invasion.lua distribuido em Scripts.zip.
-- Nao cria monstros nem modifica horarios, mortes ou recompensas.
InvasionNotifications = {}
local lastRequest = {}
local MAX_INVASIONS, MAX_GROUPS = 8, 16

local function log(message)
    if InvasionNotifications_Config.Debug then
        LogAdd("[INVASOES] " .. message)
    end
end

function InvasionNotifications.CheckSetup()
    log(string.format("Modulo carregado. Packet %d; protocolo INVN2; ativo=%s.",
        InvasionNotifications_Config.Packet, tostring(InvasionNotifications_Config.Enabled)))
    if InvasionSystem and InvasionSystem.GetNotificationSchedule then
        local definitions, schedules = InvasionSystem.GetNotificationSchedule()
        log(string.format("Agenda integrada: %d invasoes, %d horarios.", #definitions, #schedules))
    else
        log("Agenda nao integrada: confira Systems/Invasion.lua (GetNotificationSchedule).")
    end
end

local function bounded(value, maximum)
    return math.max(0, math.min(maximum, math.floor(tonumber(value) or 0)))
end

local function writeText(packet, value, maximum)
    local text = tostring(value or ""):sub(1, maximum)
    SetBytePacket(packet, #text)
    if #text > 0 then SetCharPacketLength(packet, text, #text) end
end

-- Mesmo calendario local do Schedule.lua: diario, dia da semana ou dia do mes.
function InvasionNotifications.NextStart(schedule, now)
    local current = os.date("*t", now)
    local days = schedule._dayofweek ~= -1 and 7 or (schedule._day ~= -1 and 62 or 1)
    for offset = 0, days do
        local day = os.date("*t", os.time({year = current.year, month = current.month,
            day = current.day + offset, hour = 12}))
        local matches = schedule._dayofweek ~= -1 and day.wday - 1 == schedule._dayofweek
            or schedule._dayofweek == -1 and (schedule._day == -1 or day.day == schedule._day)
        if matches then
            local candidate = os.time({year = day.year, month = day.month, day = day.day,
                hour = schedule._hour, min = schedule._minute, sec = 0})
            if candidate >= now then return candidate - now end
        end
    end
end

function InvasionNotifications.Snapshot()
    local result, ids, upcoming, names = {}, {}, {}, {}
    local definitions, schedules = {}, {}
    if InvasionSystem and InvasionSystem.GetNotificationSchedule then
        definitions, schedules = InvasionSystem.GetNotificationSchedule()
    end
    local now = os.time()
    for _, definition in ipairs(definitions) do names[definition._index] = definition._name end
    for _, schedule in ipairs(schedules) do
        if names[schedule._index] then
            local seconds = InvasionNotifications.NextStart(schedule, now)
            local previous = upcoming[schedule._index]
            if seconds and (not previous or seconds < previous) then
                upcoming[schedule._index] = seconds
            end
        end
    end
    local active, activeCount = {}, 0
    for id, invasion in pairs(INVASION_SYSTEM or {}) do
        if invasion._running == true and (invasion._end or 0) > 0 then
            ids[#ids + 1] = id
            active[id], activeCount = true, activeCount + 1
        end
    end
    for id in pairs(upcoming) do
        if not active[id] then ids[#ids + 1] = id end
    end
    table.sort(ids, function(a, b)
        if active[a] ~= active[b] then return active[a] == true end
        if not active[a] and upcoming[a] ~= upcoming[b] then return upcoming[a] < upcoming[b] end
        return a < b
    end)
    for _, id in ipairs(ids) do
        if #result >= MAX_INVASIONS then break end
        if not active[id] then
            result[#result + 1] = {Id = id, Name = names[id], Active = false,
                Seconds = upcoming[id], Monsters = {}, MoreGroups = false}
        else
            local invasion = INVASION_SYSTEM[id]
            local groups, classes = {}, {}
            for _, entry in pairs(INVASION_MONSTERS or {}) do
                if entry._Invasion == id then
                    local class = entry._Class
                    if not groups[class] then
                        groups[class] = {Class = class, Alive = 0, Total = 0,
                            Name = InvasionNotifications_Config.MonsterNames[class]}
                        classes[#classes + 1] = class
                    end
                    local group = groups[class]
                    group.Total = group.Total + 1
                    -- O sistema original preserva entradas mortas com _index = -1.
                    if entry._index ~= -1 then
                        local monster = User.new(entry._index)
                        if monster:getConnected() >= 2 then
                            group.Alive = group.Alive + 1
                            group.Name = group.Name or monster:getName()
                        end
                    end
                end
            end
            table.sort(classes)
            local list = {}
            for _, class in ipairs(classes) do
                if #list >= MAX_GROUPS then break end
                local group = groups[class]
                group.Name = group.Name or string.format("Monstro #%d", class)
                list[#list + 1] = group
            end
            result[#result + 1] = {Id = id, Name = invasion._Name, Active = true,
                Seconds = invasion._end, Monsters = list, MoreGroups = #classes > #list}
        end
    end
    return result, #ids > #result, activeCount
end

function InvasionNotifications.Send(aIndex, name)
    local packet = "INVN2_DATA-" .. name
    local invasions, more, activeCount = InvasionNotifications.Snapshot()
    CreatePacket(packet, InvasionNotifications_Config.Packet)
    SetBytePacket(packet, #invasions)
    SetBytePacket(packet, more and 1 or 0)
    SetWordPacket(packet, bounded(activeCount, 65535))
    for _, invasion in ipairs(invasions) do
        SetDwordPacket(packet, bounded(invasion.Id, 4294967295))
        writeText(packet, invasion.Name, 40)
        SetDwordPacket(packet, bounded(invasion.Seconds, 4294967295))
        SetBytePacket(packet, invasion.Active and 1 or 0)
        SetBytePacket(packet, #invasion.Monsters)
        SetBytePacket(packet, invasion.MoreGroups and 1 or 0)
        for _, monster in ipairs(invasion.Monsters) do
            writeText(packet, monster.Name, 32)
            SetWordPacket(packet, bounded(monster.Alive, 65535))
            SetWordPacket(packet, bounded(monster.Total, 65535))
        end
    end
    SendPacket(packet, aIndex)
    ClearPacket(packet)
    return #invasions, activeCount
end

function InvasionNotifications.Protocol(aIndex, packet, packetName)
    local config = InvasionNotifications_Config
    if packet ~= config.Packet then return false end
    local player = User.new(aIndex)
    local name = player:getName()
    if packetName ~= "INVN2_GET-" .. name then return false end
    ClearPacket(packetName)
    if not config.Enabled or player:getConnected() < 3 then return true end
    local now = os.time()
    if lastRequest[aIndex] and now - lastRequest[aIndex] < config.RequestCooldown then
        return true
    end
    local firstRequest = lastRequest[aIndex] == nil
    lastRequest[aIndex] = now
    local count, activeCount = InvasionNotifications.Send(aIndex, name)
    if firstRequest then
        log(string.format("Pedido INVN2 recebido; resposta enviada: %d invasoes, %d ativas.", count, activeCount))
    end
    return true
end

function InvasionNotifications.Logout(aIndex)
    lastRequest[aIndex] = nil
end

GameServerFunctions.GameServerProtocol(InvasionNotifications.Protocol)
GameServerFunctions.PlayerLogout(InvasionNotifications.Logout)
Timer.TimeOut(2, InvasionNotifications.CheckSetup)
return InvasionNotifications
