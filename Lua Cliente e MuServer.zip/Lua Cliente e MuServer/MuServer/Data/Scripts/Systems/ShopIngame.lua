--[[
    ShopIngame (SERVIDOR)

    Entrega direta no inventario via ItemSerialCreateComplete (mapa 236),
    como na roleta. Execute MuServer/SQL/ShopIngame.sql antes de instalar.
    Debito e registro dos itens pendentes sao feitos na mesma transacao.
    Nao depende mais do Guardiao de Brindes.

    Seguranca: o cliente envia apenas o ID do produto. Preco, moeda, itens e
    se o produto esta ativo vem SEMPRE de ShopIngame_Config.Products.

    Pacotes (nomes incluem o nome do personagem, como no Shop antigo):
        cliente -> servidor  SHOPI_OPEN-<nome>              (sem corpo)
        cliente -> servidor  SHOPI_BUY-<nome>   dword id
        servidor -> cliente  SHOPI_DATA-<nome>              (moedas+saldos + produtos)
        servidor -> cliente  SHOPI_RESULT-<nome>            (codigo + saldos)

    Moedas: ShopIngame_Config.Coins (tabela/coluna/where configuraveis).

    Codigos de resultado:
        1 = entrega solicitada no inventario
        2 = saldo insuficiente
        3 = produto inexistente / desativado / mal configurado
        4 = erro interno (saldo ilegivel ou falha ao gerar codigo)
        6 = aguarde (cooldown entre compras)
        5 = inventario sem espaco (sem debito)
        7 = loja desativada
        8 = itens pagos pendentes: libere espaco e clique Retirar
        9 = entrega sem confirmacao: conferir inventario/logs; nao repetir
        10 = banco indisponivel: confira a instalacao SQL
]]

ShopIngame = {}

local ShopIngame_LastBuy = {}

local RESULT_OK         = 1
local RESULT_NO_BALANCE = 2
local RESULT_INVALID    = 3
local RESULT_ERROR      = 4
local RESULT_COOLDOWN   = 6
local RESULT_DISABLED   = 7
local RESULT_SPACE, RESULT_PENDING, RESULT_DELIVERY, RESULT_DATABASE = 5, 8, 9, 10

local MAX_ITEMS_PER_PRODUCT = 8

local function PacketNameOf(prefix, name)
    return string.format("%s-%s", prefix, name)
end

local MAX_COINS = 8

-- Nome de tabela/coluna: so letras, numeros, _ e . (vem da config, mas evita erro de digitacao
-- virar consulta quebrada).
local function SafeIdentifier(text)
    return type(text) == "string" and text ~= "" and string.len(text) <= 64 and string.find(text, "^[%w_%.]+$") ~= nil
end

local function CoinValid(coin)
    if type(coin) ~= "table" then return false end
    if type(coin.Name) ~= "string" or coin.Name == "" or string.len(coin.Name) > 32 then return false end
    if not SafeIdentifier(coin.Table) or not SafeIdentifier(coin.Column) or not SafeIdentifier(coin.Where) then return false end
    if coin.IdType ~= 0 and coin.IdType ~= 1 then return false end
    return true
end

-- Lista ordenada (1..N consecutivas, no maximo MAX_COINS) das moedas validas.
local function CoinIds()
    local ids = {}
    for id = 1, MAX_COINS do
        if CoinValid(ShopIngame_Config.Coins[id]) then
            table.insert(ids, id)
        end
    end
    return ids
end

-- Valor de identificacao da moeda (IdType 0 = login da conta, 1 = nome do personagem)
local function CoinKey(coin, player)
    if coin.IdType == 0 then
        return player:getAccountID()
    end
    return player:getName()
end

local function ReadBalance(coinId, player)
    local coin = ShopIngame_Config.Coins[coinId]
    if not CoinValid(coin) then return nil end
    return DataBase.GetValue(coin.Table, coin.Column, coin.Where, CoinKey(coin, player))
end

-- Produto valido = existe, ativo, moeda existente, preco inteiro > 0, 1..8 itens validos.
local function Integer(v,min,max)
    return type(v)=="number" and v==math.floor(v) and v>=min and v<=max
end

local function ValidateProduct(product)
    if type(product) ~= "table" then return false end
    if product.Enabled ~= true then return false end
    if not Integer(product.Category,0,255) or not Integer(product.Coin,1,MAX_COINS) or not Integer(product.Price,1,2147483647) then return false end
    if type(product.Name) ~= "string" or product.Name == "" or string.len(product.Name) > 255 then return false end
    if type(product.Desc) ~= "string" or string.len(product.Desc) > 255 then return false end
    if type(product.Category) ~= "number" or product.Category < 0 or product.Category > 255 then return false end
    if type(product.Coin) ~= "number" or product.Coin < 1 or product.Coin > MAX_COINS or not CoinValid(ShopIngame_Config.Coins[product.Coin]) then return false end
    if type(product.Price) ~= "number" or product.Price <= 0 or product.Price ~= math.floor(product.Price) then return false end
    if type(product.Items) ~= "table" or #product.Items < 1 or #product.Items > MAX_ITEMS_PER_PRODUCT then return false end
    for i = 1, #product.Items do
        local it = product.Items[i]
        if type(it) ~= "table" then return false end
        if type(it.Section) ~= "number" or type(it.Index) ~= "number" then return false end
        if type(it.Level) ~= "number" or type(it.Skill) ~= "number" or type(it.Luck) ~= "number"
            or type(it.Option) ~= "number" or type(it.Exc) ~= "number" then return false end
        if not Integer(it.Section,0,15) or not Integer(it.Index,0,511) or not Integer(it.Level,0,15)
            or not Integer(it.Skill,0,1) or not Integer(it.Luck,0,1) or not Integer(it.Option,0,7) or not Integer(it.Exc,0,63) then return false end
    end
    return true
end

-- Lista ordenada de ids de produtos validos
local function ValidProductIds()
    local ids = {}
    for id, product in pairs(ShopIngame_Config.Products) do
        if Integer(id,1,2147483647) and ValidateProduct(product) then
            table.insert(ids, id)
        end
    end
    table.sort(ids)
    return ids
end

-- DATA: byte quantidade de moedas; para cada uma: id, nome (byte+texto), saldo
local function SendCoins(packet, player)
    local ids = CoinIds()
    SetBytePacket(packet, #ids)
    for _, id in ipairs(ids) do
        local coin = ShopIngame_Config.Coins[id]
        SetBytePacket(packet, id)
        SetBytePacket(packet, string.len(coin.Name))
        SetCharPacketLength(packet, coin.Name, string.len(coin.Name))
        SetDwordPacket(packet, ReadBalance(id, player) or 0)
    end
end

function ShopIngame.SendData(aIndex)
    local player = User.new(aIndex)
    local name = player:getName()
    local packet = PacketNameOf("SHOPI_DATA", name)

    CreatePacket(packet, ShopIngame_Config.Packet)
    SendCoins(packet, player)

    local ids = ValidProductIds()
    SetDwordPacket(packet, #ids)

    for _, id in ipairs(ids) do
        local p = ShopIngame_Config.Products[id]

        SetDwordPacket(packet, id)
        SetBytePacket(packet, string.len(p.Name))
        SetCharPacketLength(packet, p.Name, string.len(p.Name))
        SetBytePacket(packet, string.len(p.Desc))
        if string.len(p.Desc) > 0 then
            SetCharPacketLength(packet, p.Desc, string.len(p.Desc))
        end
        SetBytePacket(packet, p.Category)
        SetBytePacket(packet, p.Coin)
        SetDwordPacket(packet, p.Price)
        SetBytePacket(packet, #p.Items)

        for i = 1, #p.Items do
            local it = p.Items[i]
            SetWordPacket(packet, GET_ITEM(it.Section, it.Index))
            SetBytePacket(packet, it.Level)
            SetBytePacket(packet, it.Skill)
            SetBytePacket(packet, it.Luck)
            SetBytePacket(packet, it.Option)
            SetBytePacket(packet, it.Exc)
        end
    end

    SendPacket(packet, aIndex)
    ClearPacket(packet)
end

-- Saldo relido depois da transacao sincronica de compra.
local function SendResult(aIndex, result)
    local player = User.new(aIndex)
    local packet = PacketNameOf("SHOPI_RESULT", player:getName())

    CreatePacket(packet, ShopIngame_Config.Packet)
    SetBytePacket(packet, result)

    -- RESULT: byte quantidade; para cada moeda: id e saldo
    local ids = CoinIds()
    SetBytePacket(packet, #ids)
    for _, coinId in ipairs(ids) do
        local value = ReadBalance(coinId, player)
        SetBytePacket(packet, coinId)
        SetDwordPacket(packet, value or 0)
    end

    SendPacket(packet, aIndex)
    ClearPacket(packet)
end

local function Durability(section, index)
    -- Mesma regra de durabilidade do Shop antigo
    if section == 15 and index == 39 then return 0 end
    if section == 14 and (index == 208 or index == 207 or index == 206 or index == 203) then return 0 end
    return 255
end

local function Quote(value)
    return "'" .. tostring(value):gsub("'", "''") .. "'"
end

local function Ident(value)
    assert(SafeIdentifier(value), "Identificador SQL invalido")
    return '[' .. value:gsub('%.', '].[') .. ']'
end

local function Query(sql, fields)
    local db=DataBase.getDb()
    if db:exec(sql)==0 then db:clear(); return nil,false end
    if db:fetch()==100 then db:clear(); return nil,true end
    local row={}
    for _,field in ipairs(fields) do row[field]=db:getInt(field) end
    db:clear()
    return row,true
end

local rewardFields={'ID','Item','Level','Durability','Skill','Luck','Opt','Excellent'}
local function Pending(player)
    return Query('SELECT TOP 1 ID,Item,Level,Durability,Skill,Luck,Opt,Excellent FROM dbo.ShopIngameReward WHERE Account='..Quote(player:getAccountID())..' AND State=0 ORDER BY ID',rewardFields)
end

-- Native delivery has no acknowledgement. Reserve durably before calling it;
-- never retry State=1 automatically, even after a native error or reconnect.
function ShopIngame.Deliver(aIndex, quiet)
    local player=User.new(aIndex)
    local delivered=0
    for i=1,MAX_ITEMS_PER_PRODUCT do
        local reward,readOK=Pending(player)
        if not readOK then SendResult(aIndex,RESULT_DATABASE); return end
        if not reward then
            if not quiet or delivered>0 then SendResult(aIndex,RESULT_OK) end
            return
        end
        if InventoryCheckSpaceByItem(aIndex,reward.Item)~=1 then
            SendResult(aIndex,RESULT_PENDING); return
        end
        local reserved,ok=Query('SET NOCOUNT ON; UPDATE dbo.ShopIngameReward SET State=1,ClaimAt=GETUTCDATE() OUTPUT inserted.ID WHERE ID='..reward.ID..' AND State=0',{'ID'})
        if not ok or not reserved then SendResult(aIndex,RESULT_DATABASE); return end
        LogAddC(2,'[SHOP INGAME] Entrega solicitada ID='..reward.ID..' / '..player:getAccountID())
        local success=pcall(ItemSerialCreateComplete,aIndex,236,0,0,reward.Item,reward.Level,reward.Durability,reward.Skill,reward.Luck,reward.Opt,aIndex,reward.Excellent,0,0)
        if not success then
            LogAddC(2,'[SHOP INGAME] Falha nativa; conferir inventario antes de recuperar ID='..reward.ID)
            SendResult(aIndex,RESULT_DELIVERY); return
        end
        delivered=delivered+1
    end
    local remaining,readOK=Pending(player)
    SendResult(aIndex,not readOK and RESULT_DATABASE or remaining and RESULT_PENDING or RESULT_OK)
end

function ShopIngame.Buy(aIndex, productId)
    if not ShopIngame_Config.Enabled then SendResult(aIndex,RESULT_DISABLED); return end
    local now=os.time()
    local last=ShopIngame_LastBuy[aIndex]
    if last and now-last<ShopIngame_Config.CooldownSeconds then SendResult(aIndex,RESULT_COOLDOWN); return end
    ShopIngame_LastBuy[aIndex]=now
    local product=ShopIngame_Config.Products[productId]
    if not ValidateProduct(product) then SendResult(aIndex,RESULT_INVALID); return end
    local player=User.new(aIndex)
    local pending,readOK=Pending(player)
    if not readOK then SendResult(aIndex,RESULT_DATABASE); return end
    if pending then ShopIngame.Deliver(aIndex); return end
    -- Preflight each model. Several items may need more space together: their
    -- durable records retain any remainder without charging again.
    for _,it in ipairs(product.Items) do
        if InventoryCheckSpaceByItem(aIndex,GET_ITEM(it.Section,it.Index))~=1 then
            SendResult(aIndex,RESULT_SPACE); return
        end
    end
    local coin=ShopIngame_Config.Coins[product.Coin]
    local account=Quote(player:getAccountID())
    -- Serialize all currencies for this account, including other GameServers.
    -- Atomic conditional debit replaces the old asynchronous balance subtraction.
    local sql="SET NOCOUNT ON; SET XACT_ABORT ON; BEGIN TRY BEGIN TRAN; DECLARE @l int; EXEC @l=sys.sp_getapplock @Resource="..Quote('ShopIngame:'..player:getAccountID())..", @LockMode='Exclusive', @LockOwner='Transaction', @LockTimeout=3000; IF @l<0 RAISERROR('lock',16,1); "
    sql=sql..'IF EXISTS(SELECT 1 FROM dbo.ShopIngameReward WHERE Account='..account..' AND (State=0 OR CreatedAt>DATEADD(second,-'..ShopIngame_Config.CooldownSeconds..",GETUTCDATE()))) BEGIN ROLLBACK; SELECT 6 AS Result; RETURN; END; "
    sql=sql..'UPDATE '..Ident(coin.Table)..' SET '..Ident(coin.Column)..'='..Ident(coin.Column)..'-'..product.Price..' WHERE '..Ident(coin.Where)..'='..Quote(CoinKey(coin,player))..' AND '..Ident(coin.Column)..'>='..product.Price..'; IF @@ROWCOUNT<>1 BEGIN ROLLBACK; SELECT 2 AS Result; RETURN; END; '
    for _,it in ipairs(product.Items) do
        sql=sql..'INSERT dbo.ShopIngameReward(Account,Character,Product,Item,Level,Durability,Skill,Luck,Opt,Excellent) VALUES('..account..','..Quote(player:getName())..','..productId..','..GET_ITEM(it.Section,it.Index)..','..it.Level..','..Durability(it.Section,it.Index)..','..it.Skill..','..it.Luck..','..it.Option..','..it.Exc..'); '
    end
    sql=sql..'COMMIT; SELECT 1 AS Result; END TRY BEGIN CATCH IF @@TRANCOUNT>0 ROLLBACK; SELECT 10 AS Result; END CATCH;'
    local result=Query(sql,{'Result'})
    if not result then SendResult(aIndex,RESULT_DATABASE); return end
    if result.Result~=RESULT_OK then SendResult(aIndex,result.Result); return end
    ShopIngame.Deliver(aIndex)
end

function ShopIngame.Protocol(aIndex, Packet, PacketName)
    if Packet ~= ShopIngame_Config.Packet then return false end

    local player = User.new(aIndex)
    local name = player:getName()

    if PacketName == PacketNameOf("SHOPI_OPEN", name) then
        ClearPacket(PacketName)
        if ShopIngame_Config.Enabled then
            ShopIngame.SendData(aIndex)
            ShopIngame.Deliver(aIndex,true)
        else
            SendResult(aIndex, RESULT_DISABLED)
            ShopIngame.Deliver(aIndex,true)
        end
        return true
    end

    if PacketName == PacketNameOf("SHOPI_CLAIM", name) then
        ClearPacket(PacketName)
        -- Paid items remain withdrawable even if new sales are disabled.
        ShopIngame.Deliver(aIndex)
        return true
    end

    if PacketName == PacketNameOf("SHOPI_BUY", name) then
        local productId = GetDwordPacket(PacketName, -1)
        ClearPacket(PacketName)
        ShopIngame.Buy(aIndex, productId)
        return true
    end

    return false
end

function ShopIngame.Logout(aIndex, Name, Account)
    ShopIngame_LastBuy[aIndex] = nil
end

-- Avisa no log do GameServer produtos mal configurados (nao entram na loja)
function ShopIngame.CheckConfig()
    for id = 1, MAX_COINS do
        local coin = ShopIngame_Config.Coins[id]
        if coin ~= nil and not CoinValid(coin) then
            LogAddC(2, string.format("[SHOP INGAME] Moeda %d com configuracao invalida (Name/Table/Column/Where/IdType) e foi ignorada.", id))
        end
    end
    for id, product in pairs(ShopIngame_Config.Products) do
        if product ~= nil and product.Enabled == true and not (Integer(id,1,2147483647) and ValidateProduct(product)) then
            LogAddC(2, string.format("[SHOP INGAME] Produto %s esta ativo mas com configuracao invalida e foi ignorado.", tostring(id)))
        end
    end
end

function ShopIngame.Init()
    -- Register even when new sales are disabled, so paid items can be collected.
    GameServerFunctions.GameServerProtocol(ShopIngame.Protocol)
    GameServerFunctions.PlayerLogout(ShopIngame.Logout)
    Timer.TimeOut(2, ShopIngame.CheckConfig)
end

ShopIngame.Init()

return ShopIngame
