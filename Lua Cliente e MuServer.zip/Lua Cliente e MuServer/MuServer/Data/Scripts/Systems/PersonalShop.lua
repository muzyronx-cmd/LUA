Lojinha = {}

local Switch_Coin1 = 1
local Switch_Coin2 = 1
local Switch_Coin3 = 1
local Switch_Coin4 = 0

local PERSONAL_SHOP_COIN_TABLE = {}
PERSONAL_SHOP_COIN_TABLE[0] = 'CashShopData'
PERSONAL_SHOP_COIN_TABLE[1] = 'CashShopData'
PERSONAL_SHOP_COIN_TABLE[2] = 'CashShopData'

local PERSONAL_SHOP_COIN_COLUMN = {}
PERSONAL_SHOP_COIN_COLUMN[0] = 'WCoinC'
PERSONAL_SHOP_COIN_COLUMN[1] = 'WCoinP'
PERSONAL_SHOP_COIN_COLUMN[2] = 'GlobinPoint'

local PERSONAL_SHOP_COIN_WHERE = {}
PERSONAL_SHOP_COIN_WHERE[0] = 'AccountID'
PERSONAL_SHOP_COIN_WHERE[1] = 'AccountID'
PERSONAL_SHOP_COIN_WHERE[2] = 'AccountID'

local PERSONAL_SHOP_COIN_NAME = {}
PERSONAL_SHOP_COIN_NAME[0] = 'Cash'
PERSONAL_SHOP_COIN_NAME[1] = 'Gold'
PERSONAL_SHOP_COIN_NAME[2] = 'JC Point'


--[[ Functions ]]--
function Lojinha.CheckPersonalShopValue(aIndex, ItemIndex, Coin1, Coin2, Coin3, Coin4)
	local player = User.new(aIndex)
	local Account = player:getAccountID()

	if Switch_Coin1 == 1
	then
		if Coin1 > 0
		then
			local AccountCoin1 = DataBase.GetValue(PERSONAL_SHOP_COIN_TABLE[0], PERSONAL_SHOP_COIN_COLUMN[0], PERSONAL_SHOP_COIN_WHERE[0], Account)
			
			if(AccountCoin1 < Coin1)
			then
			  --  SendMessage(string.format(PERSONAL_SHOP_MESSAGES[Language][9], AccountCoin1), aIndex, 1)
				return 25
			end
		end
	end
	
	if Switch_Coin2 == 1
	then
		if Coin2 > 0
		then
			local AccountCoin2 = DataBase.GetValue(PERSONAL_SHOP_COIN_TABLE[1], PERSONAL_SHOP_COIN_COLUMN[1], PERSONAL_SHOP_COIN_WHERE[1], Account)
			
			if(AccountCoin2 < Coin2)
			then
		 --    	SendMessage(string.format(PERSONAL_SHOP_MESSAGES[Language][10], Coin2), aIndex, 1)
				return 26
			end
		end
	end
	
	if Switch_Coin3 == 1
	then
		if Coin3 > 0
		then
			local AccountCoin3 = DataBase.GetValue(PERSONAL_SHOP_COIN_TABLE[2], PERSONAL_SHOP_COIN_COLUMN[2], PERSONAL_SHOP_COIN_WHERE[2], Account)
			
			if(AccountCoin3 < Coin3)
			then
		    	--SendMessage(string.format(PERSONAL_SHOP_MESSAGES[Language][11], Coin3), aIndex, 1)
				return 27
			end
		end
	end
	
	if Switch_Coin4 == 1
	then
		if Coin4 > 0
		then
			local AccountCoin4 = DataBase.GetValue(PERSONAL_SHOP_COIN_TABLE[3], PERSONAL_SHOP_COIN_COLUMN[3], PERSONAL_SHOP_COIN_WHERE[3], Account)
			
			if(AccountCoin4 < Coin4)
			then
			  -- SendMessage(string.format(PERSONAL_SHOP_MESSAGES[Language][12], Coin4), aIndex, 1)
				return 28
			end
		end
	end
	
	return 1
end

function Lojinha.PersonalShopAddValue(aIndex, Coin1, Coin2, Coin3, Coin4)
	local player = User.new(aIndex)
	local Account = player:getAccountID()

	if Switch_Coin1 == 1
	then
		if(Coin1 > 0)
		then
			DataBase.SetAddValue(PERSONAL_SHOP_COIN_TABLE[0], PERSONAL_SHOP_COIN_COLUMN[0], Coin1, PERSONAL_SHOP_COIN_WHERE[0], Account)
		end
	end
	
	if Switch_Coin2 == 1
	then
		if(Coin2 > 0)
		then
			DataBase.SetAddValue(PERSONAL_SHOP_COIN_TABLE[1], PERSONAL_SHOP_COIN_COLUMN[1], Coin2, PERSONAL_SHOP_COIN_WHERE[1], Account)
		end
	end
	
	if Switch_Coin3 == 1
	then
		if(Coin3 > 0)
		then
			DataBase.SetAddValue(PERSONAL_SHOP_COIN_TABLE[2], PERSONAL_SHOP_COIN_COLUMN[2], Coin3, PERSONAL_SHOP_COIN_WHERE[2], Account)
		end
	end

	if Switch_Coin4 == 1
	then
		if(Coin4 > 0)
		then
			DataBase.SetAddValue(PERSONAL_SHOP_COIN_TABLE[3], PERSONAL_SHOP_COIN_COLUMN[3], Coin4, PERSONAL_SHOP_COIN_WHERE[3], Account)
		end
	end
end

function Lojinha.PersonalShopDecreaseValue(aIndex, Coin1, Coin2, Coin3, Coin4)
	local player = User.new(aIndex)
	local Account = player:getAccountID()

	if Switch_Coin1 == 1
	then
		if(Coin1 > 0)
		then
			DataBase.SetDecreaseValue(PERSONAL_SHOP_COIN_TABLE[0], PERSONAL_SHOP_COIN_COLUMN[0], Coin1, PERSONAL_SHOP_COIN_WHERE[0], Account)
		end
	end
	
	if Switch_Coin2 == 1
	then
		if(Coin2 > 0)
		then
			DataBase.SetDecreaseValue(PERSONAL_SHOP_COIN_TABLE[1], PERSONAL_SHOP_COIN_COLUMN[1], Coin2, PERSONAL_SHOP_COIN_WHERE[1], Account)
		end
	end
	
	if Switch_Coin3 == 1
	then
		if(Coin3 > 0)
		then
			DataBase.SetDecreaseValue(PERSONAL_SHOP_COIN_TABLE[2], PERSONAL_SHOP_COIN_COLUMN[2], Coin3, PERSONAL_SHOP_COIN_WHERE[2], Account)
		end
	end

	if Switch_Coin4 == 1
	then
		if(Coin4 > 0)
		then
			DataBase.SetDecreaseValue(PERSONAL_SHOP_COIN_TABLE[3], PERSONAL_SHOP_COIN_COLUMN[3], Coin4, PERSONAL_SHOP_COIN_WHERE[3], Account)
		end
	end
	
end

GameServerFunctions.PersonalShopCheckValue(Lojinha.CheckPersonalShopValue)
GameServerFunctions.PersonalShopAddValue(Lojinha.PersonalShopAddValue)
GameServerFunctions.PersonalShopDecreaseValue(Lojinha.PersonalShopDecreaseValue)


return Lojinha