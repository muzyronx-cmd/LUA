
-- true Ativa o sistema, false Desativa
BonusLogin_Ativado = false

-- M�ximo de dias que ele vai ter um bonus antes de resetar a contagem
BonusLogin_MaximoDias = 1

-- Configura��o do script no sql
BonusLogin_SqlConfig = {Tabela = "MEMB_STAT", Coluna = "DiasConsecutivos", ColunaRecebido = "BonusRecebido", Where = "memb___id", Tipo = 0}

-- Bonus em moeda
BonusLogin_PremioMoeda = {
{Dia = 1, Nome = "Golds", Valor = 5, Tabela = "CashShopData", Coluna = "WCoinP", Where = "AccountID", Tipo = 0},

}

-- Bonus em item (cuidado com itens grandes ou muitos itens, se o player nao tiver espa�o no inventairo ele nao vai receber)
BonusLogin_PremioItem = {
{Dia = 1,  Nome = "Box", Quantidade = 8, Section = 14, Index = 212, Level = 0, Skill = 0, Luck = 0, Dur = 255, Opt = 0, Exc = 0, Tempo = 0},

}
