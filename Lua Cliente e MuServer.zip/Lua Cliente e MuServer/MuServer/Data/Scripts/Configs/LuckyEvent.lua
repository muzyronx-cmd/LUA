LuckyEvent_Config = {
    Enabled = true,

    Packet = 215,

    Expiration = 1710039600,

    Ranking = {
        [0] = {Table = "Character", Column = "LuckyPointsFree", Where = "Name", IdType = 1},
        [1] = {Table = "Character", Column = "LuckyPointsDonate", Where = "Name", IdType = 1},
    },

    Coin = {
        [0] = {ItemIndex = GET_ITEM(14, 221), Valor = 60},
        [1] = {ItemIndex = GET_ITEM(14, 222), Valor = 10},
    },

    Prizes = {
        [0] = {
            {ListID = 01, ItemIndex = GET_ITEM(14, 189), Level = 0,  Dur = 01,  Skill = 0, Luck = 0, Opt = 0, Exc = 00, Ancient = 0, Harmony = 0, Rate = 05.00},
            {ListID = 02, ItemIndex = GET_ITEM(12, 208), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 1, Rate = 00.50},
            {ListID = 03, ItemIndex = GET_ITEM(12, 209), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 1, Rate = 00.50},
            {ListID = 04, ItemIndex = GET_ITEM(7,   91), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 05, ItemIndex = GET_ITEM(8,   91), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 06, ItemIndex = GET_ITEM(9,   91), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 07, ItemIndex = GET_ITEM(10,  91), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 08, ItemIndex = GET_ITEM(11,  91), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 09, ItemIndex = GET_ITEM(7,   92), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 10, ItemIndex = GET_ITEM(8,   92), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 11, ItemIndex = GET_ITEM(9,   92), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 12, ItemIndex = GET_ITEM(10,  92), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 13, ItemIndex = GET_ITEM(11,  92), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 14, ItemIndex = GET_ITEM(0,   46), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 15, ItemIndex = GET_ITEM(0,   47), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 16, ItemIndex = GET_ITEM(1,   12), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 17, ItemIndex = GET_ITEM(3,   13), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 18, ItemIndex = GET_ITEM(4,   27), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 19, ItemIndex = GET_ITEM(5,   51), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 20, ItemIndex = GET_ITEM(6,   25), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00},
            {ListID = 21, ItemIndex = GET_ITEM(13, 201), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 00, Ancient = 0, Harmony = 1, Rate = 00.50},
            {ListID = 22, ItemIndex = GET_ITEM(12,  36), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 11.00},
            {ListID = 23, ItemIndex = GET_ITEM(12,  37), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 11.00},
            {ListID = 24, ItemIndex = GET_ITEM(12,  38), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 11.00},
            {ListID = 25, ItemIndex = GET_ITEM(12,  39), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 11.00},
            {ListID = 26, ItemIndex = GET_ITEM(14,  70), Level = 0,  Dur = 255, Skill = 0, Luck = 0, Opt = 0, Exc = 00, Ancient = 0, Harmony = 0, Rate = 15.75},
            {ListID = 27, ItemIndex = GET_ITEM(14,  35), Level = 0,  Dur = 20,  Skill = 0, Luck = 0, Opt = 0, Exc = 00, Ancient = 0, Harmony = 0, Rate = 15.75},
        },

        [1] = {
           {ListID = 01, ItemIndex = GET_ITEM(14, 189), Level = 0,  Dur = 01,  Skill = 0, Luck = 0, Opt = 0, Exc = 00, Ancient = 0, Harmony = 0, Rate = 05.00}, --HORSE MIDNIGHT
           {ListID = 02, ItemIndex = GET_ITEM(14, 225), Level = 0,  Dur = 01,  Skill = 0, Luck = 0, Opt = 0, Exc = 00, Ancient = 0, Harmony = 0, Rate = 00.10}, --ROYAL DARKNESS CAPE [V]
           {ListID = 03, ItemIndex = GET_ITEM(12, 237), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 1, Rate = 00.70}, --HORSE HOLY
           {ListID = 04, ItemIndex = GET_ITEM(12, 238), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 1, Rate = 00.70}, --EARRING REAPER LEFT
           {ListID = 05, ItemIndex = GET_ITEM(7,  125), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --EARRING REAPER RIGHT
           {ListID = 06, ItemIndex = GET_ITEM(8,  125), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --WINGS HEAT [SKIN D] [V]
           {ListID = 07, ItemIndex = GET_ITEM(9,  125), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --ANGEL WINGS [V]
           {ListID = 08, ItemIndex = GET_ITEM(10, 125), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SWORD OF STYLE
           {ListID = 09, ItemIndex = GET_ITEM(11, 125), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET DRAGON BLACK HELM [V]
           {ListID = 10, ItemIndex = GET_ITEM(7,  126), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET DRAGON BLACK ARMOR [V]
           {ListID = 11, ItemIndex = GET_ITEM(8,  126), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET DRAGON BLACK PANTS [V]
           {ListID = 12, ItemIndex = GET_ITEM(9,  126), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET DRAGON BLACK GLOVES [V]
           {ListID = 13, ItemIndex = GET_ITEM(10, 126), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET DRAGON BLACK BOOTS [V]
           {ListID = 14, ItemIndex = GET_ITEM(11, 126), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --PHANTOM MACE MACE [V]
           {ListID = 15, ItemIndex = GET_ITEM(0,   64), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --CHAOS SHIELD BLACK [V]
           {ListID = 16, ItemIndex = GET_ITEM(1,   29), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET GRAND SOUL BLACK HELM [V]
           {ListID = 17, ItemIndex = GET_ITEM(4,   36), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET GRAND SOUL BLACK ARMOR [V]
           {ListID = 18, ItemIndex = GET_ITEM(5,   52), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET GRAND SOUL BLACK PANTS [V]
           {ListID = 19, ItemIndex = GET_ITEM(6,   46), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 63, Ancient = 0, Harmony = 1, Rate = 01.00}, --SET GRAND SOUL BLACK GLOVES [V]
           {ListID = 20, ItemIndex = GET_ITEM(13, 244), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 00, Ancient = 0, Harmony = 1, Rate = 00.50}, --SET GRAND SOUL BLACK BOOTS [V]
           {ListID = 21, ItemIndex = GET_ITEM(12,  36), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 07.00}, --STAFF KUNDUN BLACK [V]
           {ListID = 22, ItemIndex = GET_ITEM(12,  37), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 07.00}, --SHIELD GRANDSOUL BLACK [V]
           {ListID = 23, ItemIndex = GET_ITEM(12,  38), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 07.00}, --LIGHT SABER BLACK [V]
           {ListID = 24, ItemIndex = GET_ITEM(12,  39), Level = 15, Dur = 255, Skill = 1, Luck = 1, Opt = 7, Exc = 47, Ancient = 0, Harmony = 0, Rate = 07.00}, --LIGHT SABER BLACK [V]
           {ListID = 25, ItemIndex = GET_ITEM(14,  70), Level = 0,  Dur = 255, Skill = 0, Luck = 0, Opt = 0, Exc = 00, Ancient = 0, Harmony = 0, Rate = 15.00}, --LIGHT SABER BLACK [V]
           {ListID = 26, ItemIndex = GET_ITEM(14,  35), Level = 0,  Dur = 20,  Skill = 0, Luck = 0, Opt = 0, Exc = 00, Ancient = 0, Harmony = 0, Rate = 15.00}, --LIGHT SABER BLACK [V]
        },

    },

    Message = {
        ["Por"] = {
            [1] = "O evento n�o est� mais dispon�vel",
        },
        ["Eng"] = {
            [1] = "The event is no longer available",
        },
        ["Spn"] = {
            [1] = "El evento ya no est� disponible",
        },
    }

}

return LuckyEvent