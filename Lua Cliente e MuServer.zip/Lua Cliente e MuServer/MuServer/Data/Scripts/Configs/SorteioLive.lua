
-- Comando para abrir o sorteio. Sintaxe: /comandoabrir <comandoentrar> <quantidadedevencedores> (Ex: /abrirsorteio /stron 5) comando de entrar tem que ter /
SL_COMMAND_OPEN = "/abrirsorteio"

-- Comando para ver a quantidadede de participantes
SL_COMMAND_INFO = "/infosorteio" 

-- Comando para finalizar o sorteio
SL_COMMAND_END = "/fecharsorteio" 

-- Comando para cancelar um sorteio em andamento
SL_COMMAND_CANCEL = "/cancelarsorteio" 

-- Comando para puxar os vencedores do sorteio
SL_COMMAND_PREMIAR = "/premiarsorteio" 

-- Tempo em segundos que vai ficar anunciando o comando para entrar no sorteio. Ex. 15, a cada 15 segundos avisa no global o comando.
SL_TIME_ANNOUNCE = 15

-- Tipo de autentica��o para usar o comando (0 s� pode usar o comando os logins cadastrados abaixo. 1 autentica por ser staff, ignorando a lsita abaixo)
SL_AUTH_MODE = 1

-- Login e Char autorizado a realizar sorteio (caso SL_AUTH_MODE esteja = 0)
SL_AUTH = {
{Login = "admin", Char = "Admin"},}