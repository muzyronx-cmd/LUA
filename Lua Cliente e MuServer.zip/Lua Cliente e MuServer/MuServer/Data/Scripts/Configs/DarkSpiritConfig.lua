DARK_SPIRIT_INFO = {

    { ItemIndex = GET_ITEM(13, 232), ModelName = 'UncleanIcon',   ObjectName = 'Unclean' },
    { ItemIndex = GET_ITEM(13, 238), ModelName = 'iconsaphure',   ObjectName = 'EagleSaphure' },
	{ ItemIndex = GET_ITEM(13, 244), ModelName = 'iconzeus',      ObjectName = 'EagleZeus' },
	{ ItemIndex = GET_ITEM(13, 254), ModelName = 'iconzeus',      ObjectName = 'EagleFrost' },
	{ ItemIndex = GET_ITEM(13, 256), ModelName = 'EagleIco',      ObjectName = 'Eakerdefo' },
	{ ItemIndex = GET_ITEM(13, 267), ModelName = 'EagleIcoHorus', ObjectName = 'EagleHorus202' },
	{ ItemIndex = GET_ITEM(13, 274), ModelName = 'IconRedFenril', ObjectName = 'ealgeFenrirRed' },
	{ ItemIndex = GET_ITEM(13, 318), ModelName = 'DarkRavenIcon', ObjectName = 'DarkRavenSkin2' },

}

function StartLoadDarkSpirit()
    for i = 1, #DARK_SPIRIT_INFO do
        SetDarkSpirit(DARK_SPIRIT_INFO[i].ItemIndex, DARK_SPIRIT_INFO[i].ModelName, DARK_SPIRIT_INFO[i].ObjectName)
    end
end

StartLoadDarkSpirit()