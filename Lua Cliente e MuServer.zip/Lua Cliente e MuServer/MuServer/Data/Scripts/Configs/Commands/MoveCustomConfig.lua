--[[
Command Config
]]--
-- Configura��es moves customs
MOVES_CUSTOMS_SWITCH = 1

-- Comando, MapNumber, CoordX, CoordY, MinLevel, VipType, Price, Pk, Reset, MReset
MOVES_CUSTOMS = {
{Move = '/lorencia'        , Map = 0, CoordX = 143, CoordY = 127, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/lorencia2'       , Map = 0, CoordX = 76, CoordY = 155, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/lorencia2'       , Map = 0, CoordX = 76, CoordY = 155, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/lorencia3'       , Map = 0, CoordX = 220, CoordY = 200, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/lorencia4'       , Map = 0, CoordX = 210, CoordY = 109, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/cemiterio'       , Map = 0, CoordX = 140, CoordY = 225, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/pista'           , Map = 0, CoordX = 110, CoordY = 65, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/bar'             , Map = 0, CoordX = 125, CoordY = 125, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/ferreiro'        , Map = 0, CoordX = 118, CoordY = 141, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/mago'            , Map = 0, CoordX = 120, CoordY = 113, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/resgatequest'    , Map = 0, CoordX = 141, CoordY = 145, MinLevel = 10, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/dungeon'         , Map = 1, CoordX = 108, CoordY = 247, MinLevel = 40, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/dungeon2'        , Map = 1, CoordX = 50, CoordY = 205, MinLevel = 40, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/devias'          , Map = 2, CoordX = 203, CoordY = 37, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/devias2'         , Map = 2, CoordX = 20, CoordY =  25, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/devias3'         , Map = 2, CoordX = 225, CoordY = 230, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/devias4'         , Map = 2, CoordX = 160, CoordY = 242, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/devias'          , Map = 2, CoordX = 204, CoordY = 44, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/igreja'          , Map = 2, CoordX = 210, CoordY = 25, MinLevel = 15, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/noria'           , Map = 3, CoordX = 173, CoordY = 110, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/noria2'          , Map = 3, CoordX = 15, CoordY = 15, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/noria3'          , Map = 3, CoordX = 235, CoordY = 135, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/noria'           , Map = 3, CoordX = 173, CoordY = 111, MinLevel = 30, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/losttower'       , Map = 4, CoordX = 209, CoordY = 73, MinLevel = 80, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/losttower2'      , Map = 4, CoordX = 240, CoordY = 240, MinLevel = 80, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/arena'           , Map = 6, CoordX = 50, CoordY = 50, MinLevel = 166, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena1'          , Map = 6, CoordX = 55, CoordY = 80, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena2'          , Map = 6, CoordX = 38, CoordY = 44, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena3'          , Map = 6, CoordX = 38, CoordY = 66, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena4'          , Map = 6, CoordX = 38, CoordY = 84, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena5'          , Map = 6, CoordX = 20, CoordY = 83, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena6'          , Map = 6, CoordX = 20, CoordY = 65, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena7'          , Map = 6, CoordX = 20, CoordY = 47, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena8'          , Map = 6, CoordX = 40, CoordY = 10, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena9'          , Map = 6, CoordX = 60, CoordY = 7, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}       ,
{Move = '/arena10'         , Map = 6, CoordX = 90, CoordY = 40, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}      ,
{Move = '/arena11'         , Map = 6, CoordX = 90, CoordY = 115, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/npcpk'           , Map = 6, CoordX = 56, CoordY = 164, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/atlans'          , Map = 7, CoordX = 26, CoordY = 18, MinLevel = 60, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/atlans3'         , Map = 7, CoordX = 63, CoordY = 163, MinLevel = 60, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/tarkan'          , Map = 8, CoordX = 196, CoordY = 62, MinLevel = 130, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/tarkan2'         , Map = 8, CoordX = 30, CoordY = 225, MinLevel = 130, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/icarus'          , Map = 10, CoordX = 14, CoordY = 13, MinLevel = 160, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}    ,
{Move = '/halloween'       , Map = 86, CoordX = 123, CoordY = 48, MinLevel = 1, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/chaoshallo1'      , Map = 86, CoordX = 124, CoordY = 11, MinLevel = 1, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/chaoshallo2'      , Map = 86, CoordX = 103, CoordY = 68, MinLevel = 1, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,
{Move = '/pvphallo'      	, Map = 86, CoordX = 125, CoordY = 26, MinLevel = 1, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,

{Move = '/evento'          , Map = 2, CoordX = 209, CoordY = 87, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,

{Move = '/mobs'          , Map = 6, CoordX = 209, CoordY = 32, MinLevel = 50, MaxLevel = -1, VipType = 0, Price = 100000, Pk = 1, MinReset = -1, MaxReset = -1, MinMReset = -1, MaxMReset = -1}     ,

}


--[[
Message Config
]]--
MOVE_CUSTOM_MESSAGE = { }

MOVE_CUSTOM_MESSAGE["Por"] = {
[1] = "[Sistema] Voc� est� impossibilitado de mover no momento!",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa estar abaixo do level %d",
[4] = "[Sistema] Voc� precisa de Wing ou Dinorant para mover neste local.",
[5] = "[Sistema] Voc� n�o pode mover para este local com montarias.",
[6] = "[Sistema] Voc� precisa de privil�gios vip para mover-se",
[7] = "[Sistema] Voc� precisa de %d zen para mover-se",
[8] = "[Sistema] Assasinos n�o podem utilizar este move!",
[9] = "[Sistema] Voc� precisa ter acima de %d resets para mover-se",
[10] = "[Sistema] Voc� precisa estar abaixo de %d resets para mover-se",
[11] = "[Sistema] Voc� precisa ter acima de %d M.Resets para mover-se",
[12] = "[Sistema] Voc� precisa estar abaixo de %d M.Resets para mover-se",
}

MOVE_CUSTOM_MESSAGE["Eng"] = {
[1] = "[Sistema] Voc� est� impossibilitado de mover no momento!",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa estar abaixo do level %d",
[4] = "[Sistema] Voc� precisa de Wing ou Dinorant para mover neste local.",
[5] = "[Sistema] Voc� n�o pode mover para este local com montarias.",
[6] = "[Sistema] Voc� precisa de privil�gios vip para mover-se",
[7] = "[Sistema] Voc� precisa de %d zen para mover-se",
[8] = "[Sistema] Assasinos n�o podem utilizar este move!",
[9] = "[Sistema] Voc� precisa ter acima de %d resets para mover-se",
[10] = "[Sistema] Voc� precisa estar abaixo de %d resets para mover-se",
[11] = "[Sistema] Voc� precisa ter acima de %d M.Resets para mover-se",
[12] = "[Sistema] Voc� precisa estar abaixo de %d M.Resets para mover-se",
}

MOVE_CUSTOM_MESSAGE["Spn"] = {
[1] = "[Sistema] Voc� est� impossibilitado de mover no momento!",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa estar abaixo do level %d",
[4] = "[Sistema] Voc� precisa de Wing ou Dinorant para mover neste local.",
[5] = "[Sistema] Voc� n�o pode mover para este local com montarias.",
[6] = "[Sistema] Voc� precisa de privil�gios vip para mover-se",
[7] = "[Sistema] Voc� precisa de %d zen para mover-se",
[8] = "[Sistema] Assasinos n�o podem utilizar este move!",
[9] = "[Sistema] Voc� precisa ter acima de %d resets para mover-se",
[10] = "[Sistema] Voc� precisa estar abaixo de %d resets para mover-se",
[11] = "[Sistema] Voc� precisa ter acima de %d M.Resets para mover-se",
[12] = "[Sistema] Voc� precisa estar abaixo de %d M.Resets para mover-se",
}