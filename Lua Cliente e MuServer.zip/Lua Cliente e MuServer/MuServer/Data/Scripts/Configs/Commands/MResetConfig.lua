--[[
Command Configs
]]--

--## CONFIGURAÇÃO PREMIO POR MARSTER RESET ##--

PRIZE_SWITCH	= true	-- true = premio ativado, false = premio desativado
PRIZE_TYPE		= 0		-- 0 = da apenas um item da lista, 1 da todos os itens da lista

--Sectiond o item
--Index do item
-- Level do item
-- Durabilidade do item
-- Skill ( 1 sim, 0 não)
-- Luck ( 1 sim, 0 não)
-- Option ( 0 sme option, de 1 a 7 com option)
-- Exc ( 0 não excelente, 63 = full)
-- Quantidade
PRIZE_CONFIG = {
{Section = 14, Index = 295, Level = 0, Dur = 0, Skill = 0, Luck = 0, Opt = 0, Exc = 0, Count = 1},

}

--Configurações Npc Master Reset
MRESET_NPC_SWITCH = 1
MRESET_NPC = { 
{Class = 236, Map = 3, CoordX = 193, CoordY = 114, Dir = 3}, 
}

--Configurações sistema Master Reset
MRESET_COMMAND = "/mrsmr"
MRESET_SWITCH = 1

--Level necessário
MRESET_LEVEL = {}
MRESET_LEVEL[0] = 400
MRESET_LEVEL[1] = 300
MRESET_LEVEL[2] = 350
MRESET_LEVEL[3] = 300

--Zen necessário
MRESET_MONEY = {}
MRESET_MONEY[0] = 0
MRESET_MONEY[1] = 0
MRESET_MONEY[2] = 0
MRESET_MONEY[3] = 0

--Resetar o level up points? se sim vai ser colocado o level up com a configuração MRESET_POINTS_LEVEL_UP_AFTER
MRESET_LEVEL_UP_POINTS_RESET = {}
MRESET_LEVEL_UP_POINTS_RESET[0] = 1
MRESET_LEVEL_UP_POINTS_RESET[1] = 1
MRESET_LEVEL_UP_POINTS_RESET[2] = 1
MRESET_LEVEL_UP_POINTS_RESET[3] = 1

-- Força necessária para dar MR
MRESET_POINTS_STRENGTH = {}
MRESET_POINTS_STRENGTH[0] = 32767
MRESET_POINTS_STRENGTH[1] = 32767
MRESET_POINTS_STRENGTH[2] = 32767
MRESET_POINTS_STRENGTH[3] = 32767

-- Agilidade necessária para dar MR
MRESET_POINTS_DEXTERITY = {}
MRESET_POINTS_DEXTERITY[0] = 32767
MRESET_POINTS_DEXTERITY[1] = 32767
MRESET_POINTS_DEXTERITY[2] = 32767
MRESET_POINTS_DEXTERITY[3] = 32767

-- Vitalidade necessária para dar MR
MRESET_POINTS_VITALITY = {}
MRESET_POINTS_VITALITY[0] = 32767
MRESET_POINTS_VITALITY[1] = 32767
MRESET_POINTS_VITALITY[2] = 32767
MRESET_POINTS_VITALITY[3] = 32767

-- Energia necessária para dar MR
MRESET_POINTS_ENERGY = {}
MRESET_POINTS_ENERGY[0] = 32767
MRESET_POINTS_ENERGY[1] = 32767
MRESET_POINTS_ENERGY[2] = 32767
MRESET_POINTS_ENERGY[3] = 32767

-- Comando necessário para dar MR
MRESET_POINTS_LEADERSHIP = {}
MRESET_POINTS_LEADERSHIP[0] = 32767
MRESET_POINTS_LEADERSHIP[1] = 32767
MRESET_POINTS_LEADERSHIP[2] = 32767
MRESET_POINTS_LEADERSHIP[3] = 32767

--mínimo de resets para dar o MR
MRESET_MIN_RESETS = {}
MRESET_MIN_RESETS[0] = 0
MRESET_MIN_RESETS[1] = 0
MRESET_MIN_RESETS[2] = 0
MRESET_MIN_RESETS[3] = 0

--Remover resets?
MRESET_CHARGE_RESETS = {}
MRESET_CHARGE_RESETS[0] = 0
MRESET_CHARGE_RESETS[1] = 0
MRESET_CHARGE_RESETS[2] = 0
MRESET_CHARGE_RESETS[3] = 0

--Caso cobre resets quantos resets será removidos?
MRESETS_REMOVE_RESETS = {}
MRESETS_REMOVE_RESETS[0] = 0
MRESETS_REMOVE_RESETS[1] = 0
MRESETS_REMOVE_RESETS[2] = 0
MRESETS_REMOVE_RESETS[3] = 0

--Level após o MR
MRESET_LEVEL_AFTER = {}
MRESET_LEVEL_AFTER[0] = 1
MRESET_LEVEL_AFTER[1] = 6
MRESET_LEVEL_AFTER[2] = 15
MRESET_LEVEL_AFTER[3] = 15

--Level up points após o MR
MRESET_POINTS_LEVEL_UP_AFTER = {}
MRESET_POINTS_LEVEL_UP_AFTER[0] = 0
MRESET_POINTS_LEVEL_UP_AFTER[1] = 0
MRESET_POINTS_LEVEL_UP_AFTER[2] = 0
MRESET_POINTS_LEVEL_UP_AFTER[3] = 0

--Força após o MR
MRESET_POINTS_STRENGTH_AFTER = {}
MRESET_POINTS_STRENGTH_AFTER[0] = 100
MRESET_POINTS_STRENGTH_AFTER[1] = 200
MRESET_POINTS_STRENGTH_AFTER[2] = 300
MRESET_POINTS_STRENGTH_AFTER[3] = 350

--Agilidade após o MR
MRESET_POINTS_DEXTERITY_AFTER = {}
MRESET_POINTS_DEXTERITY_AFTER[0] = 100
MRESET_POINTS_DEXTERITY_AFTER[1] = 200
MRESET_POINTS_DEXTERITY_AFTER[2] = 300
MRESET_POINTS_DEXTERITY_AFTER[3] = 350

--Vitalidade após o MR
MRESET_POINTS_VITALITY_AFTER = {}
MRESET_POINTS_VITALITY_AFTER[0] = 100
MRESET_POINTS_VITALITY_AFTER[1] = 200
MRESET_POINTS_VITALITY_AFTER[2] = 300
MRESET_POINTS_VITALITY_AFTER[3] = 350

--Energia após o MR
MRESET_POINTS_ENERGY_AFTER = {}
MRESET_POINTS_ENERGY_AFTER[0] = 100
MRESET_POINTS_ENERGY_AFTER[1] = 200
MRESET_POINTS_ENERGY_AFTER[2] = 300
MRESET_POINTS_ENERGY_AFTER[3] = 350

--Comando após o  MR (para DL)
MRESET_POINTS_LEADERSHIP_AFTER = {}
MRESET_POINTS_LEADERSHIP_AFTER[0] = 100
MRESET_POINTS_LEADERSHIP_AFTER[1] = 200
MRESET_POINTS_LEADERSHIP_AFTER[2] = 300
MRESET_POINTS_LEADERSHIP_AFTER[3] = 350

--Retornar ao mapa?
MRESET_RETURN = {}
MRESET_RETURN[0] = 1
MRESET_RETURN[1] = 1
MRESET_RETURN[2] = 1
MRESET_RETURN[3] = 1

--Se sim, qual o mapa
MRESET_RETURN_MAP = {}
MRESET_RETURN_MAP[0] = 0
MRESET_RETURN_MAP[1] = 0
MRESET_RETURN_MAP[2] = 0
MRESET_RETURN_MAP[3] = 0

--Coordenada X
MRESET_RETURN_MAP_X = {}
MRESET_RETURN_MAP_X[0] = 125
MRESET_RETURN_MAP_X[1] = 125
MRESET_RETURN_MAP_X[2] = 125
MRESET_RETURN_MAP_X[3] = 125

--Coordenada Y
MRESET_RETURN_MAP_Y = {}
MRESET_RETURN_MAP_Y[0] = 125
MRESET_RETURN_MAP_Y[1] = 125
MRESET_RETURN_MAP_Y[2] = 125
MRESET_RETURN_MAP_Y[3] = 125

--Relogar ao dar MR?
MRESET_RELOGAR = {}
MRESET_RELOGAR[0] = 0
MRESET_RELOGAR[1] = 0
MRESET_RELOGAR[2] = 0
MRESET_RELOGAR[3] = 0

--Quantidade de MR ganha ao dar o MR no ranking
MRESET_COUNTS = {}
MRESET_COUNTS[0] = 1
MRESET_COUNTS[1] = 1
MRESET_COUNTS[2] = 1
MRESET_COUNTS[3] = 1

--Configuração de premiação em moedas, lembrando isso é direto para a conta!
--O exemplo abaixo mostra a premiação em duas moedas de duas colunas diferente!
MRESET_AMOUNT_TABLES = {}
MRESET_AMOUNT_TABLES[1] = 'CashShopData'
MRESET_AMOUNT_TABLES[2] = 'CashShopData'

MRESET_AMOUNT_COLUNS = {}
MRESET_AMOUNT_COLUNS[1] = 'WCoinP'
MRESET_AMOUNT_COLUNS[2] = 'WCoinC'

MRESET_AMOUNT_WHERE = {}
MRESET_AMOUNT_WHERE[1] = 'AccountID'
MRESET_AMOUNT_WHERE[2] = 'AccountID'

MRESET_AMOUNT = {}

--Free
MRESET_AMOUNT[0] = {
[1] = 0, --Premiação para a primeira moeda
[2] = 0, --Premiação para a segunda moeda
}
--Vip
MRESET_AMOUNT[1] = {
[1] = 0, --Premiação para a primeira moeda
[2] = 0, --Premiação para a segunda moeda
}
--Vip 1
MRESET_AMOUNT[2] = {
[1] = 0, --Premiação para a primeira moeda
[2] = 0, --Premiação para a segunda moeda
}
--Vip 2
MRESET_AMOUNT[3] = {
[1] = 0, --Premiação para a primeira moeda
[2] = 0, --Premiação para a segunda moeda
}

--[[
Message Configs
]]--
MRESETS_MESSAGES = { }

MRESETS_MESSAGES["Por"] = {
[1] = "[Sistema] Você precisa de %d level para dar M.Reset",
[2] = "[Sistema] Você precisa de %d zen para dar M.Reset",
[3] = "[Sistema] Você precisa de %d pontos em força",
[4] = "[Sistema] Você precisa de %d pontos em Agilidade",
[5] = "[Sistema] Você precisa de %d pontos em Vitalidade",
[6] = "[Sistema] Você precisa de %d pontos em Energia",
[7] = "[Sistema] Você precisa ter %d resets para dar M.Reset",
[8] = "[Sistema] Master Resetado com sucesso!",
[9] = "[Sistema] Não foi possível efetuar o M.reset",
[10] = "[Sistema] Você precisa de %d pontos em Comando",
}

MRESETS_MESSAGES["Eng"] = {
[1] = "[System] You need %d level to give M.Reset",
[2] = "[System] You need %d zen to give M.Reset",
[3] = "[System] You need %d points in strength",
[4] = "[System] You need %d points in Agility",
[5] = "[System] You need %d points on Vitality",
[6] = "[System] You need %d points in Energy",
[7] = "[System] You need to have %d resets to give M.Reset",
[8] = "[System] Master successfully reset!",
[9] = "[System] M.reset could not be performed",
[10] = "[System] You need %d points in LeaderShip",
}

MRESETS_MESSAGES["Spn"] = {
[1] = "[Sistema] Necesitas %d nivel para dar M.Reset",
[2] = "[Sistema] Necesitas %d zen para dar M.Reset",
[3] = "[Sistema] Necesitas %d puntos de fuerza",
[4] = "[Sistema] Necesitas %d puntos en Agilidad",
[5] = "[Sistema] Necesitas %d puntos en Vitality",
[6] = "[Sistema] Necesitas %d puntos en energía",
[7] = "[Sistema] Debes tener %d restablecimientos para proporcionar M.Reset",
[8] = "¡[Sistema] Maestro se reinició correctamente!",
[9] = "[System] No se pudo realizar M.reset",
[10] = "[Sistema] Necesitas %d puntos en comando",
}