--[[
Command Configs
]]--
ZEN_COMMAND = "/zen"
ZEN_SWITCH = 1
ZEN_LEVEL = 1
ZEN_RESETS = 0
ZEN_MRESETS = 0
ZEN_VIP = 0
ZEN_MAXMONEY = 2000000000

--[[
Message Configs
]]--
ZEN_MESSAGES = { }

ZEN_MESSAGES["Por"] = {
[1] = "[Sistema] Voc� precisa estar acima do level %d",
[2] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[3] = "[Sistema] Voc� precisa de %d resets",
[4] = "[Sistema] Voc� precisa de %d M.Resets",
[5] = "[Sistema] Zen adicionado com sucesso!",
}

ZEN_MESSAGES["Eng"] = {
[1] = "[Sistema] Voc� precisa estar acima do level %d",
[2] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[3] = "[Sistema] Voc� precisa de %d resets",
[4] = "[Sistema] Voc� precisa de %d M.Resets",
[5] = "[Sistema] Zen adicionado com sucesso!",
}

ZEN_MESSAGES["Spn"] = {
[1] = "[Sistema] Voc� precisa estar acima do level %d",
[2] = "[Sistema] Somente usu�rios vip podem usar este comando!",
[3] = "[Sistema] Voc� precisa de %d resets",
[4] = "[Sistema] Voc� precisa de %d M.Resets",
[5] = "[Sistema] Zen adicionado com sucesso!",
}