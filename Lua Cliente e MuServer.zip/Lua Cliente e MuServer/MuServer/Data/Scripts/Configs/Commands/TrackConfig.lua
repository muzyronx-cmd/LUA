--[[
Commands Configs
]]--
TRACK_COMMAND = "/track"
TRACK_SWITCH = 1
TRACK_GAME_MASTER_LEVEL = 1

--[[
Message Configs
]]--
TRACK_MESSAGES = { }

TRACK_MESSAGES["Por"] = {
[1] = "[Sistema] %s est� offline ou n�o existe",
}

TRACK_MESSAGES["Eng"] = {
[1] = "[Sistema] %s est� offline ou n�o existe",
}

TRACK_MESSAGES["Spn"] = {
[1] = "[Sistema] %s est� offline ou n�o existe",
}