--[[
Commands Config
]]--
--Configura��es comando /bonus
REWARD_COMMAND = "/bonus"
REWARD_INVENTORY = 1
REWARD_SWITCH = 1
REWARD_COUNTS = 5 -- Vezes que o player pode usar o comando na conta!

--Class Classe que vai receber o b�nus, 0 - SM | 1 - BK | 2 - ELF | 3 - MG

REWARD_ITEMS = {
--/////// SM
{Class = 0, ItemSection = 5, ItemIndex = 5,  Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 6, ItemIndex = 14,  Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},


{Class = 0, ItemSection = 7, ItemIndex = 3, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 8, ItemIndex = 3, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 9, ItemIndex = 3, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 10,ItemIndex = 3, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 11,ItemIndex = 3, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 12,ItemIndex = 372, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 15,ItemIndex = 8,   Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 0, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 0, ItemSection = 13,ItemIndex = 26, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},

{Class = 1, ItemSection = 0, ItemIndex = 16,  Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 6, ItemIndex = 12, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 7, ItemIndex = 0, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 8, ItemIndex = 0, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 9, ItemIndex = 0, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 10,ItemIndex = 0, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 11,ItemIndex = 0, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 12,ItemIndex = 370, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 13,ItemIndex = 26, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 1, ItemSection = 12,ItemIndex = 7,   Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 1, ItemSection = 12,ItemIndex = 19,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},

{Class = 2, ItemSection = 4, ItemIndex = 17, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 7, ItemIndex = 10, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 8, ItemIndex = 10, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 9, ItemIndex = 10, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 10,ItemIndex = 10, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 11,ItemIndex = 10, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 12,ItemIndex = 371, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 13,ItemIndex = 26, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 2, ItemSection = 12,ItemIndex = 8,   Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 2, ItemSection = 12,ItemIndex = 9,   Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 2, ItemSection = 12,ItemIndex = 10,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 2, ItemSection = 12,ItemIndex = 11,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 2, ItemSection = 12,ItemIndex = 12,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 2, ItemSection = 12,ItemIndex = 13,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 2, ItemSection = 12,ItemIndex = 14,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},

{Class = 3, ItemSection = 5, ItemIndex = 6,  Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 3, ItemSection = 6, ItemIndex = 15, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},

{Class = 3, ItemSection = 8, ItemIndex = 20, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 3, ItemSection = 9, ItemIndex = 20, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 3, ItemSection = 10,ItemIndex = 20, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 3, ItemSection = 11,ItemIndex = 20, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},

{Class = 3, ItemSection = 12,ItemIndex = 373, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},

{Class = 3, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 3, ItemSection = 13,ItemIndex = 9, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 3, ItemSection = 13,ItemIndex = 26, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},

{Class = 3, ItemSection = 12,ItemIndex = 7,   Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 3, ItemSection = 15,ItemIndex = 8,   Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},

{Class = 4, ItemSection = 0, ItemIndex = 37,  Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 6, ItemIndex = 209, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 7, ItemIndex = 209, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 8, ItemIndex = 209, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 9, ItemIndex = 209, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 10,ItemIndex = 209, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 11,ItemIndex = 209, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 12,ItemIndex = 214, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 13,ItemIndex = 157, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 13,ItemIndex = 157, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 13,ItemIndex = 158, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 13,ItemIndex = 212, Level = 15, Luck = 1, Skill = 1, Option = 7, Exc1 = 1, Exc2 = 1, Exc3 = 1, Exc4 = 1, Exc5 = 1, Exc6 = 1},
{Class = 4, ItemSection = 12,ItemIndex = 21,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 4, ItemSection = 12,ItemIndex = 22,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 4, ItemSection = 12,ItemIndex = 23,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 4, ItemSection = 12,ItemIndex = 24,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},
{Class = 4, ItemSection = 12,ItemIndex = 35,  Level = 0 , Luck = 0, Skill = 0, Option = 0, Exc1 = 0, Exc2 = 0, Exc3 = 0, Exc4 = 0, Exc5 = 0, Exc6 = 0},

}



--[[
Message Configs
]]--
REWARD_MESSAGES = { }

REWARD_MESSAGES["Por"] = {
[1] = "[Sistema] Voc� j� utilizou seu b�nus!",
[2] = "[Sistema] Seu invent�rio precisa estar vazio!",
[3] = "[Sistema] Sua recompensa foi colocado no invent�rio!",
[4] = "[Sistema] Pegue sua recompensa no ch�o!",
}

REWARD_MESSAGES["Eng"] = {
[1] = "[Sistema] Voc� j� utilizou seu b�nus!",
[2] = "[Sistema] Seu invent�rio precisa estar vazio!",
[3] = "[Sistema] Sua recompensa foi colocado no invent�rio!",
[4] = "[Sistema] Pegue sua recompensa no ch�o!",
}

REWARD_MESSAGES["Spn"] = {
[1] = "[Sistema] Voc� j� utilizou seu b�nus!",
[2] = "[Sistema] Seu invent�rio precisa estar vazio!",
[3] = "[Sistema] Sua recompensa foi colocado no invent�rio!",
[4] = "[Sistema] Pegue sua recompensa no ch�o!",
}