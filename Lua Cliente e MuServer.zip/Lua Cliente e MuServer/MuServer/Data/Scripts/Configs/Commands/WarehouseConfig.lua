--[[
Command Configs
]]--
MULT_VAULT_COMMAND = "/bau"
MULT_VAULT_SWITCH = 500
MULT_VAULT_LEVEL = 1
MULT_VAULT_RESETS = 0
MULT_VAULT_MRESETS = 0
MULT_VAULT_VIP = 0
MULT_VAULT_MONEY = 1000000
--Type 1 = quantia de ba�s atrav�s da coluna, Type = 1 quantia de baus por vip
MULT_VAULT_TYPE = 1
-- Quantia de baus por vip apenas se o Type for 1
MULT_VAULT_COUNT = {}
MULT_VAULT_COUNT[0] = 10
MULT_VAULT_COUNT[1] = 500
MULT_VAULT_COUNT[2] = 500

--Open vault
OPEN_VAULT_COMMAND = "/abrirbau"
OPEN_VAULT_SWITCH = 0
OPEN_VAULT_LEVEL = 1
OPEN_VAULT_RESETS = 0
OPEN_VAULT_MRESETS = 0
OPEN_VAULT_VIP = 0
OPEN_VAULT_MONEY = 1000000

--[[
Message Configs
]]--
WAREHOUSE_MESSAGES = { }

WAREHOUSE_MESSAGES["Por"] = {
[1] = "[Sistema] Coloque um n�mero v�lido!",
[2] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[3] = "[Sistema] Voc� precisa estar acima do level %d",
[4] = "[Sistema] Voc� precisa de %d zen",
[5] = "[Sistema] Voc� n�o tem privil�gios vip para utilizar este comando.",
[6] = "[Sistema] Voc� precisa de %d resets",
[7] = "[Sistema] Voc� precisa de %d M.Resets",
[8] = "[Sistema] Houve um problema ao identificar os baus, contate o administrador.",
[9] = "[Sistema] Seu plano n�o possu� essa quantidade de ba�s.",
[10] = "[Sistema] Ba� trocado com sucesso!",
}

WAREHOUSE_MESSAGES["Eng"] = {
[1] = "[Sistema] Coloque um n�mero v�lido!",
[2] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[3] = "[Sistema] Voc� precisa estar acima do level %d",
[4] = "[Sistema] Voc� precisa de %d zen",
[5] = "[Sistema] Voc� n�o tem privil�gios vip para utilizar este comando.",
[6] = "[Sistema] Voc� precisa de %d resets",
[7] = "[Sistema] Voc� precisa de %d M.Resets",
[8] = "[Sistema] Houve um problema ao identificar os baus, contate o administrador.",
[9] = "[Sistema] Seu plano n�o possu� essa quantidade de ba�s.",
[10] = "[Sistema] Ba� trocado com sucesso!",
}

WAREHOUSE_MESSAGES["Spn"] = {
[1] = "[Sistema] Coloque um n�mero v�lido!",
[2] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[3] = "[Sistema] Voc� precisa estar acima do level %d",
[4] = "[Sistema] Voc� precisa de %d zen",
[5] = "[Sistema] Voc� n�o tem privil�gios vip para utilizar este comando.",
[6] = "[Sistema] Voc� precisa de %d resets",
[7] = "[Sistema] Voc� precisa de %d M.Resets",
[8] = "[Sistema] Houve um problema ao identificar os baus, contate o administrador.",
[9] = "[Sistema] Seu plano n�o possu� essa quantidade de ba�s.",
[10] = "[Sistema] Ba� trocado com sucesso!",
}

OPEN_WAREHOUSE_MESSAGES = { }

OPEN_WAREHOUSE_MESSAGES["Por"] = {
[1] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Voc� n�o tem privil�gios vip para utilizar este comando.",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
}

OPEN_WAREHOUSE_MESSAGES["Eng"] = {
[1] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Voc� n�o tem privil�gios vip para utilizar este comando.",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
}

OPEN_WAREHOUSE_MESSAGES["Spn"] = {
[1] = "[Sistema] Feche outras janelas para realizar essa a��o.",
[2] = "[Sistema] Voc� precisa estar acima do level %d",
[3] = "[Sistema] Voc� precisa de %d zen",
[4] = "[Sistema] Voc� n�o tem privil�gios vip para utilizar este comando.",
[5] = "[Sistema] Voc� precisa de %d resets",
[6] = "[Sistema] Voc� precisa de %d M.Resets",
}