ExchangeItem_Config = {
    Enabled = false,

    Command = {
        ["Eng"] = "/trocar",
        ["Por"] = "/trocar",
        ["Spn"] = "/trocar"
    },

    Item = {
        ["hp"] =   {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
        ["hp5"] =  {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
        ["hp10"] = {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
        ["hp20"] = {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
        ["hp30"] = {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
        ["hp40"] = {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
        ["hp50"] = {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
        ["hp64"] = {Name = "Golds", Section = 13, Index = 52, Level = -1, Value = 1, Coin = 1000000},
    },

    Coin = {
        [1] = {Name = "Hpoints", Table = "CashShopData", Column = "WcoinP", Where = "AccountID", IdType = 0},
    },

    Message = {
        ["Eng"] = {
            [1] = " Item n�o encontrado ",
            [2] = " %d %s trocado por %d %s ",
            [3] = " 0 %s encontrados no invent�rio ",
        },

        ["Por"] = {
            [1] = " Item n�o encontrado ",
            [2] = " %d %s trocado por %d %s ",
            [3] = " 0 %s encontrados no invent�rio ",
        },

        ["Spn"] = {
            [1] = " Item n�o encontrado ",
            [2] = " %d %s trocado por %d %s ",
            [3] = " 0 %s encontrados no invent�rio ",
        },
    }

}

return ExchangeItem_Config