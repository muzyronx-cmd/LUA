--[[
System config tips
]]--

TIPS_SWITCH = 0
TIPS_COLOR = 2
TIPS_TIMER_INTERVAL = 5 * 120

TIPS_CONFIGURATIONS = { }

TIPS_CONFIGURATIONS["Por"] = {
{1, '[Dica]:Cuidado n�o empreste itens a ningu�m!'},
{2, '[Dica]:A STAFF n�o pede itens!'},
{3, '[Dica]:Utilize o Auto Potion F6!'},
{4, '[Dica]:Para Mover utilize a Tecla M!'},
}

TIPS_CONFIGURATIONS["Eng"] = {
{1, '[Dica]:Cuidado n�o empreste itens a ningu�m!'},
{2, '[Dica]:A STAFF n�o pede itens!'},
{3, '[Dica]:Utilize o Auto Potion F6!'},
{4, '[Dica]:Para Mover utilize a Tecla M!'},
}

TIPS_CONFIGURATIONS["Spn"] = {
{1, '[Dica]:Cuidado n�o empreste itens a ningu�m!'},
{2, '[Dica]:A STAFF n�o pede itens!'},
{3, '[Dica]:Utilize o Auto Potion F6!'},
{4, '[Dica]:Para Mover utilize a Tecla M!'},
}