-- BootSystem v2. Contas EXCLUSIVAS para bots, ja existentes no banco.
BOOT_SYSTEM_SWITCH = 1
BOOT_SYSTEM_CONFIG = {
    ReconnectSeconds = 30,
    LoginTimeoutSeconds = 30,
    CharacterDelaySeconds = 2,
    SummarySeconds = 60,
}

-- Copie aqui sua lista atual. Uma entrada por conta; nao divulgue as senhas.
InjectPlayers = {
     {Account = "a", Password = "a", Character = "ajak"},
	 {Account = "nelsinho", Password = "65254310", Character = "XuPaTeTa"},
	 {Account = "nelsinhohj", Password = "65254310", Character = "GeLaDoOoO"},
	 {Account = "muzyron", Password = "123456", Character = "MagoZyron"},	 
}
