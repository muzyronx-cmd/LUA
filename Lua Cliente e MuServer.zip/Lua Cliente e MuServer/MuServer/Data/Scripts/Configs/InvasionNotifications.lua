InvasionNotifications_Config = {
    Enabled = true,
    Packet = 217, -- Mesmo numero no cliente; reserve este packet no seu servidor.
    RequestCooldown = 2, -- segundos por personagem
    Debug = true, -- Loga carga, agenda e primeira resposta de cada sessao.
    -- Opcional: nomes fixos para classes (inclusive quando todos morrerem).
    MonsterNames = {},
}
