-- Configuracao principal. Reinicie o GameServer depois de editar.
LuckyRouletteConfig = {
    Enabled = true,
    Debug = true, -- Mostra clique e confirmacao do cliente no log do GameServer.
    Packet = 218,

    -- Use o numero do NPC em Monster.txt e sua posicao no MonsterSetBase.
    -- O script habilita o clique, mas o NPC precisa existir no mapa.
    -- Nao use o mesmo NPC/posicao de outro sistema (ex.: GiroDaSorte).
    NPC = {
        Class = 231,
        Map = 0,
        X = 130,
        Y = 133,
        Distance = 3,          -- Distancia maxima do jogador ao NPC.
        PositionTolerance = 2, -- Aceita NPC ate 2 coordenadas da posicao. 0 = exata.
    },

    Currency = {
        Cash = {Name = "Cash", Table = "MEMB_INFO", Column = "cash", Key = "memb___id", Character = false},
        Gold = {Name = "Gold", Table = "MEMB_INFO", Column = "gold", Key = "memb___id", Character = false},
    },

    -- ITENS: Section = categoria do Item.txt; Index = indice dentro da categoria.
    -- Exemplo: Jewel of Bless = Section 14, Index 13. Nao precisa fazer calculo.
    -- Weight = peso do sorteio: 70 e 30 representam 70% e 30%.
    -- Level = nivel; Skill/Luck = 0 sem, 1 com; Option = adicional.
    -- Excellent = soma das opcoes: 1, 2, 4, 8, 16 e 32. Todas = 63.
    -- FULL (equipamentos): Level=13, Skill=1, Luck=1, Option=7, Excellent=63.
    -- SEMI (exemplo): Level=9, Skill=1, Luck=0, Option=4, Excellent=7.
    -- Ajuste nivel/adicional ao limite da sua versao. Joias usam opcoes 0.
    -- IDs de roletas devem ser unicos (1..255). Maximo 32 roletas, 64 premios cada.
    Roulettes = {
        {
            ID = 1,
            Name = "Roleta Classica",
            Currency = "Cash",
            Price = 50,
            Cooldown = 5,
            Items = {
                {
                    Name = "Jewel of Bless",
                    Section = 14,
                    Index = 13,
                    Weight = 70,
                    Level = 0,
                    Durability = 0,
                    Skill = 0,
                    Luck = 0,
                    Option = 0,
                    Excellent = 0,
                },
                {
                    Name = "Jewel of Soul",
                    Section = 14,
                    Index = 14,
                    Weight = 30,
                    Level = 0,
                    Durability = 0,
                    Skill = 0,
                    Luck = 0,
                    Option = 0,
                    Excellent = 0,
                },
            },
        },
        {
            ID = 2,
            Name = "Roleta Vip",
            Currency = "Gold",
            Price = 100,
            Cooldown = 5,
            Items = {
                {
                    Name = "Sword of War [RL]",
                    Section = 0,
                    Index = 185,
                    Weight = 1,
                    Level = 15,
                    Durability = 255,
                    Skill = 1,
                    Luck = 1,
                    Option = 7,
                    Excellent = 63,
                },
                {
                    Name = "Sword of Majestyc [RL]",
                    Section = 0,
                    Index = 59,
                    Weight = 1,
                    Level = 15,
                    Durability = 255,
                    Skill = 1,
                    Luck = 1,
                    Option = 7,
                    Excellent = 63,
                },
                {
                    Name = "Sword of Style [RL]",
                    Section = 0,
                    Index = 54,
                    Weight = 1,
                    Level = 15,
                    Durability = 255,
                    Skill = 1,
                    Luck = 1,
                    Option = 7,
                    Excellent = 63,
                },
                {
                    Name = "Sword of Kriss [RL]",
                    Section = 0,
                    Index = 0,
                    Weight = 1,
                    Level = 15,
                    Durability = 255,
                    Skill = 1,
                    Luck = 1,
                    Option = 7,
                    Excellent = 63,
                },				
            },
        },
        {
            ID = 3,
            Name = "Roleta Free",
            Currency = "Cash",
            Price = 0,
            Cooldown = 86400,
            Items = {
                {
                    Name = "Jewel of Chaos",
                    Section = 12,
                    Index = 15,
                    Weight = 1,
                    Level = 0,
                    Durability = 0,
                    Skill = 0,
                    Luck = 0,
                    Option = 0,
                    Excellent = 0,
                },
            },
        },
        {
            ID = 4,
            Name = "Roleta Donate",
            Currency = "Gold",
            Price = 50,
            Cooldown = 5,
            Items = {
                {
                    Name = "Jewel of Bless",
                    Section = 14,
                    Index = 13,
                    Weight = 1,
                    Level = 0,
                    Durability = 0,
                    Skill = 0,
                    Luck = 0,
                    Option = 0,
                    Excellent = 0,
                },
            },
        },
    },
}
