QUEST_SYSTEM_NPC_SWITCH = 1

QUEST_SYSTEM_NPC_ONLY_ACCOUNT =   1 -- se = 1, a quest ser� apenas por conta, se for 0, � por personagem
QUEST_SYSTEM_NPC_REMOVE_RESETS =  0
QUEST_SYSTEM_NPC_REMOVE_MRESETS = 0
QUEST_SYSTEM_NPC_REMOVE_COIN1 =   0
QUEST_SYSTEM_NPC_REMOVE_COIN2 =   0
QUEST_SYSTEM_NPC_REMOVE_COIN3 =   0

QUEST_SYSTEM_NPC_ONLY_ONE_QUEST = 0 -- se = 1, quando o jogador inicia uma miss�o e cancela ou termina ele n�o pode come�ar novamente

--Npc Identification
QUEST_SYSTEM_NPC_LOCATION_INFO = {}

QUEST_SYSTEM_NPC_LOCATION_INFO = {

    { Class = 245, Map = 0,  CoordX = 137,  CoordY = 140 ,  QuestIdentification = 1},
    { Class = 245, Map = 0,  CoordX = 130,  CoordY = 125 ,  QuestIdentification = 2},

	
}

--Identification of the quest
QUEST_SYSTEM_NPC_INFO = {}
QUEST_SYSTEM_NPC_INFO = {

-- QUEST OF LORENCIA

    { QuestIdentification = 1, Level = 400, Reset = 0, 	  MReset = 0, Zen = 0,    Coin1 = 0, Coin2 = 0, Coin3 = 0, Vip = 0, Kills = 0, QuestName = 'Quest Jewel Bronze',   			 		 Validity = '30/02/2027' },

}

-- PARTE ONDE VOC� COLOCA OS ITENS NECESS�RIO PARA CADA QUEST
QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS = {}

QUEST_SYSTEM_NPC_REQUIREMENTS_ITEMS[1] = {
    { ItemIndex = GET_ITEM(7, 0),   Level =  15,  Luck = -1, Skill = -1,   Quantity = 1 },
    { ItemIndex = GET_ITEM(8, 0),   Level =  15,  Luck = -1, Skill = -1,   Quantity = 1 },
    { ItemIndex = GET_ITEM(9, 0),   Level =  15,  Luck = -1, Skill = -1,   Quantity = 1 },
    { ItemIndex = GET_ITEM(10, 0),   Level =  15,  Luck = -1, Skill = -1,   Quantity = 1 },
    { ItemIndex = GET_ITEM(11, 0),   Level =  15,  Luck = -1, Skill = -1,   Quantity = 1 },
    { ItemIndex = GET_ITEM(13, 212),   Level =  15,  Luck = -1, Skill = -1,   Quantity = 1 },
}


-- PARTE ONDE VOC� COLOCA A QUANTIDADE DE MONSTROS NECESS�RIOS (M�XIMO 9)
QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER = {}

--[1] = QUEST OF LORENCIA

--QUEST_SYSTEM_NPC_REQUIREMENTS_MONSTER[1] = {
--    { MonsterIndex = 410,  Quantity = 100 },
--    { MonsterIndex = 79,   Quantity = 100 },
--    { MonsterIndex = 309,   Quantity = 20 },
--    { MonsterIndex = 352,   Quantity = 20 },
--    { MonsterIndex = 275,   Quantity = 20 },
--    { MonsterIndex = 77,    Quantity = 20 },
--	
--}

-----
-- Reward player
-----
--Coins
--CoinIdentification: 1 = WcoinC, 2 = WcoinP, 3 = GlobinPoint
QUEST_SYSTEM_NPC_REWARD_COINS = {}
--[1] = QuestIdentification
--QUEST_SYSTEM_NPC_REWARD_COINS[1] = {
 --{ CoinName = 'hpoints', CoinAmount = 50, CoinIdentification = 1 },
--}

--[[
ItemTime: 0 = Eterno, tempo em segundos
DaysExpire: momento o item poder� ficar no npc de resgate, ap�s a pessoa n�o poder mais retirar
Class: -1 = todas as classes
]]--
QUEST_SYSTEM_NPC_REWARD_ITEMS = {}
--  QUEST 
QUEST_SYSTEM_NPC_REWARD_ITEMS[1] = {
    { ItemIndex = GET_ITEM(14, 153),  Level = 0, Op1 = 0, Op2 = 0, Life = 0, Exc = 0, Ancient = 0, JoH = 0, SocketBonus = 0, Sock1 = 0, Sock2 = 0, Sock3 = 0, Sock4 = 0, Sock5 = 0, ItemTime = 0, DaysExpire = 0, Name = 'Bronze of Jewel', Count = 1, Class = -1},

}

--Buffs
QUEST_SYSTEM_NPC_REWARD_BUFF = {}
-- (1) INDENTIFICA��O
-- O EFEITO � CONTABILIZADO POR SEGUNDOS

--QUEST_SYSTEM_NPC_REWARD_BUFF[1]  = {
 --   { EffectID = 29, EffectTime = 3600, BuffName = 'BUFF TOP QUEST' }
--}




QUEST_SYSTEM_NPC_PACKET = 0x04
QUEST_SYSTEM_NPC_PACKET_OPEN_NAME = 'QuestSystemNpcOpen'
QUEST_SYSTEM_NPC_PACKET_START_NAME = 'QuestSystemNpcStartQuest'
QUEST_SYSTEM_NPC_PACKET_GET_REWARD_NAME = 'QuestSystemNpcGetReward'
QUEST_SYSTEM_NPC_PACKET_DISMISS_QUEST_NAME = 'QuestSystemNpcDismissQuest'
QUEST_SYSTEM_NPC_PACKET_FINISHED_QUEST_NAME = 'QuestSystemNpcFinished'

QUEST_SYSTEM_NPC_MESSAGES = {}

QUEST_SYSTEM_NPC_MESSAGES['Por'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'N�o encontramos nenhuma quest dispon�vel no momento!',
[3] = 'Voc� iniciou a quest %s!',
[4] = 'N�o conseguimos identificar a sua quest!',
[5] = 'Voc� j� est� com uma quest ativa!',
[6] = 'Voc� precisa concluir todos os requisitos!',
[7] = 'Voc� recebeu %d %s',
[8] = 'Voc� j� concluiu todas as quests!',
[9] = '%s - %s (%d/%d)',
[10] = 'Voc� foi premiado com: %d %s',
}

QUEST_SYSTEM_NPC_MESSAGES['Eng'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'N�o encontramos nenhuma quest dispon�vel no momento!',
[3] = 'Voc� iniciou a quest %s!',
[4] = 'N�o conseguimos identificar a sua quest!',
[5] = 'Voc� j� est� com uma quest ativa!',
[6] = 'Voc� precisa concluir todos os requisitos!',
[7] = 'Voc� recebeu %d %s',
[8] = 'Voc� j� concluiu todas as quests!',
[9] = '%s - %s (%d/%d)',
[10] = 'Voc� foi premiado com: %d %s',
}

QUEST_SYSTEM_NPC_MESSAGES['Spn'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'N�o encontramos nenhuma quest dispon�vel no momento!',
[3] = 'Voc� iniciou a quest %s!',
[4] = 'N�o conseguimos identificar a sua quest!',
[5] = 'Voc� j� est� com uma quest ativa!',
[6] = 'Voc� precisa concluir todos os requisitos!',
[7] = 'Voc� recebeu %d %s',
[8] = 'Voc� j� concluiu todas as quests!',
[9] = '%s - %s (%d/%d)',
[10] = 'Voc� foi premiado com: %d %s',
}
