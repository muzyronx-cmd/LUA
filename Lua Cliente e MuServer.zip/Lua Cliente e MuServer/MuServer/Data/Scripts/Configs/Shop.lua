Shop_Config = {
    Enabled = true,

    Packet = 9,

    Coins = {
        [1] = {Name = "Cash", Table = "MEMB_INFO", Column = "cash", Where = "memb___id", IdType = 0},
        [2] = {Name = "Gold", Table = "MEMB_INFO", Column = "gold", Where = "memb___id", IdType = 0},
        [3] = {Name = "EventPoint", Table = "MEMB_INFO", Column = "EventPoint", Where = "memb___id", IdType = 0},
    },

    Message = {
        ["Eng"] = {
            [1] = "Item Shop Purchase",
        },
        ["Por"] = {
            [1] = "Compra na Loja de Itens",
        },
        ["Spn"] = {
            [1] = "Compra na Loja de Itens",
        },
    }
}

return Shop_Config