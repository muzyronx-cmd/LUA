--[[
Configs
]]--
NPC_RESCUE_ITEM_SWITCH = 1

NPC_RESCUE_PACKET = 2
NPC_RESCUE_PACKET_NAME_GET = 'NPC_RESCUE_ITEM_GET'
NPC_RESCUE_PACKET_GET_ITEM_RECV = 'NPC_RESCUE_GET_ITEM_RECV'

NPC_RESCUE_MONSTER_ID = 400

--[[
	Messages
]]--
NPC_RESCUE_MESSAGES = {}

NPC_RESCUE_MESSAGES['Por'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'Aguarde um tempo para falar com o npc novamente!',
[3] = 'Espera um pouco Gay!',
[4] = 'Esse item n�o existe em sua conta, ou j� foi retirado!',
[5] = 'Esvazie seu invent�rio para retirar o item!',
[6] = 'Ocorreu um erro ao retirar o item contate a administra��o!',
}

NPC_RESCUE_MESSAGES['Eng'] = {
[1] = 'Voc� est� ocupado no momento!',
[2] = 'Aguarde um tempo para falar com o npc novamente!',
[3] = 'Espera um pouco Gay!',
[4] = 'Esse item n�o existe em sua conta, ou j� foi retirado!',
[5] = 'Esvazie seu invent�rio para retirar o item!',
[6] = 'Ocorreu um erro ao retirar o item contate a administra��o!',
}

NPC_RESCUE_MESSAGES['Spn'] = {
[1] = '�Actualmente est�s ocupado!',
[2] = '�Espere un momento para volver a hablar con el npc!',
[3] = '�Espera un minuto!',
[4] = '�Este art�culo no existe en su cuenta o ya ha sido retirado!',
[5] = '�Vac�a tu inventario para eliminar el art�culo!',
[6] = 'Se produjo un error al eliminar el elemento, �comun�quese con la administraci�n!',
}
