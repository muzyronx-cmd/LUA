LEILAO_INFO_COMMAND		= "/leilaoinfo"		-- Informa o jogador qual o leilao em andamento, o lance minimo e como dar o lance.
LEILAO_REDEEM_COMMAND	= "/resgatarpremio"	-- Comando para resgatar o premio do leilao (premia��o caso use o leil�o autom�tico)

--Configura��o tempo do leil�o
LEILAO_TEMPO_MINUTOS	= 1		-- Tempo de dura��o do leil�o em minutos (minimo 1 minuto)
LEILAO_TEMPO_SEGUNDOS	= 10	-- Tempo de dura��o do leil�o em segundos (conta ap�s terminar o ultimo minuto)(minimo 10 segundos)
LEILAO_ANNOUNCE			= 1		-- Tempo que vai avisar antes de come�ar o leilao (em minutos) (minimo 1 minuto)

-- Configura��o de lance
LEILAO_BID_COMMAND				= "/lance"	-- Comando para dar lance
LEILAO_LANCE_RETER_VALOR		= 0		-- 1 Quando o player der o lance, o valor � descontado na hora mesmo que ele n�o seja o vencedor, 0 s� desconta o valor do lance vencedor ap�s finalizar o leil�o.
LEILAO_LANCE_VALOR_INCREMENTO	= 100	-- Valor minimo do pr�ximo lance sera o lance atual + o valor definido aqui
LEILAO_LANCE_TIMER_SWITCH		= 1		-- 1 Para resetar o contador dos segundos finais toda vez que um lance for dado, 0 o leilao finaliza ao final do tempo pr� configurado
LEILAO_LANCE_TIMER_TEMPO		= 5 	-- Tempo que vai contar ap�s um lance. (quando a contagem acabar, o leila finaliza)

-- Configura��o Leilao por comando
-- Ativa/Desativa o comando
LEILAO_COMMAND_SWITCH		= 1			-- 0 desativa o leil�o por comando
LEILAO_START_COMMAND		= "/abrirleilao"		-- Inicia um leilao  sintaxe: /comado [index moeda] [pre�o inicial] [Nome Do Item] (Ex: /leilao 1 1000 Sword of Style)
LEILAO_AREA_START_COMMAND	= "/leilaoarea"	-- Inicia um leil�o em um mapa especifico. Sinaxe: /comado [index area] [index moeda] [pre�o inicial] [Nome Do Item]
LEILAO_END_COMMAND			= "/fimleilao"	-- For�ar o fim do leilao antecipadamente.

--Login e char com autoriza��o para realizar o leil�o. (o char deve pertencer a conta)
LEILAO_LOGIN_SWITCH		= 0 -- 1 Ativa a autoriza��o por login e char.
LEILAO_LOGIN_AUTORIZADO	= {
{_login = "admin", _char = "Admin"},

}

--Index da moeda (ser� passado no comando), n�o use 0
--Tabela da moeda
--Coluna da moeda
--Identificador do jogador
--Nome da moeda
LEILAO_LISTA_MOEDAS = {
	{_index = "1", _tabela = "CashShopData", _coluna = "WCoinC", _where = "AccountID", _nome = "Cash"},
	{_index = "2", _tabela = "CashShopData", _coluna = "WCoinP", _where = "AccountID", _nome = "Gold"},

}

-- Configura��o da area em que o leil�o est� sendo realizado, o player so podera dar lances se estiver dentro dessa area.
-- Index da area (ser� passado no comando), n�o use 0
-- Mapa
-- Coordenada x de valor mais baixo
-- Coordnada y de valor mais baixo
-- Coordenada x de alor mais alto
-- Coordenada y de valor mais alto
LEILAO_AREA = {
	{_index = "0", _map = 0, _x1 = 121, _y1 = 121, _x2 = 128, _y2 = 136}, -- Dentro do bar
}


-- Configura��o Leilao Autom�tico

-- Ativa/Desativa
LEILAO_SWITCH = true

--Para o leilao inicar exatamente na hora desejada, coloque o horario do leilao descontando o tempo de aviso em minutos.
--Ex: Se quer que o evento come�e exatamente as 22:00 e com aviso de 5 minutos, agende o evento para 21:55

--Day of Week, Day, Hour, Minute
--Day of Week: 0 a 6: Domingo, segunda, ter�a, quarta, quinta, sexta, sabado
--Day of Week: -1 = Day
--Day = -1 = Horas e minutos.
LEILAO_AUTO_CRON = {
	--{_Index = 1, _dayofweek = -1, _day = -1, _hour = 21, _minute = 35},
	--{_Index = 2, _dayofweek = -1, _day = -1, _hour = 11, _minute = 55},
}

--Index do leilao (n�o use 0)
-- Nome do leil�o (vai aparecer no global)
--Nome da moeda
--Lance minimo para alguem ganhar o leilao
--Coluna da moeda
--Tabela da moeda
--Identificador do jogador
LEILAO_AUTO_CONFIG = {
	--{_Index = 1, _nomeLeilao = "Leil�o Sword Apolo", _nomeMoeda = "Golds", _lanceMinimo = 1000, _coluna = "gold", _tabela = "CashShopData", _where = "AccountID"},
	--{_Index = 2, _nomeLeilao = "Leil�o Sword of War", _nomeMoeda = "Cash", _lanceMinimo = 1000, _coluna = "cash", _tabela = "CashShopData", _where = "AccountID"},
}

--Index do leilao (n�o use 0) pode premiar varios itens por leilao, como set completo(cadastrar cada parte separadamente), ou um all completo, porem tem que caber tudo em 1 inventario
--Nome do item
--Se��o do item do item.txt
--Index do item no item.txt
--Level
--Durabilidade
--Sorte
--Skill
--Opcionais
--Opcionais excelentes
--Quantidade (para premiar mais que 1 do mesmo item)
LEILAO_AUTO_CONFIG_ITENS = {
	--{_Index = 1, _ItemName = "Sword Apolo +15", _ItemSection = 0, _ItemIndex = 10, _Level = 15, _Durabilidade = 255,_Luck = 1, _Skill = 1, _Opt = 7, _Exc_1 = 1, _Exc_2 = 1, _Exc_3 = 1, _Exc_4 = 1, _Exc_5 = 1, _Exc_6 = 1, _Count = 1},
	--{_Index = 2, _ItemName = "Sword of War +15", _ItemSection = 0, _ItemIndex = 10, _Level = 15, _Durabilidade = 255,_Luck = 1, _Skill = 1, _Opt = 7, _Exc_1 = 1, _Exc_2 = 1, _Exc_3 = 1, _Exc_4 = 1, _Exc_5 = 1, _Exc_6 = 1, _Count = 1},
}