-----------------------------------------
	-- Script:  Evento Rebelião
	-- Criador: Pedro Borges
	-- Skype: live:ppborges93
-----------------------------------------

Rebeliao = {}

local aberto = false
local iniciado = false
local Participantes = {}
local minutesToStart = nil
local secondsToClose = nil
local timer = nil
local timerCheck = nil
local realizador = nil

function Rebeliao.Init()
	if REB_AUTO_SWITCH == 0
	then
		return
	end	
	for i in ipairs(REB_DATA) do
		if REB_DATA[i]._dayofweek ~= -1
		then
			Schedule.SetDayOfWeek(REB_DATA[i]._dayofweek, REB_DATA[i]._hour, REB_DATA[i]._minute, Rebeliao.Start)
		elseif REB_DATA[i]._day ~= -1
		then
			Schedule.SetDayAndHourAndMinute(REB_DATA[i]._day, REB_DATA[i]._hour, REB_DATA[i]._minute, Rebeliao.Start)
		else
			Schedule.SetHourAndMinute(REB_DATA[i]._hour, REB_DATA[i]._minute, Rebeliao.Start)
		end
	end
end

function Rebeliao.Start()
	if REB_AUTO_SWITCH == 0
	then
		return
	end
	
	SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
	SendMessageGlobal(string.format("Inicia em:"), 0)
	SendMessageGlobal(string.format("%d minuto(s)", REB_ANNOUNCE_MINUTES), 0)
	SendMessageGlobal(string.format("==="), 0)
	SendMessageGlobal(string.format("Prepare-se!"), 0)
	SendMessageGlobal(string.format("= ============= = ============= ="), 0)

	minutesToStart = REB_ANNOUNCE_MINUTES
	timer = Timer.Repeater(60, 	REB_ANNOUNCE_MINUTES, Rebeliao.Running)
end

function Rebeliao.Running()
	minutesToStart = minutesToStart - 1
	if minutesToStart <= 0
	then
		Timer.Cancel(timer)
		timer = nil
		aberto = true
		Rebeliao.RemovePlayers()
		timerCheck = Timer.Interval(2, Rebeliao.CheckUser)
		SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
		SendMessageGlobal(string.format("Inicia em:"), 0)
		SendMessageGlobal(string.format("%d seg.", REB_TIME_CLOSE), 0)
		SendMessageGlobal(string.format("Para participar digite:"), 0)
		SendMessageGlobal(string.format("%s",REB_COMMAND_GO), 0)
		SendMessageGlobal(string.format("= ============= = ============= ="), 0)
		secondsToClose = REB_TIME_CLOSE
		timer = Timer.Repeater(1, REB_TIME_CLOSE, Rebeliao.ComandoIrTimer)	
	else
		SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
		SendMessageGlobal(string.format("Inicia em:"), 0)
		SendMessageGlobal(string.format("%d minuto(s)", minutesToStart), 0)
		SendMessageGlobal(string.format("==="), 0)
		SendMessageGlobal(string.format("Prepare-se!"), 0)
		SendMessageGlobal(string.format("= ============= = ============= ="), 0)
		
	end
end

function Rebeliao.ComandoAbrir(aIndex, Arguments)
	local staff = User.new(aIndex)
	
	if staff:getAuthority() == 1
	then
		return
	end
	
	if REB_COMMAND_SWITCH == 0
	then
		return
	end
	
	if aberto == true or iniciado == true
	then
		SendMessage(string.format("[Rebeliao]Aguarde o fim do evento atual.", REB_COMMAND_OPEN), aIndex, 1)
		return
	end
	
	local tempo = command:getNumber(Arguments, 1)
	
	if tempo <= 0 or tempo == nil
	then
		SendMessage(string.format("[Rebeliao] Use %s <tempo>", REB_COMMAND_OPEN), aIndex, 1)
		return
	end
	
	realizador = {Nome = staff:getName(), Account = staff:getAccountID(), Index = aIndex}
	
	aberto = true
	Rebeliao.RemovePlayers()
	timerCheck = Timer.Interval(2, Rebeliao.CheckUser)
	
	SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
	SendMessageGlobal(string.format("Inicia em:"), 0)
	SendMessageGlobal(string.format("%d seg.", tempo), 0)
	SendMessageGlobal(string.format("Para participar digite:"), 0)
	SendMessageGlobal(string.format("%s",REB_COMMAND_GO), 0)
	SendMessageGlobal(string.format("= ========== = ========== ="), 0)

	
	secondsToClose = tempo
	
	timer = Timer.Repeater(1, tempo, Rebeliao.ComandoIrTimer)		
end

function Rebeliao.CheckUser()
	for i, name in ipairs(Participantes) do
		local index = Participantes[name].Index
		local pTemp = User.new(index)

		if pTemp:getConnected() ~= 3
		then
			RemoverTable(Participantes, name)
		end
		
		local userMap = pTemp:getMapNumber()
		if userMap ~= REB_LOCATION.Map
		then
			RemoverTable(Participantes, name)
			SendMessage("[Rebeliao] Voce saiu do evento.", index, 1)
		end
		
		local userX = pTemp:getX()
		local userY = pTemp:getY()
		
		if userX < REB_AREA.CoordX1 or userX > REB_AREA.CoordX2 or userY < REB_AREA.CoordY1 or userY > REB_AREA.CoordY2 then
			RemoverTable(Participantes, name)
			Teleport(index, 0, 125, 125)
			SendMessage("[Rebeliao] Você saiu da area do evento.", index, 1)
			if #Participantes == 1 then
				Rebeliao.End()
				return
			end
		end	

		pTemp = nil
	end
	
	if aberto == false and iniciado == true
	then
		if CountTable(Participantes) == 1
		then
			if timerCheck ~= nil
			then
				Timer.Cancel(timerCheck)
				timerCheck = nil
			end
			
			Rebeliao.End()
		end
	end
end

function Rebeliao.RemovePlayers()

	for aIndex = OBJECT_START_USER, MAX_OBJECT do
		local pTemp = User.new(aIndex)
		if pTemp:getConnected() == 3
		then
			if pTemp:getAuthority() == 1
			then
				if pTemp:getMapNumber() == REB_AREA.Map and pTemp:getX() >= REB_AREA.CoordX1 and pTemp:getX() <= REB_AREA.CoordX2 and pTemp:getY() >= REB_AREA.CoordY1 and pTemp:getY() <= REB_AREA.CoordY2
				then
					Teleport(aIndex, 0, 125, 125)
					SendMessage("[Rebeliao] Voce nao tem permissao para ficar nessa area.", aIndex, 1)
				end
			end
		end

		pTemp = nil
	end

end

function Rebeliao.End()	
	local Nome = nil
	local Index = nil
	local Account = nil
	local Mortes = nil
	
	for i, name in ipairs(Participantes) do
		Nome = Participantes[name].Name
		Index = Participantes[name].Index
		Account = Participantes[name].Account
		Mortes = Participantes[name].Mortes
	end
	
	SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
	SendMessageGlobal(string.format("==="), 0)
	SendMessageGlobal(string.format("  Vencedor: %s  ", Nome), 0)
	SendMessageGlobal(string.format("==="), 0)
	SendMessageGlobal(string.format("  Matou %d players  ", Mortes), 0)
	SendMessageGlobal(string.format("= ============= = ============= ="), 0)
	
	Teleport(Index, 0, 125, 125)
	
	DataBase.SetAddValue(REB_PLAYER_REWARD.MoneyTable, REB_PLAYER_REWARD.MoneyColumn, REB_PLAYER_REWARD.MoneyAmmount, REB_PLAYER_REWARD.MoneyWhere, Account)
	DataBase.SetAddValue(REB_PLAYER_REWARD.PointsTable, REB_PLAYER_REWARD.PointsColumn, REB_PLAYER_REWARD.PointsAmmount, REB_PLAYER_REWARD.PointsWhere, Nome)
	SendMessage(string.format("[Sistema] Voce recebeu %d %s.", REB_PLAYER_REWARD.MoneyAmmount, REB_PLAYER_REWARD.MoneyName ), Index, 1)
	
	Rebeliao.Clear()
end

function Rebeliao.Clear()
	aberto = false
	iniciado = false
	Participantes = {}
	minutesToStart = nil
	secondsToClose = nil
	realizador = nil
	
	if timer ~= nil
	then
		Timer.Cancel(timer)
		timer = nil
	end
	
	if timerCheck ~= nil
	then
		Timer.Cancel(timerCheck)
		timerCheck = nil
	end
	
	return
end

function Rebeliao.ComandoIrTimer()
	secondsToClose = secondsToClose - 1
	
	if secondsToClose <= 0
	then
		Timer.Cancel(timer)
		timer = nil
		aberto = false
		
		if CountTable(Participantes) < REB_MIN_PLAYERS
		then
			SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
			SendMessageGlobal(string.format("  Evento Cancelado!  "), 0)
			SendMessageGlobal(string.format("  Motivo:  "), 0)
			SendMessageGlobal(string.format("[ Falta de participantes ]"), 0)
			SendMessageGlobal(string.format("  Aguarde o proximo.  "), 0)
			SendMessageGlobal(string.format("= ============= = ============= ="), 0)		
			
			
			if #Participantes > 0 then
				for i, Nome in ipairs(Participantes) do
					Teleport(Participantes[Nome].Index, 0, 125, 125)
				end
			end
			
			Rebeliao.Clear()
			return
		end
		
		if realizador ~= nil then
			DataBase.SetAddValue(REB_STAFF_REWARD.MoneyTable, REB_STAFF_REWARD.MoneyColumn, REB_STAFF_REWARD.MoneyAmmount, REB_STAFF_REWARD.MoneyWhere, realizador.Account)
			DataBase.SetAddValue(REB_STAFF_REWARD.PointsTable, REB_STAFF_REWARD.PointsColumn, REB_STAFF_REWARD.PointsAmmount, REB_STAFF_REWARD.PointsWhere, realizador.Nome)
			SendMessage(string.format("[Sistema] Você recebeu %d %s.", REB_STAFF_REWARD.MoneyAmmount, REB_STAFF_REWARD.MoneyName), realizador.Index, 1)
		end
		
		SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
		SendMessageGlobal(string.format("==="), 0)
		SendMessageGlobal(string.format("Evento Iniciado!"), 0)
		SendMessageGlobal(string.format("==="), 0)
		SendMessageGlobal(string.format("Aguarde o Anuncio do  vencedor."), 0)
		SendMessageGlobal(string.format("= ============= = ============= ="), 0)
		iniciado = true
		
		return 0
	end
	
	SendMessageGlobal(string.format("= ===== Evento Rebeliao ===== ="), 0)
	SendMessageGlobal(string.format("Inicia em:"), 0)
	SendMessageGlobal(string.format("%d seg.", secondsToClose), 0)
	SendMessageGlobal(string.format("Para participar digite:"), 0)
	SendMessageGlobal(string.format("%s",REB_COMMAND_GO), 0)
	SendMessageGlobal(string.format("= ============= = ============= ="), 0)
end

function Rebeliao.ComandoIr(aIndex, Arguments)
	if aberto == false
	then
		SendMessage(string.format("[Rebeliao] Nenhum evento aberto"), aIndex, 1)
		return
	end	
	
	local player = User.new(aIndex)
	
	if player:getLevel() < REB_LEVEL
	then
		SendMessage(string.format("[Rebeliao] Voce precisa estar acima do level %d", REB_LEVEL), aIndex, 1)
		return
	end
	
	if DataBase.GetValue(TABLE_VIP, COLUMN_VIP, WHERE_VIP, player:getAccountID()) < REB_VIP
	then
		SendMessage(string.format("[Rebeliao] Somente usuarios vip podem usar este comando!"), aIndex, 1)
		return
	end
	
	local Nome = player:getName()

	if DataBase.GetValue(TABLE_RESET, COLUMN_RESET[0], WHERE_RESET, Nome) < REB_RESETS
	then
		SendMessage(string.format("[Rebeliaovivência] Voce precisa de %d resets", REB_RESETS), aIndex, 1)
		return
	end
	
	if DataBase.GetValue(TABLE_MRESET, COLUMN_MRESET[0], WHERE_MRESET, Nome) < REB_MRESETS
	then
		SendMessage(string.format("[Rebeliao] Voce precisa de %d M.Resets", REB_MRESETS), aIndex, 1)
		return
	end	
	
	local Login = player:getAccountID()
	
	if has_key(Participantes, Nome) == true
	then
		SendMessage("[Rebeliao] Voce ja esta participando.", aIndex, 1)
		return
	end	
	
	InsertKey(Participantes, Nome)
	Participantes[Nome] = {Name = Nome, Index = aIndex, Account = Login, Mortes = 0}
	Teleport(aIndex, REB_LOCATION.Map, REB_LOCATION.CoordX, REB_LOCATION.CoordY)
	SendMessage("[Rebeliao] Voce foi movido.", aIndex, 1)
	SendMessage("[Rebeliao] Nao relogue ou sera desclassificado.", aIndex, 1)
end	

function Rebeliao.BlockAttack(aIndex, TargetIndex)	
	local player = User.new(aIndex)
	local pTarget = User.new(TargetIndex)

	if has_key(Participantes, player:getName()) == true and has_key(Participantes, pTarget:getName()) == true
	then
		if iniciado == false
		then
			SendMessage("[Rebeliao] Aguarde o inicio do evento.", aIndex, 1)
			return 1
		else
			return
		end
	end
	
	return
end

function Rebeliao.PlayerDie(aIndex, TargetIndex)
	if iniciado == false
	then
		return
	end
	
	local player = User.new(aIndex)
	local pTarget = User.new(TargetIndex)
	
	if has_key(Participantes, player:getName()) == true and has_key(Participantes, pTarget:getName()) == true
	then
		Participantes[player:getName()].Mortes = Participantes[pTarget:getName()].Mortes + 1
		RemoverTable(Participantes, pTarget:getName())		
		SendMessageGlobal(string.format(" [Rebeliao] %s matou %s ", player:getName(), pTarget:getName()), 0)		
		SendMessage(string.format("[Rebeliao]Voce foi morto por %s", player:getName()), TargetIndex, 1)
	end
end

Rebeliao.Init()

Commands.Register(REB_COMMAND_GO, Rebeliao.ComandoIr)
Commands.Register(REB_COMMAND_OPEN, Rebeliao.ComandoAbrir)
GameServerFunctions.PlayerAttack(Rebeliao.BlockAttack)
GameServerFunctions.PlayerDie(Rebeliao.PlayerDie)

return Rebeliao