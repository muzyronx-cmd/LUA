-----------------------------------------
	-- Script:		Add Pr�mio
	-- Criador:		Pedro Borges
	-- Skype:		live:ppborges93
	-- WhatsApp:	+55 51 99507-8287
	-- Servidor:	King
-----------------------------------------

-- true ativa o comando, false desativa
AddPremio_Ativado = true

-- Comando para adicionar um premio. Sintaxe: /comando Nome_Do_Premio nick
AddPremio_Comando = "/add"

-- Coloque o nick do personagem que poder� usar o comando e o n�vel da permiss�o
AddPremio_NivelPermissao = {}
AddPremio_NivelPermissao["Admin"] = 10



-- para criar um pr�mio, copie a linha AddPremio_Config["Nome_Do_Premio"] = {}
-- Dentro dos colchetes coloque o nome do premio que ser� digitado no comando (deve ser min�sculo e n�o pode ter espa�os)
-- Dentro das chaves, coloque o nome, a IdPremio que ser� usada para identificar os itens, e o nivel de permiss�o para poder dar o premio
AddPremio_Config = {}
AddPremio_Config["box"] =         {Nome = "Luck Events Reward",                IdPremio = 1,    NivelPermissao = 5, TemValidade = 0, Dias = -1}

AddPremio_Config["donate"] =         {Nome = "Kit DONATE",                IdPremio = 2,    NivelPermissao = 10, TemValidade = 0, Dias = -1}
AddPremio_Config["evolution"] =      {Nome = "Kit EVOLUTION",         	  IdPremio = 3,    NivelPermissao = 10, TemValidade = 0, Dias = -1}
AddPremio_Config["halloblack"] =     {Nome = "Kit Halloween Black",       IdPremio = 4,    NivelPermissao = 10, TemValidade = 0, Dias = -1}
AddPremio_Config["style2"] =  	     {Nome = "Kit Style 2.0",  		      IdPremio = 5,    NivelPermissao = 10, TemValidade = 0, Dias = -1}
AddPremio_Config["frost"] =  	     {Nome = "Kit Frost",  			      IdPremio = 6,    NivelPermissao = 10, TemValidade = 0, Dias = -1}

AddPremio_Config["hp"] =         	 {Nome = "HPoints",              	  IdPremio = 7,    NivelPermissao = 5,  TemValidade = 0, Dias = -1}
AddPremio_Config["live"] =           {Nome = "CODIGO de LIVE YouTube",    IdPremio = 8,    NivelPermissao = 10, TemValidade = 0, Dias = -1}
AddPremio_Config["natal"] =  	     {Nome = "DONATE DE NATAL",  		  IdPremio = 9,    NivelPermissao = 10, TemValidade = 0, Dias = -1}

AddPremio_Config["death"] =  	     {Nome = "[DONATE] ALL DEATH RELIC",  IdPremio = 10,    NivelPermissao = 10, TemValidade = 0, Dias = -1}
AddPremio_Config["bloody"] =  	     {Nome = "[DONATE] ALL BLOODY", 	  IdPremio = 11,    NivelPermissao = 10, TemValidade = 0, Dias = -1}

AddPremio_Config["mystic"] =  	     {Nome = "[DONATE] ALL Mystic", 	  IdPremio = 12,    NivelPermissao = 10, TemValidade = 0, Dias = -1}

-- Para configurar os itens de um pr�mio, copie a linha AddPremio_Itens[IdPremio] = {}
-- Dentro dos colchetes coloque o IdPremio configurado acima
-- Dentro das chaves adicione os itens conforme exemplo abaixo, sempre colocando uma virgula no final da linha
AddPremio_Itens = {} -- n�o repetir essa linha
--# INICIO DO PR�MIO 1 #--

AddPremio_Itens[1] = {
	{Nome = "Luck Events Reward", Section =  14, Id =  212, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
}


AddPremio_Itens[2] = {
	{Nome = "Mace Saphure",  Section =  0, Id =  66, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Sword Saphure", Section =  0, Id =  67, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Mace Saphure",	 Section =  5, Id =  56, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Shield Saphure", Section = 6, Id = 219, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Saphure" 	, Section = 7, Id = 223, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Saphure" , Section = 8, Id = 223, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Saphure" , Section = 9, Id = 223, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Saphure", Section = 10, Id = 223, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Saphure" , Section = 11, Id = 223, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa Saphure"  , Section = 12, Id = 235, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa Saphure"  ,  Section = 12, Id = 238, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Saphure"  , Section = 13, Id = 173, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Saphure"  , Section = 13, Id = 173, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pend Saphure"  , Section = 13, Id = 174, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Raven Saphure" , Section = 13, Id = 238, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pet Saphure"   , Section = 13, Id = 239, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Horse Saphure" , Section = 13, Id = 241, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},



}

AddPremio_Itens[3] = {
	{Nome = "Sword Evolution", Section =  0, Id =  58, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Mace Evolution",  Section =  2, Id =  64, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Shield Evolution", Section = 6, Id = 212, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Evolution"  , Section = 7, Id = 213, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Evolution" , Section = 8, Id = 213, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Evolution" , Section = 9, Id = 213, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Evolution", Section = 10, Id = 213, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Evolution" , Section = 11, Id = 213, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa Evolution"  , Section = 12, Id = 222, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa Evolution"  ,  Section = 12, Id = 223, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Evolution"  , Section = 13, Id = 159, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Evolution"  , Section = 13, Id = 159, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pend Evolution"  , Section = 13, Id = 160, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Brinco Evolution", Section = 13, Id = 224, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Brinco Evolution", Section = 13, Id = 225, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Fenrir Evolution" ,Section = 13, Id = 273, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Horse Evolution" , Section = 13, Id = 310, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},



}
AddPremio_Itens[4] = {
	{Nome = "Sword Halloween Black", Section =  2, Id = 102, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Mace Halloween Black",  Section =  2, Id = 103, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Shield Halloween Black", Section = 6, Id = 275, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Halloween Black"  , Section = 7, Id =  56, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Halloween Black" , Section = 8, Id =  56, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Halloween Black" , Section = 9, Id =  56, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Halloween Black", Section = 10, Id = 56 , Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Halloween Black" , Section = 11, Id = 56 , Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa Halloween Black"  , Section = 12, Id = 341, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa Halloween Black"  ,  Section = 12, Id = 342, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},



}
AddPremio_Itens[5] = {
	{Nome = "Sword Style 2.0", Section =  2, Id =  99, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Mace Style 2.0",  Section =  2, Id = 100, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Spear Style 2.0",  Section = 2, Id = 101, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Shield Style 2.0", Section = 6, Id = 256, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Style 2.0"  , Section = 7, Id = 291, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Style 2.0" , Section = 8, Id = 291, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Style 2.0" , Section = 9, Id = 291, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Style 2.0", Section = 10, Id = 291, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Style 2.0" , Section = 11, Id = 291, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa Style 2.0"  , Section = 12, Id = 310, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa Style 2.0"  ,  Section = 12, Id = 311, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Style 2.0"  , Section = 15, Id = 444, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Style 2.0"  , Section = 15, Id = 444, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pend Style 2.0"  , Section = 15, Id = 445, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Brinco Style 2.0", Section = 15, Id = 446, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Brinco Style 2.0", Section = 15, Id = 447, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Staff Style 2.0",  Section =  5, Id =  71, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},



}
AddPremio_Itens[6] = {
	{Nome = "Sword Frost", Section =  2, Id =  93, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Mace Frost",  Section =  2, Id =  94, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Spear Frost",  Section = 2, Id =  95, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Shield Frost", Section = 6, Id =  254, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Frost"  , Section = 7, Id =  288, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Frost" , Section = 8, Id =  288, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Frost" , Section = 9, Id =  288, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Frost", Section = 10, Id = 288, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Frost" , Section = 11, Id = 288, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa Frost"  , Section = 12, Id = 306, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa Frost"  ,  Section = 12, Id = 307, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Frost"  , Section = 13, Id = 254, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Staff Frost",  Section =  5, Id =  70, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Frost f"  , Section = 7, Id =  289, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Frost f" , Section = 8, Id =  289, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Frost f" , Section = 9, Id =  289, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Frost f", Section = 10, Id = 289, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Frost f" , Section = 11, Id = 289, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},



}
AddPremio_Itens[7] = {
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},
	{Nome = "Luck Events Reward", Section =  14, Id =  224, Level = 0, Durabilidade = 0, Skill = 0, Luck = 0, Opt = 0, Excelente = 0, Dias = -1},

}
AddPremio_Itens[8] = {
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},


	{Nome = "PRESENTE",   Section =  13, Id =  64, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  65, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  67, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  80, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  76, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "PRESENTE",   Section =  13, Id =  64, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  65, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  67, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  80, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  13, Id =  76, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  54, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "PRESENTE",   Section =  0, Id =  55, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},


}

AddPremio_Itens[9] = {
	{Nome = "Sword", 			Section = 0,  Id =  75, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Mace",   			Section = 0,  Id =  76, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Hammer",   		Section = 0,  Id =  77, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Shield", 			Section = 6,  Id = 225, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm", 			Section = 7,  Id = 237, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor" , 			Section = 8,  Id = 237, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants" , 			Section = 9,  Id = 237, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves", 			Section = 10, Id = 237, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots" , 			Section = 11, Id = 237, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa"  , 			Section = 12, Id = 245, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa"  ,  			Section = 12, Id = 244, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Trans"  , 	Section = 13, Id = 41,  Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring"  , 			Section = 13, Id = 179, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring"  , 			Section = 13, Id = 179, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pend", 			Section = 13, Id = 180, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Dino", 			Section = 13, Id = 246, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Horse" ,			Section = 13, Id = 247, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Fenrir" , 			Section = 13, Id = 248, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Brinco" , 			Section = 13, Id = 249, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Brinco" , 			Section = 13, Id = 250, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pet" , 			Section = 13, Id = 245, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Fenrir [v]" , 		Section = 13, Id = 258, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},



}

AddPremio_Itens[10] = {
	{Nome = "Sword Death Relic",  Section = 0, 	Id =  90, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Knifer Death Relic", Section = 0, 	Id =  91, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Mace Death Relic",	  Section = 0, 	Id =  92, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Spear Death Relic",  Section = 0, 	Id =  93, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Staff Death Relic",  Section = 5, 	Id =  60, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Shield Death Relic", Section = 6, 	Id = 233, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Death Relic" 	, Section = 7, 	Id = 249, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Death Relic" , Section = 8, 	Id = 249, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Death Relic" , Section = 9, 	Id = 249, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Death Relic", Section = 10, Id = 249, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Death Relic" , Section = 11, Id = 249, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Helm Death Relic" 	, Section = 7, 	Id = 250, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Death Relic" , Section = 8, 	Id = 250, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Death Relic" , Section = 9, 	Id = 250, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Death Relic", Section = 10, Id = 250, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Death Relic" , Section = 11, Id = 251, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Capa Death Relic"  , Section = 12, Id = 261, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa Death Relic"  ,  Section = 12, Id = 262, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Death Relic"  , Section = 15, Id = 407, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "ring Death Relic"  , Section = 15, Id = 407, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pend Death Relic"  , Section = 15, Id = 408, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Aguia Death Relic" , Section = 13, Id = 256, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Horse Death Relic" , Section = 13, Id = 255, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "brinco Death Relic" , Section = 15, Id = 465, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "brinco Death Relic" , Section = 15, Id = 466, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},


}
AddPremio_Itens[11] = {
	{Nome = "Mace Bloody",   Section = 0,  Id = 117, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Sword Bloody",  Section = 0,  Id = 118, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Shield Bloody", Section = 6,  Id = 244, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Helm Bloody" ,  Section = 7,  Id = 270, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Bloody" , Section = 8,  Id = 270, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Bloody" , Section = 9,  Id = 270, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Bloody", Section = 10, Id = 270, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Bloody" , Section = 11, Id = 270, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Asa Bloody"  ,  Section = 12, Id = 281, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa Bloody"  , Section = 12, Id = 282, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Earring Bloody" , Section = 15, Id = 422, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Earring Bloody" , Section = 15, Id = 423, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Artifact Bloody", Section = 15, Id = 421, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},



}

AddPremio_Itens[12] = {
	{Nome = "Sword Mystic",  Section = 0,  Id = 100, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Sword Mystic",  Section = 0,  Id = 101, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Sword Mystic",  Section = 0,  Id = 102, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Sword Mystic",  Section = 0,  Id = 103, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Sword Mystic",  Section = 0,  Id = 104, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Staff Mystic",  Section = 5,  Id = 63,  Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Shield Mystic", Section = 6,  Id = 237, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	
	{Nome = "Helm Mystic" ,  Section = 7,  Id = 257, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Armor Mystic" , Section = 8,  Id = 257, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pants Mystic" , Section = 9,  Id = 257, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Gloves Mystic", Section = 10, Id = 257, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Boots Mystic" , Section = 11, Id = 257, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Asa Mystic"  ,  Section = 12, Id = 267, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Capa Mystic"  , Section = 12, Id = 268, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Ring Mystic" ,   Section = 15, Id = 413, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Ring Mystic" ,   Section = 15, Id = 413, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Pendat Mystic" , Section = 15, Id = 414, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Earring Mystic" , Section = 15, Id = 415, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},
	{Nome = "Earring Mystic" , Section = 15, Id = 416, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},

	{Nome = "Malignant Dragon" , Section = 13, Id = 264, Level = 15, Durabilidade = 255, Skill = 1, Luck = 1, Opt = 7, Excelente = 63, Dias = -1},


}