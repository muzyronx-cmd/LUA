
--Configura��es evento automatico
SOBRE_AUTO_SWITCH		= 0			-- 0 Desativa o evento autom�tico
SOBRE_ANNOUNCE_MINUTES	= 0				-- Tempo em minutos que anunciar� que o evento vai come�ar (0 inicia sem aviso)
SOBRE_TIME_CLOSE		= 30			-- Tempo em segundos que o move ficara aberto no evento autom�tico
-- Configura��o dos hor�rios do evento autom�rico
--Para o evento inicar exatamente na hora desejada, coloque o horario do evento descontando o tempo de aviso em minutos.
--Ex: Se quer que o evento come�e exatamente as 22:00 e com aviso de 5 minutos, agende o evento para 21:55

--Day of Week, Day, Hour, Minute
--Day of Week: 0 a 6: Domingo, segunda, ter�a, quarta, quinta, sexta, sabado
--Day of Week: -1 = Day
--Day = -1 = Horas e minutos.
SOBRE_DATA	= {

	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 03},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 05},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 07},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 10},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 12},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 15},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 17},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 20},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 22},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 25},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 27},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 31},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 33},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 37},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 40},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 42},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 45},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 47},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 50},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 52},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 55},
	--{_dayofweek = -1, _day = -1, _hour = 12, _minute = 57},

}

-- Configura��o evento manual
SOBRE_COMMAND_SWITCH	= 1				-- 0 desativa o comando de abrir o evento
SOBRE_COMMAND_OPEN		= "/abrirsobre"	-- Comando para abrir o evento (Sintaxe: /comando <tempo>)
SOBRE_COMMAND_GO		= "/sobre"		-- Comando para entrar no evento

-- Configura��es gerais do evento
SOBRE_MIN_PLAYERS		= 2				-- Quantidade minima de players para o evento acontecer.
SOBRE_LEVEL				= 500			-- Level minimo para participar do evento
SOBRE_VIP				= 0				-- Vip minimo para participar do evento
SOBRE_RESETS			= 0				-- Quantidade minima de resets para participar do evento
SOBRE_MRESETS			= 0				-- Quantidade minima de master resets para participar do evento

SOBRE_CLASSES_PERMITIDAS = { --classes que podem ir ao evento
[0] = false, 	-- SM, true permitido, false n�o permitido
[1] = true, 	-- BK, true permitido, false n�o permitido
[2] = false, 	-- ELF, true permitido, false n�o permitido
[3] = true, 	-- MG, true permitido, false n�o permitido
[4] = true, 	-- DL, true permitido, false n�o permitido
}

SOBRE_AREA = { -- area do evento, se sair dessa area, sera desclassificado.
Map		= 1,	-- Mapa
CoordX	= 174,	-- Coordenada X -- coordenada X para onde o player sera movido ao entrar no evento
CoordY	= 220,	-- Coordenada Y	-- coordenada Y para onde o player sera movido ao entrar no evento
CoordX1	= 173,	-- Coordenada X Menor
CoordY1	= 174,	-- Coordenada Y Menor
CoordX2	= 221,	-- Coordenada X Maior
CoordY2	= 221	-- Coordenada Y Maior
} 


-- Configura��o do premio

SOBRE_PREMIO_NOME = "CASH"				-- Nome da moeda
SOBRE_PREMIO_VALOR = 200				-- Quantidade da moeda
SOBRE_PREMIO_TABELA = "CashShopData"		-- Tabela da moeda
SOBRE_PREMIO_COLUNA = "WCoinC"			-- Coluna da moeda
SOBRE_PREMIO_WHERE = "AccountID"		-- Identificador do player
SOBRE_PREMIO_TIPO = 0 					-- Tipo de identificador, 0 = login, 1 = nick

SOBRE_PONTO_VALOR = 0					-- Quantidade de pontos
SOBRE_PONTO_TABELA = "Character"		-- Tabela dos pontos
SOBRE_PONTO_COLUNA = "sobre"			-- Coluna dos pontos
SOBRE_PONTO_WHERE = "Name"				-- Identificador do player
SOBRE_PONTO_TIPO = 1 					-- Tipo de identificador, 0 = login, 1 = nick

SOBRE_PONTO2_VALOR = 1					-- Quantidade de pontos
SOBRE_PONTO2_TABELA = "Character"		-- Tabela dos pontos
SOBRE_PONTO2_COLUNA = "matamata"		-- Coluna dos pontos
SOBRE_PONTO2_WHERE = "name"				-- Identificador do player
SOBRE_PONTO2_TIPO = 1 					-- Tipo de identificador, 0 = login, 1 = nick

Sobre_PremioReward = GET_ITEM(14, 123)

SOBRE_MESSAGES = {
	["Eng"] = {
		[1] = "� ����� Evento Sobreviv�ncia ����� �",
		[2] = "In�cio em:",
		[3] = "%d minuto(s)",
		[4] = "���",
		[5] = "Prepare-se!",
		[6] = "� ������������� � ������������� �",
		[7] = "%d seg.",
		[8] = "Para participar digite:",
		[9] = "%s",
		[10] = "[Sobre] Aguarde o fim do evento atual.",
		[11] = "[Sobre] Use %s <tempo>",
		[12] = "[Sobreviv�ncia] Voc� saiu do evento.",
		[13] = "[Sobreviv�ncia] Voc� saiu da �rea do evento.",
		[14] = "[Sobreviv�ncia] Voc� nao tem permissao para ficar nessa area.",
		[15] = "Vencedor: %s",
		[16] = "Matou %d players",
		[17] = "[Sistema] Voc� recebeu %d %s.",
		[18] = "Evento Cancelado!",
		[19] = "Motivo:",
		[20] = "[ Falta de participantes ]",
		[21] = "Aguarde o pr�ximo.",
		[22] = "Evento Iniciado!",
		[23] = "Aguarde o An�ncio do  vencedor.",
		[24] = "[Sobreviv�ncia] Nenhum evento aberto",
		[25] = "[Sobreviv�ncia] Voc� precisa estar acima do level %d",
		[26] = "[Sobreviv�ncia] Somente usu�rios vip podem usar este comando!",
		[27] = "[Sobreviv�ncia] Voc� precisa de %d resets",
		[28] = "[Sobreviv�ncia] Voc� precisa de %d M.Resets",
		[29] = "[Sobreviv�ncia] Sua classe n�o � permitida no evento.",
		[30] = "[Sobreviv�ncia] Voc� j� est� participando.",
		[31] = "[Sobreviv�ncia] Voc� foi movido.",
		[32] = "N�o mova ou relogue ou ser� desclassificado.",
		[33] = "[Sobreviv�ncia] Aguarde o inicio do evento.",
		[34] = "[Sobre] %s matou %s",
		[35] = "[Sobreviv�ncia]Voc� foi morto por %s",
	},
	["Por"] = {
		[1] = "� ����� Evento Sobreviv�ncia ����� �",
		[2] = "In�cio em:",
		[3] = "%d minuto(s)",
		[4] = "���",
		[5] = "Prepare-se!",
		[6] = "� ������������� � ������������� �",
		[7] = "%d seg.",
		[8] = "Para participar digite:",
		[9] = "%s",
		[10] = "[Sobre] Aguarde o fim do evento atual.",
		[11] = "[Sobre] Use %s <tempo>",
		[12] = "[Sobreviv�ncia] Voc� saiu do evento.",
		[13] = "[Sobreviv�ncia] Voc� saiu da �rea do evento.",
		[14] = "[Sobreviv�ncia] Voc� nao tem permissao para ficar nessa area.",
		[15] = "Vencedor: %s",
		[16] = "Matou %d players",
		[17] = "[Sistema] Voc� recebeu %d %s.",
		[18] = "Evento Cancelado!",
		[19] = "Motivo:",
		[20] = "[ Falta de participantes ]",
		[21] = "Aguarde o pr�ximo.",
		[22] = "Evento Iniciado!",
		[23] = "Aguarde o An�ncio do  vencedor.",
		[24] = "[Sobreviv�ncia] Nenhum evento aberto",
		[25] = "[Sobreviv�ncia] Voc� precisa estar acima do level %d",
		[26] = "[Sobreviv�ncia] Somente usu�rios vip podem usar este comando!",
		[27] = "[Sobreviv�ncia] Voc� precisa de %d resets",
		[28] = "[Sobreviv�ncia] Voc� precisa de %d M.Resets",
		[29] = "[Sobreviv�ncia] Sua classe n�o � permitida no evento.",
		[30] = "[Sobreviv�ncia] Voc� j� est� participando.",
		[31] = "[Sobreviv�ncia] Voc� foi movido.",
		[32] = "N�o mova ou relogue ou ser� desclassificado.",
		[33] = "[Sobreviv�ncia] Aguarde o inicio do evento.",
		[34] = "[Sobre] %s matou %s",
		[35] = "[Sobreviv�ncia]Voc� foi morto por %s",
	},
	["Spn"] = {
		[1] = "� ����� Evento Sobreviv�ncia ����� �",
		[2] = "In�cio em:",
		[3] = "%d minuto(s)",
		[4] = "���",
		[5] = "Prepare-se!",
		[6] = "� ������������� � ������������� �",
		[7] = "%d seg.",
		[8] = "Para participar digite:",
		[9] = "%s",
		[10] = "[Sobre] Aguarde o fim do evento atual.",
		[11] = "[Sobre] Use %s <tempo>",
		[12] = "[Sobreviv�ncia] Voc� saiu do evento.",
		[13] = "[Sobreviv�ncia] Voc� saiu da �rea do evento.",
		[14] = "[Sobreviv�ncia] Voc� nao tem permissao para ficar nessa area.",
		[15] = "Vencedor: %s",
		[16] = "Matou %d players",
		[17] = "[Sistema] Voc� recebeu %d %s.",
		[18] = "Evento Cancelado!",
		[19] = "Motivo:",
		[20] = "[ Falta de participantes ]",
		[21] = "Aguarde o pr�ximo.",
		[22] = "Evento Iniciado!",
		[23] = "Aguarde o An�ncio do  vencedor.",
		[24] = "[Sobreviv�ncia] Nenhum evento aberto",
		[25] = "[Sobreviv�ncia] Voc� precisa estar acima do level %d",
		[26] = "[Sobreviv�ncia] Somente usu�rios vip podem usar este comando!",
		[27] = "[Sobreviv�ncia] Voc� precisa de %d resets",
		[28] = "[Sobreviv�ncia] Voc� precisa de %d M.Resets",
		[29] = "[Sobreviv�ncia] Sua classe n�o � permitida no evento.",
		[30] = "[Sobreviv�ncia] Voc� j� est� participando.",
		[31] = "[Sobreviv�ncia] Voc� foi movido.",
		[32] = "N�o mova ou relogue ou ser� desclassificado.",
		[33] = "[Sobreviv�ncia] Aguarde o inicio do evento.",
		[34] = "[Sobre] %s matou %s",
		[35] = "[Sobreviv�ncia]Voc� foi morto por %s",
	},
}