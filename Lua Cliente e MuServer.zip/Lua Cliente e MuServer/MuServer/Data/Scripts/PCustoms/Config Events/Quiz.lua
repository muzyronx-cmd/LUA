Quiz_Config = {
	-- true ativa o envento, false desativa
	Ativado = true,

	-- COmando para responder a pergunta
	ComandoResposta = "/quiz",
	
	-- Comando para iniciar um quiz aleat�rio
	ComandoAbrir = "/abrirquiz",

	-- Comando para cancelar um quiz aberto
	ComandoCancelar = "/fimquiz",

 	-- tempo em minutos que o evento fica aberto, se ninguem responder ele encerrar� automaticamente
	TimeOut = 2, 

	-- Pontua��es do evento
	Premio = {
		{Quantidade = 10, Tabela = "CashShopData", Coluna = "WCoinC", Where = "AccountID", Tipo = 0},

	},

	-- Perguntas e respostas
	Perguntas = {
		-------------------------------- pregunta 1
		{
			Pergunta = {
				["Eng"] = "Quanto � 2+10=(?)=x2?",
				["Spn"] = "Quanto � 2+10=(?)=x2?",
				["Por"] = "Quanto � 2+10=(?)=x2?",
			},
			Resposta = {
				["Por"] = "24",
				["Eng"] = "24",
				["Spn"] = "24",
			},
		},

		-------------------------------- pregunta 2
		{
			Pergunta = {
				["Eng"] = "Quanto � 2+10=?",
				["Spn"] = "Quanto � 2+10=?",
				["Por"] = "Quanto � 2+10=?",
			},
			Resposta = {
				["Por"] = "12",
				["Eng"] = "12",
				["Spn"] = "12",
			},
		},

		-------------------------------- pregunta 3
		{
			Pergunta = {
				["Eng"] = "Quanto � 2+10=(?)=x2=(?)-4=?",
				["Spn"] = "Quanto � 2+10=(?)=x2=(?)-4=?",
				["Por"] = "Quanto � 2+10=(?)=x2=(?)-4=?",
			},
			Resposta = {
				["Por"] = "20",
				["Eng"] = "20",
				["Spn"] = "20",
			},
		},

		-------------------------------- pregunta 4
		{
			Pergunta = {
				["Eng"] = "Qual nome do Mu?",
				["Spn"] = "Qual nome do Mu?",
				["Por"] = "Qual nome do Mu?",
			},
			Resposta = {
				["Por"] = "muzyron-x",
				["Eng"] = "muzyron-x",
				["Spn"] = "muzyron-x",
			},
		},

		-------------------------------- pregunta 5
		{
			Pergunta = {
				["Eng"] = "Quanto � 15+10=(?)-9=?",
				["Spn"] = "Quanto � 15+10=(?)-9=?",
				["Por"] = "Quanto � 15+10=(?)-9=?",
			},
			Resposta = {
				["Por"] = "16",
				["Eng"] = "16",
				["Spn"] = "16",
			},
		},

		-------------------------------- pregunta 6
		{
			Pergunta = {
				["Eng"] = "Quanto � 65x6=?",
				["Spn"] = "Quanto � 65x6=?",
				["Por"] = "Quanto � 65x6=?",
			},
			Resposta = {
				["Por"] = "390",
				["Eng"] = "390",
				["Spn"] = "390",
			},
		},

		-------------------------------- pregunta 7
		{
			Pergunta = {
				["Eng"] = "Quanto � 34x7=?",
				["Spn"] = "Quanto � 34x7=?",
				["Por"] = "Quanto � 34x7=?",
			},
			Resposta = {
				["Por"] = "238",
				["Eng"] = "238",
				["Spn"] = "238",
			},
		},

		-------------------------------- pregunta 7
		{
			Pergunta = {
				["Eng"] = "Quanto � 164x3=?",
				["Spn"] = "Quanto � 164x3=?",
				["Por"] = "Quanto � 164x3=?",
			},
			Resposta = {
				["Por"] = "492",
				["Eng"] = "492",
				["Spn"] = "492",
			},
		},


	},

	-- Agenda do evento automatico
	Cron = {

	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 03},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 05},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 07},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 10},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 12},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 15},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 17},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 20},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 22},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 25},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 27},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 31},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 33},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 37},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 40},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 42},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 45},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 47},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 50},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 52},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 55},
	{DiaSemana = -1, Dia = -1, Hora = 09, Minuto = 57},

	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 03},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 05},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 07},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 10},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 12},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 15},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 17},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 20},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 22},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 25},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 27},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 31},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 33},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 37},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 40},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 42},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 45},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 47},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 50},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 52},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 55},
	{DiaSemana = -1, Dia = -1, Hora = 11, Minuto = 57},

	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 03},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 05},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 07},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 10},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 12},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 15},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 17},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 20},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 22},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 25},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 27},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 31},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 33},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 37},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 40},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 42},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 45},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 47},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 50},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 52},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 55},
	{DiaSemana = -1, Dia = -1, Hora = 14, Minuto = 57},


},

	Mensagens = {
		["Por"] = {
			[1] = "====== QUIZ AUTOM�TICO ======",
			[2] = "Utilize %s para responder",
			[3] = "Vencedor: %s",
			[4] = "Resposta: %s",
			[5] = "[Sistema] Resposta incorreta",
			[6] = "[Sistema] Parab�ns! Voc� acertou a resposta",
			[7] = "N�o houve vencedor",
			[8] = "[Sistema] Voc� recebeu 500k de HPoints",
		},
		["Eng"] = {
			[1] = "====== QUIZ AUTOM�TICO ======",
			[2] = "Utilize %s para responder",
			[3] = "Vencedor: %s",
			[4] = "Resposta: %s",
			[5] = "[Sistema] Resposta incorreta",
			[6] = "[Sistema] Parab�ns! Voc� acertou a resposta",
			[7] = "N�o houve vencedor",
			[8] = "[Sistema] Voc� recebeu 500k de HPoints",
		},
		["Spn"] = {
			[1] = "====== QUIZ AUTOM�TICO ======",
			[2] = "Utilize %s para responder",
			[3] = "Vencedor: %s",
			[4] = "Resposta: %s",
			[5] = "[Sistema] Resposta incorreta",
			[6] = "[Sistema] Parab�ns! Voc� acertou a resposta",
			[7] = "N�o houve vencedor",
			[8] = "[Sistema] Voc� recebeu 500k de HPoints",
		},
	}
}

return Quiz_Config
