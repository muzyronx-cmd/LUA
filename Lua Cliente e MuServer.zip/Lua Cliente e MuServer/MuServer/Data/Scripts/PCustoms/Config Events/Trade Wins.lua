TradeWins_Ativado = true

TradeWins_Agenda = {

	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 03},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 05},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 07},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 10},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 12},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 15},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 17},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 20},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 22},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 25},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 27},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 31},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 33},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 37},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 40},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 42},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 45},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 47},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 50},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 52},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 55},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 13, Minuto = 57},

	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 03},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 05},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 07},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 10},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 12},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 15},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 17},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 20},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 22},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 25},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 27},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 31},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 33},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 37},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 40},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 42},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 45},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 47},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 50},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 52},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 55},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 16, Minuto = 57},

	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 03},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 05},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 07},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 10},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 12},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 15},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 17},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 20},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 22},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 25},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 27},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 31},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 33},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 37},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 40},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 42},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 45},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 47},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 50},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 52},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 55},
	{DiaDoMes = -1, DiaDaSemana = -1, Hora = 18, Minuto = 57},

}

TradeWins_Mapas = {
{Nome = "/bar",		 Mapa = 0, X = 124, Y = 124},
{Nome = "/ferreiro", Mapa = 0, X = 116, Y = 140},
{Nome = "/lorencia2", Mapa = 0, X = 76,  Y = 155}, 
{Nome = "/cemiterio", Mapa = 0, X = 140, Y = 225},
{Nome = "/pista", 	  Mapa = 0, X = 112, Y = 72 }, 
{Nome = "/mago", 	  Mapa = 0, X = 120, Y = 113},
{Nome = "/igreja",	  Mapa = 2, X = 210, Y = 25},
{Nome = "/arena1", 	  Mapa = 6, X = 55, Y =  80}, 
{Nome = "/arena2", 	  Mapa = 6, X = 38, Y =  44}, 
{Nome = "/arena3", 	  Mapa = 6, X = 38, Y =  66}, 
{Nome = "/arena4", 	  Mapa = 6, X = 38, Y =  84}, 
{Nome = "/arena5", 	  Mapa = 6, X = 20, Y =  83}, 
{Nome = "/arena6", 	  Mapa = 6, X = 20, Y =  65}, 
{Nome = "/arena7", 	  Mapa = 6, X = 20, Y =  47}, 
{Nome = "/arena8", 	  Mapa = 6, X = 40, Y =  10}, 
{Nome = "/arena9", 	  Mapa = 6, X = 60, Y =  7 }, 
{Nome = "/arena10",   Mapa = 6, X = 90, Y =  40}, 
{Nome = "/arena11",   Mapa = 6, X = 90, Y =  115},
}

TradeWins_NpcClass = 249

TradeWins_CommandOpen = "/abrirtradewins"
TradeWins_CommandCancel = "/fimtradewins"

TradeWins_TempoMaximo = 1 -- Tempo m�ximo em minutos para do evento ser cancelado caso n�o tenha ganhadores

TradeWins_PremioMoeda = {Nome = "Cash", Quantidade = 50, Tabela = "CashShopData", Coluna = "WCoinC", Where = "AccountID", Tipo = 0}
TradeWins_PremioPonto = {Quantidade = 1, Tabela = "Character", Coluna = "tradewins", Where = "Name", Tipo = 1}
TradeWins_PremioPonto2 = {Quantidade = 1, Tabela = "Character", Coluna = "eventostotais", Where = "Name", Tipo = 1}
TradeWins_PremioReward = GET_ITEM(14, 123)

TradeWins_Messages = {
    ["Por"] = {
        [1] = "## Evento Trade Wins ##",
        [2] = "## Evento Trade Wins Acabou ##",
        [3] = "N�o houve vencedor!",
        [4] = "Vencedor: %s",
        [5] = "Pr�mio: %d %s",
        [6] = "J� existe um Trade Wins aberto",
        [7] = "Utilize %s para finalizar",
        [8] = "N�o existe um Trade Wins aberto",
        [9] = "Utilize %s para come�ar",
    },
	
	["Spn"] = {
        [1] = "## Evento Trade Wins ##",
        [2] = "## Evento Trade Wins Acabou ##",
        [3] = "N�o houve vencedor!",
        [4] = "Vencedor: %s",
        [5] = "Pr�mio: %d %s",
        [6] = "J� existe um Trade Wins aberto",
        [7] = "Utilize %s para finalizar",
        [8] = "N�o existe um Trade Wins aberto",
        [9] = "Utilize %s para come�ar",
    },
	["Eng"] = {
        [1] = "## Evento Trade Wins ##",
        [2] = "## Evento Trade Wins Acabou ##",
        [3] = "N�o houve vencedor!",
        [4] = "Vencedor: %s",
        [5] = "Pr�mio: %d %s",
        [6] = "J� existe um Trade Wins aberto",
        [7] = "Utilize %s para finalizar",
        [8] = "N�o existe um Trade Wins aberto",
        [9] = "Utilize %s para come�ar",
    },


}
