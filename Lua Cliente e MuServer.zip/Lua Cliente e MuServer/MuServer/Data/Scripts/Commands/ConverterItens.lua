ConversorItens = {}

function ConversorItens.Converter(aIndex, Arguments)

	local player = User.new(aIndex)
	local pInv = Inventory.new(aIndex)

	local Account = player:getAccountID()
	local comando = command:getString(Arguments, 1, 0)

	if comando == nil or string.len(comando) < 1 then		
		SendMessage(string.format("Use %s <item>", CONVERT_ITEM_COMMAND), aIndex, 1)
		return
	elseif player:getInterfaceUse() ~= 0 or player:getState() == 32 or player:getDieRegen() ~= 0 or player:getTeleport() ~= 0 
	then
        SendMessage(string.format("[Sistema] Feche outras janelas para utilizar o comando."), aIndex, 1)
		return 
	end
		
	for i in ipairs(CONVERT_ITEM_LIST) do	
		if comando == CONVERT_ITEM_LIST[i].Command
		then
			local valor = 0
			
			for slot = 12, 75 do
				if pInv:isItem(slot) ~= 0
				then
					if pInv:getIndex(slot) == GET_ITEM(CONVERT_ITEM_LIST[i].Section, CONVERT_ITEM_LIST[i].Index)
					then
						valor = valor + CONVERT_ITEM_LIST[i].Value[pInv:getLevel(slot)]
						InventoryDeleteItem(aIndex, slot)
						SendInventoryDeleteItem(aIndex, slot)
					end
				end
			end	
			
			DataBase.SetAddValue(CONVERT_ITEM_TABLE, CONVERT_ITEM_LIST[i].Column, valor, CONVERT_ITEM_WHERE, Account)

			SendMessage(string.format("Voce recebeu %d %s", valor, CONVERT_ITEM_LIST[i].CoinName), aIndex, 25)
			--SendMessage(string.format(" em troca de %d %s", quantidade, CONVERT_ITEM_LIST[i].Nome ), aIndex, 25)
			--LogAddC(1, string.format("[%s}%s trocou %d %s por %d %s",Account, player:getName(), quantidade, CONVERT_ITEM_LIST[i].Nome, valor, CONVERT_ITEM_LIST[i].CoinName))		
			return
		end
	end
end

Commands.Register(CONVERT_ITEM_COMMAND, ConversorItens.Converter)


return ConversorItens