MonsterReloadMap = {}

function MonsterReloadMap.Command(aIndex, Arguments)
    local player = User.new(aIndex)
	
	if player:getAuthority() ~= 32 and CheckGameMasterLevel(player:getAccountID(), player:getName(), RELOAD_MONSTER_MAP_GAME_MASTER_LEVEL) == 0
	then
		return
	end

    local map = command:getNumber(Arguments, 1)

    ReloadMonsterMap(map)
end


if RELOAD_MONSTER_MAP_SWITCH ~= 0
then
    Commands.Register(RELOAD_MONSTER_MAP_SYNTAX, MonsterReloadMap.Command)
end

return MonsterReloadMap