MakeItem = {}

--[[
	Comando Free para criação de item
	Criador: Fernando Vergis
    Contato: (16) 9 9223-9230
    Criado: 29/09/2019
    Atualizado para o último update. Update 93 100% funcionando
]]--

local COORD_X = 0
local COORD_Y = 1
local MAP_USER = 0

function MakeItem.CommandAut(staffIndex, Arguments)
    local autorizado = false
	if MAKE_COMMAND_SWITCH == 1
	then
	local player = User.new(staffIndex)
		for i in ipairs(MAKE_COMMAND_AUTORIZATION) do
			if MAKE_COMMAND_AUTORIZATION[i]._somenteChar == false  and player:getAccountID() == MAKE_COMMAND_AUTORIZATION[i]._login then
				autorizado = true
				break
			elseif player:getAccountID() == MAKE_COMMAND_AUTORIZATION[i]._login and player:getName() == MAKE_COMMAND_AUTORIZATION[i]._char
			then
				autorizado = true
				break
			end
		end
		if autorizado == false
		then
			SendMessage(string.format("%s",MESSAGE_COMMAND_NOT_AUTHORIZED), staffIndex, 1)
			return
		end
    end
	
    local COMMAND_USE = command:getString(Arguments, 0, 0)

    if COMMAND_USE == MAKE_COMMAND_ITEM then
        MakeItem.CommandMakeItem(staffIndex,Arguments)
    elseif COMMAND_USE == MAKE_COMMAND_SET then 
        MakeItem.CommandMakeSet(staffIndex,Arguments)
    elseif COMMAND_USE == COMMAND_MAKEITEM_OPT then
        MakeItem.CommandMakeItemAllOptions(staffIndex,Arguments)
    end

end

function MakeItem.CommandMakeItem(aIndex, Arguments)

    local player = User.new(aIndex)
    local SECTION = command:getNumber(Arguments, 1)
    local INDEX = command:getNumber(Arguments, 2)
    local FULL = command:getNumber(Arguments, 3)
    local QTD = command:getNumber(Arguments, 4)
    
	if INDEX < 0 then
        SendMessage(string.format("[Sistema] Item nao existente %s", player:getName()), aIndex, 1)
        return
    end
	
	if SECTION > 15 then
        SendMessage(string.format("[Sistema] Categoria não existe %s", player:getName()), aIndex, 1)
        return
    end
	
	local  max_opt = 63
	
	if SECTION == 12 then
		max_opt = 31
	end
	
    if QTD > 1 then
	    for i = 1, QTD do
            if FULL == 1 then			
                ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(SECTION, INDEX), 15, 255, 1, 1, 7, max_opt)
            else
                ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(SECTION, INDEX), 0, 0, 0, 0, 0, 0)
            end
		end
    elseif FULL == 1 then
        ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(SECTION, INDEX), 15, 255, 1, 1, 7, max_opt)
    else
        ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(SECTION, INDEX), 0, 0, 0, 0, 0, 0)
    end

    --SendMessage(string.format("%s criou o Item Index:%d Section:%d",UserGetName(aIndex), INDEX, SECTION), aIndex, 1)
end

function MakeItem.CommandMakeSet(aIndex, Arguments)
    
	local player = User.new(aIndex)
    --Argumentos inseridos no comando Seção do Item, Index do Item, Full ou Não (0 ou 1)
    local INDEX = command:getNumber(Arguments, 1)
    local FULL = command:getNumber(Arguments, 2)
	
    if INDEX < 0 then
        SendMessage(string.format("[Sistema] Item nao existente %s", player:getName()), aIndex, 1)
        return
    end
	
	for i = 7, 11 do
		if FULL == 1 then
			ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(i, INDEX), 15, 255, 1, 1, 7, 63)
		else
			ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(i, INDEX), 0, 0, 0, 0, 0, 0)
		end
	end

	--SendMessage(string.format("%s Item criado",UserGetName(aIndex), INDEX, SECTION), aIndex, 1)
end

function MakeItem.CommandMakeItemAllOptions(aIndex, Arguments)
    
	local player = User.new(aIndex)
    local section = command:getNumber(Arguments, 1) -- Seção do item
	local index	= command:getNumber(Arguments, 2) --Index do item
	local level = command:getNumber(Arguments, 3) -- Level +0 até +15
	local luck = command:getNumber(Arguments, 4) -- 0 pra não ter, 1 pra ter
	local skill = command:getNumber(Arguments, 5) -- 0 pra não ter, 1 pra ter
	local opt = command:getNumber(Arguments, 6) -- Testar 
    local exc = command:getNumber(Arguments, 7) -- Testar
    local qtd = command:getNumber(Arguments, 8) -- Quantidade de itens
    if qtd > 1 then 
        for i = 1, qtd do
            ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(section, index), level, 2, luck, skill, opt, exc)
        end
    else 
        ItemSerialCreate(aIndex, 236, 0, 0, GET_ITEM(section, index), level, 2, luck, skill, opt, exc)
    end
    
end

Commands.Register(MAKE_COMMAND_ITEM, MakeItem.CommandAut)
Commands.Register(MAKE_COMMAND_SET, MakeItem.CommandAut)
Commands.Register(COMMAND_MAKEITEM_OPT, MakeItem.CommandAut)