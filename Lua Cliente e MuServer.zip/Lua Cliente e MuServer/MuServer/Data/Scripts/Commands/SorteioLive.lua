SorteioLive = {}

local sorteioStarted = false
local comando = ""
local vencedores = 1
local realizador = nil
local participantes = {}
local ganhadores = {}
local timer = nil
local indexToMove = nil
local sorteioDone = false

function SorteioLive.Init()
	
	Commands.CallCommand(SorteioLive.CommandEnter)
	Commands.Register(SL_COMMAND_OPEN,SorteioLive.CommandOpen)
	Commands.Register(SL_COMMAND_END,SorteioLive.CommandEnd)
	Commands.Register(SL_COMMAND_INFO,SorteioLive.CommandInfo)
	Commands.Register(SL_COMMAND_CANCEL,SorteioLive.CommandCancel)
	Commands.Register(SL_COMMAND_PREMIAR,SorteioLive.CommandPremiar)
	GameServerFunctions.PlayerLogout(SorteioLive.PleyerLeft)
	GameServerFunctions.EnterCharacter(SorteioLive.PleyerJoin)	

end

function SorteioLive.CommandOpen(aIndex, Arguments)
	local isAllowed = false
	local player = User.new(aIndex)
	local Name = player:getName(aIndex)
	local Account = player:getAccountID(aIndex)
	
	if SL_AUTH_MODE == 0 then
		for i in ipairs(SL_AUTH) do
			if Account == SL_AUTH[i].Login and Name == SL_AUTH[i].Char
			then
				isAllowed = true
			end
		end
	else
		if player:getAuthority(aIndex) > 1
		then
			isAllowed = true
		end
	end
	
	if isAllowed == false
	then			
		SendMessage(string.format("[Sistema] Voc� n�o tem autoriza��o para usar o comando. "), aIndex, 1)
		return
	end
	
	if sorteioStarted == true
	then
		SendMessage(string.format("[Sistema] J� existe sorteio em andamento. "), aIndex, 1)
		return
	end
	
	
	if string.sub(command:getString(Arguments, 1, 0), 1, 1) ~= '/'
	then	
		SendMessage(string.format("[Sistema] Comando deve conter / "), aIndex, 1)
		SorteioLive.Clear()
		return
	end
	
	comando = command:getString(Arguments, 1, 0)
	vencedores = command:getNumber(Arguments, 2)
	
	if vencedores <= 0 or vencedores == nil
	then
		SendMessage(string.format("[Sistema] M�nimo de vencedores � 1 ."), aIndex, 1)
		SorteioLive.Clear()
		return
	end
	
	sorteioStarted = true
	realizador = aIndex
	
	SendMessageGlobal(string.format("[%s]", Name),0)
	SendMessageGlobal(string.format("Digite %s para participar do sorteio.", comando),0)
	
	timer = Timer.Interval(SL_TIME_ANNOUNCE, SorteioLive.AnunciarSorteio)
	return
end

function SorteioLive.CommandEnd(aIndex, Arguments)
	local isAllowed = false
	local player = User.new(aIndex)
	local Name = player:getName(aIndex)
	local Account = player:getAccountID(aIndex)
	
	if SL_AUTH_MODE == 0 then
		for i in ipairs(SL_AUTH) do
			if Account == SL_AUTH[i].Login and Name == SL_AUTH[i].Char
			then
				isAllowed = true
			end
		end
	else
		if player:getAuthority(aIndex) > 1
		then
			isAllowed = true
		end
	end
	
	if isAllowed == false
	then			
		SendMessage(string.format("[Sistema] Voc� n�o tem autoriza��o para usar o comando"), aIndex, 1)
		return
	end

	if sorteioStarted == false
	then
		SendMessage(string.format("[Sistema] N�o existe sorteio em andamento ."), aIndex, 1)
		return
	end
	
	if sorteioDone == true
	then
		SendMessage(string.format("[Sistema] Sorteio finalizado, use %s", SL_COMMAND_PREMIAR ), aIndex, 1)
		return
	end
		
	if #participantes <= 0 or #participantes < vencedores
	then
		SendMessage(string.format("[Sistema] N�o h� participantes o suficiente ."), aIndex, 1)
		return
	end
	
	Timer.Cancel(timer)
	
	ganhadores = {}
	
	for i = 1, vencedores do
		local vencedor = GetRand(1, #participantes)

		for a, name in ipairs(participantes) do
			if a == vencedor
			then				
				InsertKey(ganhadores, name)
				ganhadores[name] = {Index = participantes[name].Index, Nome = name, Show = 0}
				SendMessage(string.format("[Sorteio] Parab�ns voc� foi o %d� colocado. ", i), participantes[name].Index, 1)
				RemoveKey(participantes, a)
			end
		end
	end
	
	SendMessageGlobal(string.format("[%s]", player:getName(aIndex)),0)
	SendMessageGlobal(string.format("Sorteio realizado com sucesso "),0)
	SendMessageGlobal(string.format("..:: RESULTADO DO SORTEIO ::.."),0)
	
	local tempo = #ganhadores
	
	sorteioDone = true
	
	Timer.Repeater(1, tempo, SorteioLive.ShowWinner)
	SendMessage(string.format("[Sistema] Utilize %s para entregar a premia��o para os ganhadores", SL_COMMAND_PREMIAR), aIndex, 1)
	return
end

function SorteioLive.ShowWinner()
	for i, name in ipairs(ganhadores) do
		if ganhadores[name].Show == 0
		then
			SendMessageGlobal(string.format("%d� Lugar %s", i, ganhadores[name].Nome),0)
			ganhadores[name].Show = 1
			break
		end
	end
end

function SorteioLive.CommandPremiar(aIndex, Arguments)
	
	local isAllowed = false
	local player = User.new(aIndex)
	local Name = player:getName(aIndex)
	local Account = player:getAccountID(aIndex)
	
	if SL_AUTH_MODE == 0 then
		for i in ipairs(SL_AUTH) do
			if Account == SL_AUTH[i].Login and Name == SL_AUTH[i].Char
			then
				isAllowed = true
			end
		end
	else
		if player:getAuthority(aIndex) > 1
		then
			isAllowed = true
		end
	end
	
	if isAllowed == false
	then			
		SendMessage(string.format("[Sistema] Voc� n�o tem autoriza��o para usar o comando. "), aIndex, 1)
		return
	end
	
	if sorteioStarted == false
	then
		SendMessage(string.format("[Sistema] N�o existe sorteio em andamento."), aIndex, 1)
		return
	end
	
	if sorteioDone == false
	then
		SendMessage(string.format("[Sistema] Finalize o sorteio primeiro."), aIndex, 1)
		return
	end
	
	if indexToMove ~= nil
	then
		Teleport(indexToMove, 0,125,125)
		indexToMove = nil
	end
	
	if #ganhadores <= 0
	then
		SendMessage(string.format("[Sistema] N�o h� mais ganhadores para premiar."), aIndex, 1)
		SendMessageGlobal(string.format("[%s]", player:getName(aIndex)),0)
		SendMessageGlobal(string.format("Sorteio finalizado com sucesso !"),0)
		SendMessageGlobal(string.format("A premia��o foi entregue aos vencedores."),0)		
		SorteioLive.Clear()
		return
	end
	
	local Map = player:getMapNumber(aIndex)
	local x = player:getX(aIndex)
	local y = player:getY(aIndex)
	
	for i, name in ipairs(ganhadores) do
		if player:getConnected(ganhadores[name].Index) == 3 then	
			Teleport(ganhadores[name].Index, Map, x, y)
			indexToMove = ganhadores[name].Index
			RemoveKey(ganhadores, i)
			break
		end
		SendMessage(string.format("[Aviso] %s esta offline .", name), aIndex, 1)
		SendMessage(string.format("o pr�ximo ganhador foi chamado."), aIndex, 1)
	end
end

function SorteioLive.CommandInfo(aIndex, Arguments)
	local isAllowed = false
	local player = User.new(aIndex)
	for i in ipairs(SL_AUTH) do
		if Account == SL_AUTH[i].Login and Name == SL_AUTH[i].Char
		then
			isAllowed = true
		end
	end
	
	if player:getAuthority(aIndex) > 1
	then
		isAllowed = true
	end
	
	if isAllowed == false
	then			
		SendMessage(string.format("[Sistema] Voc� n�o tem autoriza��o para usar o comando ."), aIndex, 1)
		return
	end

	if sorteioStarted == false
	then
		SendMessage(string.format("[Sistema] N�o existe sorteio em andamento."), aIndex, 1)
		return
	end
	
	if #participantes > 0
	then
		SendMessage(string.format("[Sistema] H� %s jogadores registrados no sorteio.", #participantes), aIndex, 1)
		return
	else
		SendMessage(string.format("[Sistema] N�o h� jogadores registrados no sorteio."), aIndex, 1)
		return
	end
end

function SorteioLive.CommandEnter(aIndex, Command, Arguments)
local player = User.new(aIndex)
	if Command ~= comando 
	then		
		return		
	end
	
	if sorteioStarted == false
	then
		SendMessage(string.format("[Sistema] N�o existe sorteio em andamento ."), aIndex, 1)
		return
	end
	
	local Name = player:getName(aIndex)
	
	if has_key(participantes, Name)
	then
		SendMessage(string.format("[Sistema] Voc� j� esta participando do sorteio ."), aIndex, 1)
		return
	end
		
	InsertKey(participantes, Name)
	participantes[Name] = {Index = aIndex, Nome = Name}
	
	SendMessage(string.format("[Sistema] %s entrou no sorteio .", Name), realizador, 25)
	SendMessage(string.format("[Sistema] Entrada registrada com sucesso."), aIndex, 25)
	SendMessage(string.format("[Sistema] Voc� esta participando do sorteio ."), aIndex, 25)
	return
end

function SorteioLive.PleyerLeft(aIndex, Name, Account)	
	if has_key(participantes, Name)
	then
		RemoverTable(participantes, Name)
		SendMessage(string.format("[Sistema] %s saiu no sorteio.", Name), realizador, 1)
	end
end

function SorteioLive.PleyerJoin(aIndex)
local player = User.new(aIndex)
	local Name = player:getName(aIndex)
	if sorteioDone then
		if has_key(ganhadores, Name)
		then
			ganhadores[Name].Index = aIndex
		end
	end
end

function SorteioLive.AnunciarSorteio()

 --   SendMessageGlobal(string.format("[%s]", player:getName(realizador)),0)
	SendMessageGlobal(string.format("Digite %s para participar do sorteio.", comando),0)
end

function SorteioLive.Clear()
	sorteioStarted = false
	sorteioDone = false
	comando = ""
	vencedores = 1
	realizador = nil
	participantes = {}
	ganhadores = {}
	if timer ~= nil
	then
		Timer.Cancel(timer)
	end
	timer = nil
	return
end

function SorteioLive.CommandCancel(aIndex, Arguments)
	local isAllowed = false
	local player = User.new(aIndex)
	for i in ipairs(SL_AUTH) do
		if Account == SL_AUTH[i].Login and Name == SL_AUTH[i].Char
		then
			isAllowed = true
		end
	end
	
	if player:getAuthority(aIndex) > 1
	then
		isAllowed = true
	end
	
	if isAllowed == false
	then			
		SendMessage(string.format("[Sistema] Voc� n�o tem autoriza��o para usar o comando ."), aIndex, 1)
		return
	end

	if sorteioStarted == false
	then
		SendMessage(string.format("[Sistema] N�o existe sorteio em andamento."), aIndex, 1)
		return
	end
	
	SendMessageGlobal(string.format("[%s]", player:getName(realizador)),0)
	SendMessageGlobal(string.format("Sorteio cancelado.", comando),0)
	SorteioLive.Clear()
	return
end

SorteioLive.Init()

return SorteioLive