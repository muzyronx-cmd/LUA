SummonBoss = {}

local summon_boss_open = false
local drop_item_config = nil

function SummonBoss.Init()
    if summon_boss_switch then 
        Commands.Register(summon_boss_command, SummonBoss.CreateMonster)

        GameServerFunctions.MonsterDie(SummonBoss.MonsterDie)
        GameServerFunctions.MonsterDie(SummonBoss.MonsterDieGiveItem)
    end
end

function SummonBoss.CreateMonster(aIndex, Arguments)
    
    local player = User.new(aIndex)
    local idioma = player:getLanguage()
    local mensagens = summon_message_boss[idioma]

    if not AuthorizarionAccount.CheckAuth(aIndex, Arguments) then
        return
    end

    if summon_boss_open	then
		SendMessage(mensagens[0], aIndex, 1)
		return
	end

    summon_boss_open = true

	local class_monster = command:getNumber(Arguments, 1)
	local drop = command:getNumber(Arguments, 2)
	local map = command:getNumber(Arguments, 3)
	local coord_x = command:getNumber(Arguments, 4)
	local coord_y = command:getNumber(Arguments, 5)
    
    local aIndexMonster = nil
    drop_item_config = summon_boss_drop_config[drop]

    if drop_item_config == nil then 
        SendMessage('Drop não existente ou mal configurado', aIndex, 1)
        return
    end

	local indexMonster = AddMonster(map)

	if indexMonster == -1 then
		LogAddC(2, string.format("[Summon] Problema ao criar o Monstro: %d", class_monster))
		return
	end

    local monster = User.new(indexMonster)

	SetPositionMonster(indexMonster, map)
	SetMonster(indexMonster, class_monster)
	monster:setX(coord_x)
	monster:setY(coord_y)

    if aIndexMonster == nil then
        aIndexMonster = indexMonster
    end

    monster = nil

    local monster = User.new(aIndexMonster)
    local nameMonster = monster:getName()
	local mapName = MAPS_STRING[map].name

    if summon_boss_teleport_staff then 
        Teleport(aIndex, map, coord_x, coord_y)
    end

	SendMessage(string.format(mensagens[1], player:getName(), nameMonster), aIndex, 1)
	SendMessage(string.format(mensagens[2], mapName, coord_x, coord_y), aIndex, 1)

	if summon_boss_announce_global then
		SendMessageGlobal(string.format(mensagens[1], player:getName(), nameMonster), 0)
		SendMessageGlobal(string.format(mensagens[6], summon_command_go_boss), 0)
	end

	LogAddC(2, string.format("[Summon] %s Criou boss: %d, map: %d, x: %d, y: %d, drop: %d", player:getName(), class_monster, map, coord_x, coord_y, drop))
end

function SummonBoss.MonsterDie(aIndex, Monster)

	if not summon_boss_open then
		return
	end

	local player = User.new(aIndex)
	local monster = User.new(Monster)

    local idioma = player:getLanguage()
    local mensagens = summon_message_boss[idioma]

	local namePlayer = player:getName(aIndex)
	local nameMonster = monster:getName(Monster)

    if summon_boss_detah_announce_global then
        SendMessageGlobal(string.format(mensagens[4], namePlayer, nameMonster), 0)
    end
end

function SummonBoss.MonsterDieGiveItem(aIndex, Monster)

	if not summon_boss_open then
		return
	end

	local player = User.new(aIndex)
	local monster = User.new(Monster)

    local namePlayer = player:getName()
    local mapPlayer = player:getMapNumber()
    local coordXp = player:getX()
    local coordYp = player:getY()

    local nameMonster = monster:getName()

    local idioma = player:getLanguage()
    local mensagens = summon_message_boss[idioma]

    local section = drop_item_config.section
    local index = drop_item_config.index
    local level = drop_item_config.level
    local luck = drop_item_config.luck
    local skill = drop_item_config.skill
    local option = drop_item_config.option
    local exc = drop_item_config.exc
    local ancient = drop_item_config.ancient
    local days = drop_item_config.days

    local hexIndex = GET_ITEM(section, index)

    local inventoryClear = InventoryCheckSpaceByItem(aIndex, hexIndex)

    if inventoryClear == 1 then
        ItemSerialCreateComplete(aIndex, 236, 0, 0, hexIndex, level, 255, luck, skill, option, aIndex, exc, ancient, days)
    else
        ItemSerialCreateComplete(aIndex, mapPlayer, coordXp, coordYp, hexIndex, level, 255, luck, skill, option, aIndex, exc, ancient, days)
    end

    if inventoryClear == 1 then 
         SendMessageGlobal(string.format(mensagens[4], namePlayer, nameMonster), 0)
        SendMessage(mensagens[5], aIndex, 1)
    else 
         SendMessageGlobal(string.format(mensagens[4], namePlayer, nameMonster), 0)
        SendMessage(mensagens[7], aIndex, 1)
    end

    summon_boss_open = false

    LogAddC(2, string.format("[Summon] %s recebeu o prêmio %d.", namePlayer, drop_item_config.name))
end

SummonBoss.Init()


return SummonBoss