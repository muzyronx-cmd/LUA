OpenFolder("Definitions")
InterfaceController = {}

local CMLockoutAlert = false
local cmText1 = ""
local cmText2 = ""
local cmText3 = ""

local InterfaceText = {
	["Por"] = {
		[1] = "Fechar janela de grupo (P)",
		[2] = "Personagem (C)",
		[3] = "Inventário (I/V)",
		[4] = "Guild (G)",		
		[5] = "Horário Servidor: %s  |  Horário Local: %s",
	},
	["Eng"] = {
		[1] = "Close party window (P)",
		[2] = "Character (C)",
		[3] = "Inventory (I/V)",
		[4] = "Guild (G)",
		[5] = "ServerTime: %s  |  Local Time: %s",
	},
	["Spn"] = {
		[1] = "Cerrar ventana de grupo (P)",
		[2] = "Personaje (C)",
		[3] = "Inventario (I/V)",
		[4] = "Guild (G)",
		[5] = "Horario Servidor: %s  |  Horario Local: %s",
	},
}

local BloodCastleLevel = {
	[1] = {Min = 15, Max = 80},
	[2] = {Min = 81, Max = 130},
	[3] = {Min = 131, Max = 180},
	[4] = {Min = 181, Max = 230},
	[5] = {Min = 231, Max = 280},
	[6] = {Min = 281, Max = 330},
	[7] = {Min = 331, Max = 400},
}

local BloodCastleText = {
	["Por"] = {
		[1] = "Mensajeiro do Arcanjo",
		[2] = "Sua vontade de ajudar o arcanjo é",
		[3] = "admirável. Mas tenha cuidado, pois o",
		[4] = "Blood Castle é um lugar perigoso.",
		[5] = "Que Deus esteja com você!",
		[6] = "Blood Castle 1 (Nível 15-80)",
		[7] = "Blood Castle 2 (Nível 81-130)",
		[8] = "Blood Castle 3 (Nível 131-180)",
		[9] = "Blood Castle 4 (Nível 181-230)",
		[10] = "Blood Castle 5 (Nível 231-280)",
		[11] = "Blood Castle 6 (Nível 281-330)",
		[12] = "Blood Castle 7 (Nível 331-400)",
	},
	["Eng"] = {
		[1] = "Mensajeiro do Arcanjo",
		[2] = "Sua vontade de ajudar o arcanjo é",
		[3] = "admirável. Mas tenha cuidado, pois o",
		[4] = "Blood Castle é um lugar perigoso.",
		[5] = "Que Deus esteja com você!",
		[6] = "Blood Castle 1 (Nível 15-80)",
		[7] = "Blood Castle 2 (Nível 81-130)",
		[8] = "Blood Castle 3 (Nível 131-180)",
		[9] = "Blood Castle 4 (Nível 181-230)",
		[10] = "Blood Castle 5 (Nível 231-280)",
		[11] = "Blood Castle 6 (Nível 281-330)",
		[12] = "Blood Castle 7 (Nível 331-400)",
	},
	["Spn"] = {
		[1] = "Mensajeiro do Arcanjo",
		[2] = "Sua vontade de ajudar o arcanjo é",
		[3] = "admirável. Mas tenha cuidado, pois o",
		[4] = "Blood Castle é um lugar perigoso.",
		[5] = "Que Deus esteja com você!",
		[6] = "Blood Castle 1 (Nível 15-80)",
		[7] = "Blood Castle 2 (Nível 81-130)",
		[8] = "Blood Castle 3 (Nível 131-180)",
		[9] = "Blood Castle 4 (Nível 181-230)",
		[10] = "Blood Castle 5 (Nível 231-280)",
		[11] = "Blood Castle 6 (Nível 281-330)",
		[12] = "Blood Castle 7 (Nível 331-400)",
	},
}

local ChaosMachineText = {
	["Por"] = {
		[1] = "Selecione um tipo de combinação",
		[2] = "Combinação comum é usada para",
		[3] = "criar convites de eventos (BC e DS)",
		[4] = "Combinação Comum",
		[5] = "Chaos Dragon Axe, Chaos Lightning Staff,",
		[6] = "Chaos Nature Bow",
		[7] = "Chaos Weapon",
		[8] = "Combinar",
	},
	["Eng"] = {
		[1] = "Select a combination type",
		[2] = "Regular combination is used for",
		[3] = "create events invitaions (BC and DS)",
		[4] = "Regular Combination",
		[5] = "Chaos Dragon Axe, Chaos Lightning Staff,",
		[6] = "Chaos Nature Bow",
		[7] = "Chaos Weapon",
		[8] = "Combine",
	},
	["Spn"] = {
		[1] = "Selecione um tipo de combinação",
		[2] = "Combinação comum é usada para",
		[3] = "criar convites de eventos (BC e DS)",
		[4] = "Combinação Comum",
		[5] = "Chaos Dragon Axe, Chaos Lightning Staff,",
		[6] = "Chaos Nature Bow",
		[7] = "Chaos Weapon",
		[8] = "Combinar",
	},
}

local DevilSquareLevel = {
	[1] = {Min = 15, Max = 130},
	[2] = {Min = 131, Max = 180},
	[3] = {Min = 181, Max = 230},
	[4] = {Min = 231, Max = 280},
	[5] = {Min = 281, Max = 330},
	[6] = {Min = 331, Max = 400},
}

local DevilSquareText = {
	["Por"] = {
		[1] = "Devil Square",
		[2] = "Você ganhou a chance de provar a sua bravura.",
		[3] = "Até agora ninguém entrou no Devil Square.",
		[4] = "Jamais um ser humano foi até lá.",
		[5] = "Não acredite nas coisas que você verá lá.",
		[6] = "Confie somente em sua bravura e força",
		[7] = "Somente eles o manterão vivo.",
		[8] =  "Devil Square 1 (Nível 15-130)",
		[9] =  "Devil Square 2 (Nível 131-180)",
		[10] = "Devil Square 3 (Nível 181-230)",
		[11] = "Devil Square 4 (Nível 231-280)",
		[12] = "Devil Square 5 (Nível 281-330)",
		[13] = "Devil Square 6 (Nível 331-400)",
	},
	["Eng"] = {
		[1] = "Devil Square",
		[2] = "You have earned a chance to prove your bravery.",
		[3] = "So far no one has entered the Devil Square.",
		[4] = "Never has a human being gone there.",
		[5] = "Do not believe the things you will see there.",
		[6] = "Trust only in your bravery and strength",
		[7] = "Only they will keep you alive.",
		[8] =  "Devil Square 1 (Level 15-130)",
		[9] =  "Devil Square 2 (Level 131-180)",
		[10] = "Devil Square 3 (Level 181-230)",
		[11] = "Devil Square 4 (Level 231-280)",
		[12] = "Devil Square 5 (Level 281-330)",
		[13] = "Devil Square 6 (Level 331-400)",
	},
	["Spn"] = {
		[1] = "Devil Square",
		[2] = "Usted ganó la oportunidad de probar su valentía.",
		[3] = "Hasta ahora nadie ha entrado en Devil Square.",
		[4] = "Jamás un ser humano ha ido hasta allí.",
		[5] = "No crea las cosas que verá allí.",
		[6] = "Confíe solamente en su valentía y fuerza",
		[7] = "Solamente ellos lo mantendrán vivo.",
		[8] =  "Devil Square 1 (Nível 15-130)",
		[9] =  "Devil Square 2 (Nível 131-180)",
		[10] = "Devil Square 3 (Nível 181-230)",
		[11] = "Devil Square 4 (Nível 231-280)",
		[12] = "Devil Square 5 (Nível 281-330)",
		[13] = "Devil Square 6 (Nível 331-400)",
	},
}

local JerintText = {
	["Por"] = {
		[1] = "Jerint",

		[2] = "Sem a Ordem de Gaion, você",
		[3] = "não poderá entrar para os",
		[4] = "Guardiões da Fortaleza do Império.",
		[5] = "Pode me mostrar a ordem?",

		[6] = "Sem o Secromicon Completo, você",
		[7] = "não poderá entrar para os",
		[8] = "Guardiões da Fortaleza do Império.",
		[9] = "Pode me mostrar o secromicon?",

		[10] = "Você só poderá entrar se estiver em party",
		[11] = "Entrar",
	},
	["Eng"] = {
		[1] = "Jerint",

		[2] = "Without the Order of Gaion, you",
		[3] = "cannot enter the Empire's",
		[4] = "Fortress Guardians.",
		[5] = "Can you show me the order?",

		[6] = "Without the Complete Secromicon, you",
		[7] = "cannot enter the Empire's",
		[8] = "Fortress Guardians.",
		[9] = "Can you show me the secromicon?",

		[10] = "You can only enter if you are in a party",
		[11] = "Enter",
	},
	["Spn"] = {
		[1] = "Jerint",

		[2] = "Sin la Orden de Gaion, usted",
		[3] = "no podrá entrar para los",
		[4] = "Guardianes de la Fortaleza del Imperio.",
		[5] = "¿Puedes mostrarme la orden?",

		[6] = "Sin el Secromicon Completo, usted",
		[7] = "no podrá entrar para los",
		[8] = "Guardianes de la Fortaleza del Imperio.",
		[9] = "¿Puedes mostrarme el secromicon?",

		[10] = "Usted sólo podrá entrar si está en party",
		[11] = "Entrar",
	},
}

local serverTime = os.time()

function DrawBox(x, y, w, h)
    DrawBar(x, y, w, 1)
    DrawBar(x, y+1, 1, h-2)
    DrawBar(x+w-1, y+1, 1, h-2)
    DrawBar(x, y+h-1, w, 1)
end

local MainProc_Handle = {}
function MainProc()
	for i in pairs(MainProc_Handle) do
		MainProc_Handle[i].callback()
	end
end

function InterfaceController.MainProc(callback, ...)
	MainProc_Handle[callback] = { callback = callback }
end

local AfterMainProc_Handle = {}

function AfterMainProc()
	local addX = WindowGetWidthAdd()
	local offset = WindowGetWidth()-640

	if GetEscMenuState() == 1 then
		EnableAlphaTest()
		local state = 0
		if MousePosX() >=266+addX and MousePosX() <= 266+addX+110 and MousePosY() >= 123 and MousePosY() <= 123+28 then
			state = 1
		end
		DrawButton.Menu(state, 266+addX, 123, 110, 28)
		state = 0
		if MousePosX() >=266+addX and MousePosX() <= 266+addX+110 and MousePosY() >= 153 and MousePosY() <= 153+28 then
			state = 1
		end
		DrawButton.Menu(state, 266+addX, 153, 110, 28)
		state = 0
		if MousePosX() >=266+addX and MousePosX() <= 266+addX+110 and MousePosY() >= 183 and MousePosY() <= 183+28 then
			state = 1
		end
		DrawButton.Menu(state, 266+addX, 183, 110, 28)
		state = 0
		if MousePosX() >=266+addX and MousePosX() <= 266+addX+110 and MousePosY() >= 213 and MousePosY() <= 213+28 then
			state = 1
		end
		DrawButton.Menu(state, 266+addX, 213, 110, 28)
		state = 0
		if MousePosX() >=266+addX and MousePosX() <= 266+addX+110 and MousePosY() >= 243 and MousePosY() <= 243+28 then
			state = 1
		end
		DrawButton.Menu(state, 266+addX, 243, 110, 28)
		SetFontType(1)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
       	RenderText3(266+addX+(110/2), 133, GetTextBmdMessage(381), 110, 8)
       	RenderText3(266+addX+(110/2), 163, GetTextBmdMessage(382), 110, 8)
       	RenderText3(266+addX+(110/2), 193, GetTextBmdMessage(383), 110, 8)
       	RenderText3(266+addX+(110/2), 223, GetTextBmdMessage(385), 110, 8)
       	RenderText3(266+addX+(110/2), 253, GetTextBmdMessage(384), 110, 8)
		DisableAlphaBlend()
	end

	if GetCmMenuState() == 1 then
		EnableAlphaTest()
		RenderImage2(600076, 240+addX, 125, 160, 28, 0.001, 0.003, 0.89652734, 0.622833, 1, 1, 1.0)
		RenderImage2(600077, 240+addX, 153, 160, 28, 0.001, 0.003, 0.89652734, 0.622833, 1, 1, 1.0)
		RenderImage2(600077, 240+addX, 181, 160, 28, 0.001, 0.003, 0.89652734, 0.622833, 1, 1, 1.0)
		RenderImage2(600077, 240+addX, 209, 160, 28, 0.001, 0.003, 0.89652734, 0.622833, 1, 1, 1.0)
		RenderImage2(600077, 240+addX, 237, 160, 28, 0.001, 0.003, 0.89652734, 0.622833, 1, 1, 1.0)
		RenderImage2(600078, 240+addX, 265, 160, 28, 0.001, 0.003, 0.89652734, 0.622833, 1, 1, 1.0)

		local state = 0
		if MousePosX() >= 256+addX and MousePosX() <= 256+addX+127 and MousePosY() >= 179 and MousePosY() <= 208 then
			state = 1
		end
		DrawButton.Large(state, 256+addX, 179, 128, 29)

		state = 0
		if MousePosX() >= 256+addX and MousePosX() <= 256+addX+127 and MousePosY() >= 250 and MousePosY() <= 278 then
			state = 1
		end
		DrawButton.Large(state, 256+addX, 250, 128, 29)

		SetFontType(1)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,128,0,240)
		RenderText3(240+addX+(160/2), 135, ChaosMachineText[GetLanguage()][1], 160, 8)
		SetFontType(0)
		SetTextColor(242,242,242,240)
       	RenderText3(240+addX+(160/2), 155, ChaosMachineText[GetLanguage()][2], 160, 8)
       	RenderText3(240+addX+(160/2), 165, ChaosMachineText[GetLanguage()][3], 160, 8)

		RenderText3(240+addX+(160/2), 225, ChaosMachineText[GetLanguage()][5], 160, 8)
       	RenderText3(240+addX+(160/2), 235, ChaosMachineText[GetLanguage()][6], 160, 8)

		SetFontType(1)
		RenderText3(240+addX+(160/2), 189, ChaosMachineText[GetLanguage()][4], 128, 8)
       	RenderText3(240+addX+(160/2), 260, ChaosMachineText[GetLanguage()][7], 128, 8)
		DisableAlphaBlend()
	end

	if CheckWindowOpen(UIParty) == 1 then
		EnableAlphaTest()
		if MousePosX() >= 450+offset + 23 and MousePosX() <= 450+offset + 23+25 and MousePosY() >= 393 and MousePosY() <= 393+24 then
           DrawButton.Close(1, 450+offset + 23, 393, 25, 24)
		   DrawTooltip(450+offset, 378, InterfaceText[GetLanguage()][1])
        else
            DrawButton.Close(0, 450+offset + 23, 393, 25, 24)
        end
		DisableAlphaBlend()
	end

	if CheckWindowOpen(UIGuild) == 1 or CheckWindowOpen(UINPCGuild) == 1 then
		EnableAlphaTest()
		if MousePosX() >= 450+offset + 23 and MousePosX() <= 450+offset + 23+25 and MousePosY() >= 393 and MousePosY() <= 393+24 then
           DrawButton.Close(1, 450+offset + 23, 393, 25, 24)
        else
            DrawButton.Close(0, 450+offset + 23, 393, 25, 24)
        end
		DisableAlphaBlend()
	end

	if CheckWindowOpen(UIBloodCastle) == 1 then
		EnableAlphaTest()
		RenderImage2(542029, 450+offset, 0, 191, 429, 0.0, 0.0, 0.83, 0.935, 1, 1, 1.0)


		SetFontType(1)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
        RenderText3(450+offset+95, 15, BloodCastleText[GetLanguage()][1], 150, 8)

		SetFontType(0)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
        RenderText3(450+offset+95, 55, BloodCastleText[GetLanguage()][2], 150, 8)
        RenderText3(450+offset+95, 65, BloodCastleText[GetLanguage()][3], 150, 8)
        RenderText3(450+offset+95, 75, BloodCastleText[GetLanguage()][4], 150, 8)
        RenderText3(450+offset+95, 95, BloodCastleText[GetLanguage()][5], 150, 8)

		local newy = 0
		for i = 1, 7 do
			SetFontType(1)
			SetTextBg(0,0,0, 0)
			if UserGetLevel() >= BloodCastleLevel[i].Min and UserGetLevel() <= BloodCastleLevel[i].Max then
				local state = 0
				if MousePosX() >= 450+offset+20 and MousePosX() <= 450+offset+20+150 and MousePosY() >= 126+newy and MousePosY() <= 126+newy+26 then
					state = 1
				end
				DrawButton.Large(state, 450+offset+20, 126+newy, 150, 26)
				SetTextColor(255,255,255,200)
			else
				DrawButton.Large(3, 450+offset+20, 126+newy, 150, 26)
				SetTextColor(150,150,150,200)
			end
        	RenderText3(450+offset+95, 126+newy+9, BloodCastleText[GetLanguage()][5+i], 150, 8)
			newy = newy+33
		end
		local closestate = 0
		if MousePosX() >= 450+offset+23 and MousePosX() <= 450+offset+23+25 and MousePosY() >= 393 and MousePosY() <= 393+24 then
			closestate = 1
			DrawTooltip(450+offset+25, 382, MenuOptions_Config.Texts[GetLanguage()][2])
		end

		DrawButton.Close(closestate, 450+offset+23, 393, 25, 24)

		DisableAlphaBlend()
	end

	if CheckWindowOpen(UIDevilSquare) == 1 then
		EnableAlphaTest()
		RenderImage2(542029, 450+offset, 0, 191, 429, 0.0, 0.0, 0.83, 0.935, 1, 1, 1.0)


		SetFontType(1)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
        RenderText3(450+offset+95, 15, DevilSquareText[GetLanguage()][1], 150, 8)

		SetFontType(0)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
        RenderText3(450+offset+95, 45, DevilSquareText[GetLanguage()][2], 150, 8)
        RenderText3(450+offset+95, 65, DevilSquareText[GetLanguage()][3], 150, 8)
        RenderText3(450+offset+95, 80, DevilSquareText[GetLanguage()][4], 150, 8)
        RenderText3(450+offset+95, 95, DevilSquareText[GetLanguage()][5], 150, 8)
        RenderText3(450+offset+95, 110, DevilSquareText[GetLanguage()][6], 150, 8)
        RenderText3(450+offset+95, 125, DevilSquareText[GetLanguage()][7], 150, 8)

		local newy = 0
		for i = 1, 6 do
			SetFontType(1)
			SetTextBg(0,0,0, 0)
			if UserGetLevel() >= DevilSquareLevel[i].Min and UserGetLevel() <= DevilSquareLevel[i].Max then
				local state = 0
				if MousePosX() >= 450+offset+20 and MousePosX() <= 450+offset+20+150 and MousePosY() >= 155+newy and MousePosY() <= 155+newy+26 then
					state = 1
				end
				DrawButton.Large(state, 450+offset+20, 155+newy, 150, 26)
				SetTextColor(255,255,255,200)
			else
				DrawButton.Large(3, 450+offset+20, 155+newy, 150, 26)
				SetTextColor(150,150,150,200)
			end
        	RenderText3(450+offset+95, 155+newy+9, DevilSquareText[GetLanguage()][7+i], 150, 8)
			newy = newy+33
		end
		local closestate = 0
		if MousePosX() >= 450+offset+23 and MousePosX() <= 450+offset+23+25 and MousePosY() >= 393 and MousePosY() <= 393+24 then
			closestate = 1
			DrawTooltip(450+offset+25, 382, MenuOptions_Config.Texts[GetLanguage()][2])
		end

		DrawButton.Close(closestate, 450+offset+23, 393, 25, 24)

		DisableAlphaBlend()
	end

	if CheckWindowOpen(UIJerint) == 1 then
		EnableAlphaTest()
		local offset = WindowGetWidth()-640
		RenderImage2(542029, 450+offset, 0, 191, 429, 0.0, 0.0, 0.83, 0.935, 1, 1, 1.0)


		SetFontType(1)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
        RenderText3(450+offset+95, 15, JerintText[GetLanguage()][1], 150, 8)

		SetFontType(0)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
		local itemindex = GET_ITEM(14, 102)

		if tonumber(os.date("%w", os.time())) == 0 then
			RenderText3(450+offset+95, 55, JerintText[GetLanguage()][6], 150, 8)
       		RenderText3(450+offset+95, 65, JerintText[GetLanguage()][7], 150, 8)
       		RenderText3(450+offset+95, 75, JerintText[GetLanguage()][8], 150, 8)
       		RenderText3(450+offset+95, 95, JerintText[GetLanguage()][9], 150, 8)
			itemindex = GET_ITEM(14, 109)
		else
			RenderText3(450+offset+95, 55, JerintText[GetLanguage()][2], 150, 8)
			RenderText3(450+offset+95, 65, JerintText[GetLanguage()][3], 150, 8)
			RenderText3(450+offset+95, 75, JerintText[GetLanguage()][4], 150, 8)
			RenderText3(450+offset+95, 95, JerintText[GetLanguage()][5], 150, 8)
		end

		SetFontType(1)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,240)
		RenderText3(450+offset+95, 150, GetNameByIndex(itemindex), 150, 8)
		local state = 0
		if MousePosX() >= 450+offset+69 and MousePosX() <= 450+offset+69+51 and MousePosY() >= 190 and MousePosY() <= 190+21 then
			state = 1
		end
		DrawButton.Large(state, 450+offset+69, 190, 51, 21)
		SetFontType(1)
		SetTextBg(0,0,0, 0)
		SetTextColor(255,255,255,200)
        RenderText3(450+offset+95, 196, JerintText[GetLanguage()][11], 150, 8)

		local closestate = 0
		if MousePosX() >= 450+offset+23 and MousePosX() <= 450+offset+23+25 and MousePosY() >= 393 and MousePosY() <= 393+24 then
			closestate = 1
			DrawTooltip(450+offset+25, 382, MenuOptions_Config.Texts[GetLanguage()][2])
		end

		DrawButton.Close(closestate, 450+offset+23, 393, 25, 24)
		
		DisableAlphaBlend()

		SetBlend(1)
		CreateItem(450+offset+95, 140,0, 0, itemindex, 0, 0, 0, 1.0)
		EndDrawBar()
	end

	if CheckWindowOpen(UIChaosBox) == 1 and GetChaosState() == 0  and GetChaosGenesisOpen() == 0 then
		EnableAlphaTest()
		if MousePosX() >= 260+offset+((190-32)/2) and MousePosX() <= 260+offset+((190-32)/2)+32 and MousePosY() >= 380 and MousePosY() <= 380 + 32
		then			
			DrawTooltip(260+offset+((190-32)/2), 365, ChaosMachineText[GetLanguage()][8])
			
			if CheckPressedKey(Keys.LButton) == 1
			then
				RenderImage2(600035, 260+offset+((190-32)/2), 380, 32, 32, 0.018, 0.4247492, 0.812731823, 0.2023746, 1, 1, 1.0)
				
				DisableClickClient()
			else-- 
				RenderImage2(600035, 260+offset+((190-32)/2), 380, 32, 32, 0.018, 0.2123746, 0.812731823, 0.2023746, 1, 1, 1.0)
			end
		else
			RenderImage2(600035, 260+offset+((190-32)/2), 380, 32, 32, 0.018, 0.0, 0.812731823, 0.2023746, 1, 1, 1.0)
		end
		DisableAlphaBlend()
	end
	
	EnableAlphaTest()
	SetFontType(11)
	SetTextBg(0,0,0, 0)
	SetTextColor(237, 214, 161, 155)
	RenderText3(WindowGetWidth()/2+1, 435, InterfaceText[GetLanguage()][5]:format(os.date("%H:%M:%S", serverTime), os.date("%H:%M:%S", os.time())), 200, 8)

	DisableAlphaBlend()

	for i in pairs(AfterMainProc_Handle) do
		AfterMainProc_Handle[i].callback()
	end

	if CMLockoutAlert then
		EnableAlphaTest()
		RenderImage2(41007, 205+addX, 86, 225, 4, 0, 0, 0.83203125, 0.625, 1, 1, 1.0)
        RenderImage2(41010, 205+addX, 148, 225, 30, 0.0, 0.0, 0.8322874124, 0.6042874124, 1, 1, 1.0)
        RenderImage2(41010, 205+addX, 119, 225, 30, 0.0, 0.0, 0.8322874124, 0.6042874124, 1, 1, 1.0)
        RenderImage2(41010, 205+addX, 90, 225, 30, 0.0, 0.0, 0.8322874124, 0.6042874124, 1, 1, 1.0)
        RenderImage2(41007, 205+addX, 179, 225, 4, 0, 0, 0.83203125, 0.625, 1, 1, 1.0)

        SetFontType(5)
        SetTextBg(0,0,0, 0)
        SetTextColor(255,20,20,255)
        RenderText3(320+addX, 105, cmText1, 200, 8)
        SetFontType(0)
        SetTextBg(0,0,0, 0)
        SetTextColor(242,250,250,255)
        RenderText3(320+addX, 120, cmText2, 200, 8)
        RenderText3(320+addX, 130, cmText3, 200, 8)

        if MousePosX() >= 285+addX and MousePosX() <= 285+60+addX and MousePosY() >= 150 and MousePosY() <= 150+18 then
            RenderImage2(41011, 285+addX, 150, 60, 18, 0.00688282, 0.313344848, 0.538486151, 0.333344848, 1, 1, 1.0)
        else
            RenderImage2(41011, 285+addX, 150, 60, 18, 0.00688282, 0.002127840, 0.538486151, 0.323344848, 1, 1, 1.0)
        end

		DisableAlphaBlend()
	end

end

function InterfaceController.AfterMainProc(callback, ...)
	AfterMainProc_Handle[callback] = { callback = callback }
end

local BeforeMainProc_Handle = {}

function BeforeMainProc()

	if UserGetMap() == 82 then
		SetBlend()
		glColor4f(0.0, 0.0, 0.0, 1.0)
		DrawBar(0, 0, (WindowGetWidth()-640)/2+5, 480)
		DrawBar(0, 420, WindowGetWidth(), 60)
		DrawBar(WindowGetWidth()/2+320, 0, (WindowGetWidth()-640)/2+5, 480)
		EndDrawBar()
		EnableAlphaTest()
		RenderImage2(600082, WindowGetWidth()/2-320, -60, 640, 480, 0.01, 0.0, 0.612415, 0.92784, 1, 1, 1.0)
		DisableAlphaBlend()
	end

	for i in pairs(BeforeMainProc_Handle) do
		BeforeMainProc_Handle[i].callback()
	end
end

function InterfaceController.BeforeMainProc(callback, ...)
	BeforeMainProc_Handle[callback] = { callback = callback }
end

local ClientProtocol_Handle = {}

function ClientProtocol(Packet, PacketName)
	if Packet == 1 and PacketName == "TaxSwitch" then
		local state = GetBytePacket(PacketName, -1)
		ClearPacket(PacketName)
		SetTaxSwitch(state)
		return
	end

	if Packet == 7 and PacketName == "UpdateClass" then
		local class = GetBytePacket(PacketName)
		if class == nil or class < 0 or class > 3 then class = 1 end
		setValueRegKey("CharacterClass", class)
		ClearPacket(PacketName)
		return
	end

	if Packet == 18 and PacketName == "CMLockout" then
		local len = GetBytePacket(PacketName, -1)		
		cmText1 = GetCharPacketLength(PacketName, -1, len)

		len = GetBytePacket(PacketName, -1)		
		cmText2 = GetCharPacketLength(PacketName, -1, len)

		len = GetBytePacket(PacketName, -1)		
		cmText3 = GetCharPacketLength(PacketName, -1, len)
			
		ClearPacket(PacketName)

		CMLockoutAlert = true
		return
	end

	if Packet == 26 and PacketName == "UpdateTopKill" then
		local class = GetDwordPacket(PacketName)
		setValueRegKey("TopKillCount", class)
		ClearPacket(PacketName)
		return
	end

	if Packet == 31 and PacketName == "ServerTime" then
		local size = GetBytePacket(PacketName, -1)
        local ts = GetCharPacketLength(PacketName, -1, size)
        if ts ~= nil then
            serverTime = tonumber(ts) or serverTime
        end
		ClearPacket(PacketName)
		return
	end

	if Packet == 31 and PacketName == "wareHousePrice" then
		local price = GetDwordPacket(PacketName, -1)
		Warehouse_Config.BuyPrice[2].Name = "VGolds"
		Warehouse_Config.BuyPrice[2].Value = price
		ClearPacket(PacketName)
		return
	end

	
	
	for i in pairs(ClientProtocol_Handle) do
		if ClientProtocol_Handle[i].callback(Packet, PacketName) then
			return
		end
	end
	ClearPacket(PacketName)
end

function InterfaceController.ClientProtocol(callback, ...)
	ClientProtocol_Handle[callback] = { callback = callback }
end

local MainProcWorldKey_Handle = {}

function MainProcWorldKey(key)
	if key == Keys.Escape then
		if GetEscMenuState() == 1 then
			CloseEscMenu()
		end
	end

	for i in pairs(MainProcWorldKey_Handle) do
		MainProcWorldKey_Handle[i].callback(key)
	end
end

function InterfaceController.MainProcWorldKey(callback, ...)
	MainProcWorldKey_Handle[callback] = { callback = callback }
end

local ScrollMouse_Handle = {}

function ScrollMouse(value)
	for i in pairs(ScrollMouse_Handle) do
		ScrollMouse_Handle[i].callback(value)
	end
end

function InterfaceController.ScrollMouse(callback, ...)
	ScrollMouse_Handle[callback] = { callback = callback }
end

local InterfaceClickRightEvent_Handle = {}

function InterfaceClickRightEvent()
	for i in pairs(InterfaceClickRightEvent_Handle) do
		InterfaceClickRightEvent_Handle[i].callback()
	end
end

function InterfaceController.InterfaceClickRightEvent(callback, ...)
	InterfaceClickRightEvent_Handle[callback] = { callback = callback }
end

local InterfaceClickEvent_Handle = {}

function InterfaceClickEvent()
	if CMLockoutAlert then
		local addX = WindowGetWidthAdd()
		if MousePosX() >= 285+addX and MousePosX() <= 285+60+addX and MousePosY() >= 150 and MousePosY() <= 150+18 then
			CMLockoutAlert = false
			return false
		end
	end

	for i in pairs(InterfaceClickEvent_Handle) do
		InterfaceClickEvent_Handle[i].callback()
	end
end

function InterfaceController.InterfaceClickEvent(callback, ...)
	InterfaceClickEvent_Handle[callback] = { callback = callback }
end

local InterfaceUpdateProc_Handle = {}

function UpdateProc()
	if GetCmMenuState() == 1 and CheckWindowOpen(UIChaosBox) == 0 then
		CloseCmMenu()
	end

	for i in pairs(InterfaceUpdateProc_Handle) do
		InterfaceUpdateProc_Handle[i].callback()
	end
end

function InterfaceController.UpdateProc(callback)
	InterfaceUpdateProc_Handle[callback] = { callback = callback }
end

local InterfaceUpdateMouse_Handle = {}

function UpdateMouse()

	if CMLockoutAlert then
		DisableClickClient()
	end

	local addX = WindowGetWidthAdd()

	if GetCmMenuState() == 1 then
		if MousePosX() >= 256+addX and MousePosX() <= 256+addX+127 and MousePosY() >= 179 and MousePosY() <= 208 then
			CloseCmMenu()
		end

		if MousePosX() >= 256+addX and MousePosX() <= 256+addX+127 and MousePosY() >= 250 and MousePosY() <= 278 then
			CloseCmMenu()
		end

	end


	if GetEscMenuState() == 1 then
		for i = 123, 246, 30 do
			if MousePosX() >=266+addX and MousePosX() <= 266+addX+110 and MousePosY() >= i and MousePosY() <= i+28 then
				CloseEscMenu()
			end
		end
	end


	if CheckWindowOpen(UIJerint) == 1 then
		local offset = WindowGetWidth()-640

		if CheckPressedKey(Keys.LButton) ~= 0 then
			if MousePosX() >= 450+offset+23 and MousePosX() <= 450+offset+23+25 and MousePosY() >= 393 and MousePosY() <= 393+24 then
				CloseWindow(UIJerint)
			end
		end
	end

	if CheckWindowOpen(UIChatWindow) == 0 then
		if MousePosX() > 280+addX and MousePosX() < 360 + addX and MousePosY() > 410 and MousePosY() < 435 then
			DisableClickClient()
		end
	end


	for i in pairs(InterfaceUpdateMouse_Handle) do
		InterfaceUpdateMouse_Handle[i].callback()
	end
end

function InterfaceController.UpdateMouse(callback)
	InterfaceUpdateMouse_Handle[callback] = { callback = callback }
end

local InterfaceUpdateKey_Handle = {}

function UpdateKey()
	if CMLockoutAlert then
		DisableClickClient()
		if CheckPressedKey(Keys.Return) == 1 or CheckPressedKey(Keys.Escape) == 1 then
			CMLockoutAlert = false
		end
	end

	if CheckPressedKey(Keys.Tab) == 1 then DisableClickClient() end
	if CheckWindowOpen(UIChatWindow) ~= 0 then
		if CheckRepeatKey(Keys.ControlKey) == 1 then
			if CheckRepeatKey(Keys.Back) == 1 or CheckPressedKey(Keys.Back) == 1 then
				CloseWindow(UIChatWindow)
				DisableClickClient()
			end
		end
	end
	for i in pairs(InterfaceUpdateKey_Handle) do
		InterfaceUpdateKey_Handle[i].callback()
	end
end

function InterfaceController.UpdateKey(callback)
	InterfaceUpdateKey_Handle[callback] = { callback = callback }
end

local InterfacePlayerDraw_Handle = {}

function MainPlayerDraw()
	for i in pairs(InterfacePlayerDraw_Handle) do
		InterfacePlayerDraw_Handle[i].callback()
	end
end

function InterfaceController.PlayerDraw(callback)
	InterfacePlayerDraw_Handle[callback] = { callback = callback }
end

local FinalBoot_Handle = {}

function FinalBoot()
	for i in pairs(FinalBoot_Handle) do
		FinalBoot_Handle[i].callback()
	end

	local resolution = GetResolution()
	if resolution < 0 or resolution > 8 or FontByResolution[resolution] == nil then resolution = 0 end
	SetFontValue(FontByResolution[resolution])
	setValueRegKey("FontValue", FontByResolution[resolution])
end

function InterfaceController.FinalBoot(callback)
	FinalBoot_Handle[callback] = { callback = callback }
end

local AfterScriptLoad_Handle = {}

function AfterScriptLoad()
	NewMenu.SetWindowInfo()

	for i in pairs(AfterScriptLoad_Handle) do
		AfterScriptLoad_Handle[i].callback()
	end
end

function InterfaceController.AfterScriptLoad(callback)
	AfterScriptLoad_Handle[callback] = { callback = callback }
end

local LoadImages_Handle = {}

function LoadImages()
	for i in pairs(LoadImages_Handle) do
		LoadImages_Handle[i].callback()
	end
end

function InterfaceController.LoadImages(callback)
	LoadImages_Handle[callback] = { callback = callback }
end

--[[
CALL FOLDER NEED STAY HERE
--]]

FontByResolution = {
	[0] = 12, --640x480
	[1] = 13, --800x600
	[2] = 14, --1024x768
	[3] = 16, --1280x1024
	[4] = 16, --1366x768
	[5] = 16, --1440x900
	[6] = 16, --1600x900
	[7] = 16, --1680x1050
	[8] = 16, --1920x1080
}

OpenFolder("Configs")
OpenFolder("Systems")


return InterfaceController