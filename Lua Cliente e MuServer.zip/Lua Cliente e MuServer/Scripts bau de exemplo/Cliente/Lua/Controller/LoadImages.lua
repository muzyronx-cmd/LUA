--[[
here you can upload images, I recommend using from the number 40000
--]]

-- MagMode
local GL_NEAREST = 0x2600
local GL_LINEAR = 0x2601

-- WrapMode
local GL_CLAMP = 0x2900
local GL_REPEAT = 0x2901

function LoadImages()
	LoadImage("Interface\\Central_Back.jpg"                     , 40002 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\Central_Info_Back.tga"                , 40003 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\Central_Delete.tga"                   , 40004 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\Custom\\btn-previous.tga"             , 40005 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\Custom\\btn-next.tga"                 , 40006 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\mini_map_ui_blacksmith.tga"        , 40007 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\PlayerPoint.jpg"                   , 40008 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\none.tga"                          , 40009 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\edBtUcx.tga"                       , 40010 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\edBtUcx_1.tga"                     , 40011 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\YYB6BUk.tga"                       , 40012 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\mini_map_ui_blacksmith.tga"        , 40013 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\mini_map_ui_Potion.tga"            , 40014 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\mini_map_ui_baul.tga"              , 40015 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\mini_map_ui_Que.tga"               , 40016 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\mini_map_ui_party.tga"             , 40017 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Maps\\mini_map_ui_mob.tga"               , 40018 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\WarehouseMenu_Back.tga"       , 41000 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\nis_hframe.jpg"                       , 41001 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\MacroUI\\MacroUI_OptionButton.tga"    , 41002 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\Window_Back.jpg"                      , 41003 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\Title_Back.tga"                       , 41004 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\menu_geral.jpg"               , 41005 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Message_box.jpg"  			, 41006 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Message_box2.jpg" 			, 41007 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\nis_vframe.jpg"               , 41008 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Trash.jpg"                    , 41009 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Message_box1.jpg" 			, 41010 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Ok97d.jpg"                    , 41011 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Cancel97d.jpg"                , 41012 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Shop_Back.jpg"                , 41013 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Level_buttonN.jpg"            , 41014 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\vcash.jpg"                    , 41015 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\vgold.jpg"                    , 41016 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Menu_CashShop.jpg"            , 41017 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Level_button.jpg"             , 41018 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Progress_Back.jpg"            , 41019 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Slider.tga"                   , 41020 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\securitycenter.jpg"           , 41021 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\ViewItem_Back.tga"            , 41022 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\auction_ico.jpg"  			, 41023 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Reload.tga"                   , 41024 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Item_Back01_Fix.jpg"          , 41025 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Item_Back01_Fix.jpg"          , 41025 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\CharacterSelect_Button01.jpg"         , 41026 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\CharacterSelect_Button02.jpg"         , 41027 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\CharacterSelect_Button03.jpg"         , 41028 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO.jpg"             , 41029 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_BORDA.tga"             , 41030 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_BK_OFF.tga"            , 41031 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_BK_ON.tga"             , 41032 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_MG_OFF.tga"            , 41033 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_MG_ON.tga"             , 41034 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_ELF_OFF.tga"           , 41035 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_ELF_ON.tga"            , 41036 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_SM_OFF.tga"            , 41037 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_SM_ON.tga"             , 41038 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\eventpoints.jpg"              , 41039 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Menu_A.jpg"                   , 41040 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\Menu_AutoPotion.jpg"          , 41041 , GL_LINEAR, GL_REPEAT)
	LoadImage("Interface\\Ranking_Back.jpg"                     , 41042 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO.tga"             , 41043 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO2.tga"            , 41044 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO3.tga"            , 41045 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO4.tga"            , 41046 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO5.tga"            , 41047 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO6.tga"            , 41048 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\ViewItem_Back_Visual.tga"     , 41049 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\ScrollBar_Down.jpg"           , 41050 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\ScrollBar_Down_Clicked.jpg"   , 41051 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\ScrollBar_Up.jpg"             , 41052 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\ScrollBar_Up_Clicked.jpg"     , 41053 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO2_H.tga"          , 41054 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO2_P.tga"          , 41055 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO3_H.tga"          , 41056 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO3_P.tga"          , 41057 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO4_H.tga"          , 41058 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO4_P.tga"          , 41059 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO5_H.tga"          , 41060 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO5_P.tga"          , 41061 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO6_H.tga"          , 41062 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO6_P.tga"          , 41063 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO_H.tga"           , 41064 , GL_LINEAR, GL_REPEAT)
	LoadImage("Custom\\Interface\\SELECT_FUNDO_P.tga"           , 41065 , GL_LINEAR, GL_REPEAT)

	--NOVA
	LoadImage("Custom\\Interface\\Interface_duel.tga"           , 591000 , GL_LINEAR, GL_REPEAT) --INTERFACE DUEL
	LoadImage("Custom\\Interface\\btn_changeclass_sm.tga"       , 599994 , GL_LINEAR, GL_REPEAT) --CHANGE CLASS BUTTON SM
	LoadImage("Custom\\Interface\\btn_changeclass_bk.tga"       , 599995 , GL_LINEAR, GL_REPEAT) --CHANGE CLASS BUTTON BK
	LoadImage("Custom\\Interface\\btn_changeclass_me.tga"       , 599996 , GL_LINEAR, GL_REPEAT) --CHANGE CLASS BUTTON ME
	LoadImage("Custom\\Interface\\btn_changeclass_mg.tga"       , 599997 , GL_LINEAR, GL_REPEAT) --CHANGE CLASS BUTTON MG
	LoadImage("Interface\\GB_Ponto.tga"                         , 599998 , GL_LINEAR, GL_REPEAT) --INTERFACE GUARDIAN B�U
	LoadImage("Interface\\GB_Chest.tga"                         , 599999 , GL_LINEAR, GL_REPEAT) --INTERFACE GUARDIAN PONTO
	LoadImage("Custom\\Interface\\central_locked.tga"           , 600000 , GL_LINEAR, GL_REPEAT) --CENTRAL CADEADO PNG
	LoadImage("Custom\\Interface\\ChangeClass_SM.tga"           , 600001 , GL_LINEAR, GL_REPEAT) --CLASSE ON SM
	LoadImage("Custom\\Interface\\ChangeClass_BK.tga"           , 600002 , GL_LINEAR, GL_REPEAT) --CLASSE ON BK
	LoadImage("Custom\\Interface\\ChangeClass_ELF.tga"          , 600003 , GL_LINEAR, GL_REPEAT) --CLASSE ON ELF
	LoadImage("Custom\\Interface\\ChangeClass_MG.tga"           , 600004 , GL_LINEAR, GL_REPEAT) --CLASSE ON MG
	LoadImage("Custom\\Interface\\ChangeClass_SM_OFF.tga"       , 600005 , GL_LINEAR, GL_REPEAT) --CLASSE OFF SM
	LoadImage("Custom\\Interface\\ChangeClass_BK_OFF.tga"       , 600006 , GL_LINEAR, GL_REPEAT) --CLASSE OFF BK
	LoadImage("Custom\\Interface\\ChangeClass_ELF_OFF.tga"      , 600007 , GL_LINEAR, GL_REPEAT) --CLASSE OFF ELF
	LoadImage("Custom\\Interface\\ChangeClass_MG_OFF.tga"       , 600008 , GL_LINEAR, GL_REPEAT) --CLASSE OFF MG
	LoadImage("Custom\\Interface\\central_blocked.jpg"          , 600009 , GL_LINEAR, GL_REPEAT) --CENTRAL SELECT CHAR CADEADO
	LoadImage("Custom\\Interface\\central_rejected.jpg"         , 600010 , GL_LINEAR, GL_REPEAT) --CENTRAL SELECT CHAR REJEITADO "X"
	LoadImage("Custom\\Interface\\interface_square.jpg"         , 600011 , GL_LINEAR, GL_REPEAT) --QUADRADO DO GUARDI�O DE ITENS
	LoadImage("Custom\\Interface\\main_frame_left.tga"          , 600012 , GL_LINEAR, GL_REPEAT) --INTERFACE ESQUERDA
	LoadImage("Custom\\Interface\\main_frame_right.tga"         , 600013 , GL_LINEAR, GL_REPEAT) --INTERFACE DIREITA
	LoadImage("Custom\\Interface\\btn_autopotion.jpg"           , 600014 , GL_LINEAR, GL_REPEAT) --BUTTON AUTO POTION
	LoadImage("Custom\\Interface\\btn_menu.jpg"                 , 600015 , GL_LINEAR, GL_REPEAT) --BUTTON MENU
	LoadImage("Custom\\Interface\\btn_party_v2.jpg"             , 600016 , GL_LINEAR, GL_REPEAT) --BUTTON PARTY
	LoadImage("Custom\\Interface\\btn_inventory_v2.jpg"         , 600017 , GL_LINEAR, GL_REPEAT) --BUTTON INVENTARIO
	LoadImage("Custom\\Interface\\btn_character_v2.jpg"         , 600018 , GL_LINEAR, GL_REPEAT) --BUTTON CHARACTER
	LoadImage("Custom\\Interface\\btn_lock_v2.jpg"              , 600019 , GL_LINEAR, GL_REPEAT) --BUTTON CENTRAL
	LoadImage("Custom\\Interface\\btn_guild_v2.jpg"             , 600020 , GL_LINEAR, GL_REPEAT) --BUTTON GUILD
	LoadImage("Custom\\Interface\\btn_back_v2.jpg"              , 600021 , GL_LINEAR, GL_REPEAT) --BUTTON VOLTAR
	LoadImage("Custom\\Interface\\btn_arrowleft.jpg"            , 600022 , GL_LINEAR, GL_REPEAT) --BUTTON SETA LEFT
	LoadImage("Custom\\Interface\\btn_arrowright.jpg"           , 600023 , GL_LINEAR, GL_REPEAT) --BUTTON SETA RIGHT
	LoadImage("Custom\\Interface\\btn_discord.jpg"              , 600024 , GL_LINEAR, GL_REPEAT) --BUTTON DISCORD
	LoadImage("Custom\\Interface\\btn_info.jpg"                 , 600025 , GL_LINEAR, GL_REPEAT) --BUTTON INFORMA��O
	LoadImage("Custom\\Interface\\btn_close_v2.jpg"             , 600026 , GL_LINEAR, GL_REPEAT) --BUTTON CLOSE
	LoadImage("Custom\\Interface\\btn_repair_v2.jpg"            , 600027 , GL_LINEAR, GL_REPEAT) --BUTTON REPARAR
	LoadImage("Custom\\Interface\\btn_openstore_v2.jpg"         , 600028 , GL_LINEAR, GL_REPEAT) --BUTTON ABRIR LOJA
	LoadImage("Custom\\Interface\\btn_settings_v2.jpg"          , 600029 , GL_LINEAR, GL_REPEAT) --BUTTON CONFIGURA��ES
	LoadImage("Custom\\Interface\\btn_next.jpg"                 , 600030 , GL_LINEAR, GL_REPEAT) --BUTTON PR�XIMO
	LoadImage("Custom\\Interface\\btn_previous.jpg"             , 600031 , GL_LINEAR, GL_REPEAT) --BUTTON ANTERIOR
	LoadImage("Custom\\Interface\\btn_plus_v2.jpg"              , 600032 , GL_LINEAR, GL_REPEAT) --BUTTON + PLUS VERMELHO (UPAR PONTOS)
	LoadImage("Custom\\Interface\\btn_circle_v2.jpg"            , 600033 , GL_LINEAR, GL_REPEAT) --BUTTON OK TRADE
	LoadImage("Custom\\Interface\\btn_news.jpg"                 , 600034 , GL_LINEAR, GL_REPEAT) --BUTTON NOTICIAS
	LoadImage("Custom\\Interface\\btn_mix_v2.jpg"               , 600035 , GL_LINEAR, GL_REPEAT) --BUTTON MIX CHAOS MACHINE
	LoadImage("Custom\\Interface\\btn_tradex.jpg"               , 600036 , GL_LINEAR, GL_REPEAT) --BUTTON TRADEX
	LoadImage("Custom\\Interface\\btn_confirmar_v2.jpg"         , 600037 , GL_LINEAR, GL_REPEAT) --BUTTON CONFIRMAR
	LoadImage("Custom\\Interface\\btn_cancel_v2.jpg"            , 600038 , GL_LINEAR, GL_REPEAT) --BUTTON CANCELAR
	LoadImage("Custom\\Interface\\btn_deposit_v2.jpg"           , 600039 , GL_LINEAR, GL_REPEAT) --BUTTON DEPOSITAR BAU
	LoadImage("Custom\\Interface\\btn_withdraw_v2.jpg"          , 600040 , GL_LINEAR, GL_REPEAT) --BUTTON RETIRAR BAU
	LoadImage("Custom\\Interface\\Item_Back01_v2.jpg"           , 600041 , GL_LINEAR, GL_REPEAT) --INTERFACE BLACK
	LoadImage("Custom\\Interface\\btn_small_v2.jpg"             , 600042 , GL_LINEAR, GL_REPEAT) --BUTTON PEQUENO
	LoadImage("Custom\\Interface\\btn_medium_v2.jpg"            , 600043 , GL_LINEAR, GL_REPEAT) --BUTTON MEDIUM
	LoadImage("Custom\\Interface\\btn_large_v2.jpg"             , 600044 , GL_LINEAR, GL_REPEAT) --BUTTON GRANDE
	LoadImage("Custom\\Interface\\option_check.tga"             , 600045 , GL_LINEAR, GL_REPEAT) --CHECK BOX TRADEX
	LoadImage("Custom\\Interface\\interface_scroll_up.jpg"      , 600046 , GL_LINEAR, GL_REPEAT) --BUTTON SCROLL PARTE DE CIMA
	LoadImage("Custom\\Interface\\interface_scroll_m.jpg"       , 600047 , GL_LINEAR, GL_REPEAT) --BUTTON SCROLL PARTE DO MEIO
	LoadImage("Custom\\Interface\\interface_scroll_down.jpg"    , 600048 , GL_LINEAR, GL_REPEAT) --BUTTON SCROLL PARTE DE BAIXO
	LoadImage("Custom\\Interface\\interface_scroll_on.tga"      , 600049 , GL_LINEAR, GL_REPEAT) --BUTTON SCROLL BOLINHA (ÊMBOLO)
	LoadImage("Custom\\Interface\\interface_scroll_on_hover.tga", 600050 , GL_LINEAR, GL_REPEAT) --BUTTON SCROLL BOLINHA (ÊMBOLO) HOVER
	LoadImage("Custom\\Interface\\btn_hiden_tradex.jpg"         , 600051 , GL_LINEAR, GL_REPEAT) --BUTTON HIDDEN TRADEX
	LoadImage("Custom\\Interface\\trading_bar_v2.tga"           , 600052 , GL_LINEAR, GL_REPEAT) --INTERFACE BARRA SEPARA��O
	LoadImage("Custom\\Interface\\Item_Back01_DownFix.jpg"      , 600053 , GL_LINEAR, GL_REPEAT) --INTERFACE BLACK DOWN FIX BUTTONS
	LoadImage("Custom\\Interface\\btn_chat.jpg"                 , 600054 , GL_LINEAR, GL_REPEAT) --BUTTON ORELHINHA CHAT
	LoadImage("Custom\\Interface\\btn_lampada.jpg"              , 600055 , GL_LINEAR, GL_REPEAT) --BUTTON AJUSTE DE TRANSPARENCIA CHAT
	LoadImage("Custom\\Interface\\Item_title.tga"               , 600056 , GL_LINEAR, GL_REPEAT) --BUTTON ITEM TITLE
	LoadImage("Custom\\Interface\\btn_upper.jpg"                , 600057 , GL_LINEAR, GL_REPEAT) --BUTTON PRA CIMA
	LoadImage("Custom\\Interface\\btn_backer.jpg"               , 600058 , GL_LINEAR, GL_REPEAT) --BUTTON PRA BAIXO
	LoadImage("Custom\\Interface\\Menu_AP.jpg"                  , 600059 , GL_LINEAR, GL_REPEAT) --MENU AUTO POTION
	LoadImage("Custom\\Interface\\Menu_v2.jpg"                  , 600060 , GL_LINEAR, GL_REPEAT) --MENU FUNDO
	LoadImage("Custom\\Interface\\btn_plus_menos.jpg"           , 600061 , GL_LINEAR, GL_REPEAT) --BUTTON - PLUS VERMELHO (DIMINUIR PONTOS)
	LoadImage("Custom\\Interface\\btn_red.jpg"                  , 600062 , GL_LINEAR, GL_REPEAT) --BUTTON RED V1
	LoadImage("Custom\\Interface\\btn_red_v2.jpg"               , 600063 , GL_LINEAR, GL_REPEAT) --BUTTON RED V2
	LoadImage("Custom\\Interface\\item_money_v2.tga"            , 600064 , GL_LINEAR, GL_REPEAT) --TEXT BOX ZEN
	LoadImage("Custom\\Interface\\store_name_v2.jpg"            , 600065 , GL_LINEAR, GL_REPEAT) --TEXT BOX LOJINHA
	LoadImage("Custom\\Interface\\bar_switch01.jpg"             , 600066 , GL_LINEAR, GL_REPEAT) --TEXT BOX BAR
	LoadImage("Custom\\Interface\\ViewItem_Back.tga"            , 600067 , GL_LINEAR, GL_REPEAT) --VIEW ITEM PERFIL
	LoadImage("Custom\\Interface\\ViewItem_Back_Visual.tga"     , 600068 , GL_LINEAR, GL_REPEAT) --VIEW ITEM PERFIL VISUAL
	LoadImage("Custom\\Interface\\ViewItem_Back2.tga"           , 600069 , GL_LINEAR, GL_REPEAT) --VIEW ITEM PERFIL MG
	LoadImage("Custom\\Interface\\ViewItem_Back_Visual2.tga"    , 600070 , GL_LINEAR, GL_REPEAT) --VIEW ITEM PERFIL VISUAL MG
	LoadImage("Interface\\cr_gr.tga"                            , 600071 , GL_LINEAR, GL_REPEAT) --(ORIGINAL) SELECT ITEM FADE LEFT
	LoadImage("Interface\\cr_gr2.tga"                           , 600072 , GL_LINEAR, GL_REPEAT) --(ORIGINAL) SELECT ITEM FADE RIGHT
	LoadImage("Custom\\Interface\\btn_balance.jpg"              , 600073 , GL_LINEAR, GL_REPEAT) --BUTTON SALDO
	LoadImage("Custom\\Interface\\btn_menu_v2.jpg"              , 600074 , GL_LINEAR, GL_REPEAT) --BUTTON MENU
	LoadImage("Custom\\Interface\\messagebox_top2_v2.tga"       , 600075 , GL_LINEAR, GL_REPEAT) --INTERACE MESSAGEBOX TOPO COM TITULO
	LoadImage("Custom\\Interface\\messagebox_top_v2.tga"        , 600076 , GL_LINEAR, GL_REPEAT) --INTERACE MESSAGEBOX TOPO SEM TITULO
	LoadImage("Custom\\Interface\\messagebox_mid_v2.tga"        , 600077 , GL_LINEAR, GL_REPEAT) --INTERACE MESSAGEBOX MEIO INFINITO
	LoadImage("Custom\\Interface\\messagebox_bot_v2.tga"        , 600078 , GL_LINEAR, GL_REPEAT) --INTERACE MESSAGEBOX BAIXO
	LoadImage("Custom\\Interface\\btn_purple.jpg"               , 600079 , GL_LINEAR, GL_REPEAT) --BUTTON PURPLE V1
	LoadImage("Custom\\Interface\\btn_purple_v2.jpg"            , 600080 , GL_LINEAR, GL_REPEAT) --BUTTON PURPLE V2
	LoadImage("Custom\\Interface\\Layout.tga"                   , 600081 , GL_LINEAR, GL_REPEAT) --INTERFACE SELECT CHAR
	LoadImage("Custom\\Interface\\black_vision.tga"             , 600082 , GL_LINEAR, GL_REPEAT) --INTERFACE BLACK VISION
	LoadImage("Interface\\item_box.jpg"                         , 600083 , GL_LINEAR, GL_REPEAT) --(ORIGINAL) ITEM BOX INVEN�RIO
	LoadImage("Interface\\InventoryBox2.jpg"                    , 600084 , GL_LINEAR, GL_REPEAT) --(ORIGINAL) ITEM BOX INVEN�RIO SELECIONADO
	LoadImage("Custom\\Interface\\btn_check_on.jpg"             , 600085 , GL_LINEAR, GL_REPEAT) --BUTTON CHECK BOX ON
	LoadImage("Custom\\Interface\\btn_check_off.jpg"            , 600086 , GL_LINEAR, GL_REPEAT) --BUTTON CHECK BOX OFF
	LoadImage("Custom\\Interface\\btn_plus_v2_purple.jpg"       , 600087 , GL_LINEAR, GL_REPEAT) --BUTTON - PLUS ROXO (AUMENTAR PONTOS)
	LoadImage("Custom\\Interface\\btn_plus_menos_purple.jpg"    , 600088 , GL_LINEAR, GL_REPEAT) --BUTTON - PLUS ROXO (DIMINUIR PONTOS)
	LoadImage("Custom\\Interface\\basebar_top.jpg"              , 600089 , GL_LINEAR, GL_REPEAT) --INTERFACE MENU SALDO CIMA
	LoadImage("Custom\\Interface\\basebar_middle.jpg"           , 600090 , GL_LINEAR, GL_REPEAT) --INTERFACE MENU SALDO MEIO
	LoadImage("Custom\\Interface\\basebar_middle_line.tga"      , 600091 , GL_LINEAR, GL_REPEAT) --INTERFACE MENU SALDO MEIO LINHA
	LoadImage("Custom\\Interface\\basebar_bottom.jpg"           , 600092 , GL_LINEAR, GL_REPEAT) --INTERFACE MENU SALDO BAIXO
	LoadImage("Custom\\Interface\\Base_Container.jpg"           , 600093 , GL_LINEAR, GL_REPEAT) --INTERFACE DENTRO DO MENU COM FUNDO
	LoadImage("Custom\\Interface\\Base_Container.tga"           , 600094 , GL_LINEAR, GL_REPEAT) --INTERFACE DENTRO DO MENU SEM FUNDO
	LoadImage("Custom\\Interface\\btn_mais.jpg"                 , 600095 , GL_LINEAR, GL_REPEAT) --BUTTON MAIS NORMAL
	LoadImage("Custom\\Interface\\btn_menos.jpg"                , 600096 , GL_LINEAR, GL_REPEAT) --BUTTON MENOS NORMAL
	LoadImage("Custom\\Interface\\btn_mais_grande.jpg"          , 600097 , GL_LINEAR, GL_REPEAT) --BUTTON MAIS NORMAL GRANDE
	LoadImage("Custom\\Interface\\btn_menos_grande.jpg"         , 600098 , GL_LINEAR, GL_REPEAT) --BUTTON MENOS NORMAL GRANDE
	LoadImage("Custom\\Interface\\Interface_base_select.jpg"    , 600099 , GL_LINEAR, GL_REPEAT) --INTERFACE DELETE CHARACTER FUNDO
	LoadImage("Custom\\Interface\\btn_visible.jpg"              , 600100 , GL_LINEAR, GL_REPEAT) --BUTTON INVISIVEL (PERFIL OLHO)
	LoadImage("Custom\\Interface\\btn_invisible.jpg"            , 600101 , GL_LINEAR, GL_REPEAT) --BUTTON VISIVEL (PERFIL OLHO)
	LoadImage("Custom\\Interface\\btn_reload.jpg"               , 600102 , GL_LINEAR, GL_REPEAT) --BUTTON ATUALIZAR 1 (PERFIL)
	LoadImage("Custom\\Interface\\btn_reload2.jpg"              , 600103 , GL_LINEAR, GL_REPEAT) --BUTTON ATUALIZAR 2 (PERFIL)
	LoadImage("Custom\\Interface\\btn_action_house.jpg"         , 600104 , GL_LINEAR, GL_REPEAT) --BUTTON LEILAO
	LoadImage("Custom\\Interface\\btn_unlocked.jpg"             , 600105 , GL_LINEAR, GL_REPEAT) --BUTTON ABERTO
	LoadImage("Custom\\Interface\\btn_shop.jpg"                 , 600106 , GL_LINEAR, GL_REPEAT) --BUTTON SHOP/COMPRAR
	LoadImage("Custom\\Interface\\btn_ok.jpg"                   , 600107 , GL_LINEAR, GL_REPEAT) --BUTTON OK
	LoadImage("Custom\\Interface\\btn_lang_cancelar.jpg"        , 600108 , GL_LINEAR, GL_REPEAT) --BUTTON POR/SPN CANCELAR
	LoadImage("Custom\\Interface\\btn_lang_cancel.jpg"          , 600109 , GL_LINEAR, GL_REPEAT) --BUTTON ENG CANCEL
	LoadImage("Custom\\Interface\\btn_lang_confirmar.jpg"       , 600110 , GL_LINEAR, GL_REPEAT) --BUTTON POR/SPN CONFIRMAR
	LoadImage("Custom\\Interface\\btn_lang_confirm.jpg"         , 600111 , GL_LINEAR, GL_REPEAT) --BUTTON ENG CONFIRM
	LoadImage("Custom\\Interface\\btn_lang_fechar.jpg"          , 600112 , GL_LINEAR, GL_REPEAT) --BUTTON POR FECHAR
	LoadImage("Custom\\Interface\\btn_lang_close.jpg"           , 600113 , GL_LINEAR, GL_REPEAT) --BUTTON ENG FECHAR
	LoadImage("Custom\\Interface\\btn_lang_cerrar.jpg"          , 600114 , GL_LINEAR, GL_REPEAT) --BUTTON SPN FECHAR
	LoadImage("Custom\\Interface\\btn_server.jpg"               , 600115 , GL_LINEAR, GL_REPEAT) --BUTTON SERVER
	LoadImage("Custom\\Interface\\btn_lang_abrir.jpg"           , 600116 , GL_LINEAR, GL_REPEAT) --BUTTON POR/SPN ABRIR
	LoadImage("Custom\\Interface\\btn_lang_open.jpg"            , 600117 , GL_LINEAR, GL_REPEAT) --BUTTON ENG ABRIR
	LoadImage("Custom\\Interface\\btn_lang_voltar.jpg"          , 600118 , GL_LINEAR, GL_REPEAT) --BUTTON POR VOLTAR
	LoadImage("Custom\\Interface\\btn_lang_back.jpg"            , 600119 , GL_LINEAR, GL_REPEAT) --BUTTON ENG VOLTAR
	LoadImage("Custom\\Interface\\btn_lang_volver.jpg"          , 600120 , GL_LINEAR, GL_REPEAT) --BUTTON SPN VOLTAR
	LoadImage("Custom\\Interface\\btn_scroll_up.jpg"            , 600121 , GL_LINEAR, GL_REPEAT) --SCROLL BAR UP
	LoadImage("Custom\\Interface\\btn_scroll_down.jpg"          , 600122 , GL_LINEAR, GL_REPEAT) --SCROLL BAR DOWN
	LoadImage("Custom\\Interface\\btn_scroll_bar.jpg"           , 600123 , GL_LINEAR, GL_REPEAT) --SCROLL BAR BARRA
	LoadImage("Custom\\Interface\\btnChatOn.jpg"                , 600124 , GL_LINEAR, GL_REPEAT) --BUTTON VISIVEL PERFIL
	LoadImage("Custom\\Interface\\btnChatOff.jpg"               , 600125 , GL_LINEAR, GL_REPEAT) --BUTTON INVISIVEL PERFIL
	LoadImage("Custom\\Interface\\button_ranking.jpg"           , 600126 , GL_LINEAR, GL_REPEAT) --BUTTON RANKING
	LoadImage("Custom\\Interface\\btn_void.jpg"        		    , 600127 , GL_LINEAR, GL_REPEAT) --BUTTON VOID
	LoadImage("Custom\\Interface\\item_select_box.jpg"			, 600128 , GL_LINEAR, GL_REPEAT) --INTERFACE SELECT ITEM
	LoadImage("Custom\\Interface\\btn_wiki.jpg"        		    , 600129 , GL_LINEAR, GL_REPEAT) --BUTTON WIKI
	LoadImage("Custom\\Interface\\trading_bar_v2.jpg"           , 600130 , GL_LINEAR, GL_REPEAT) --INTERFACE BARRA SEPARA��O 2
	LoadImage("Custom\\Interface\\btn_scroll_bar_middle.jpg"    , 600131 , GL_LINEAR, GL_REPEAT) --SCROLL BAR BARRA MEIO
	LoadImage("Custom\\Interface\\lucky_event_free.jpg"    		, 600132 , GL_LINEAR, GL_REPEAT) --LUCK EVENT FREE
	LoadImage("Custom\\Interface\\lucky_event_donate.jpg"    	, 600133 , GL_LINEAR, GL_REPEAT) --LUCK EVENT DONATE
	LoadImage("Custom\\Interface\\button_luckevent.jpg"			, 600134 , GL_LINEAR, GL_REPEAT) --BUTTON LUCKY EVENT
	LoadImage("Custom\\leilao.jpg"								, 600135 , GL_LINEAR, GL_REPEAT) --BUTTON LEIL�O
	LoadImage("Custom\\Interface\\black_vision_2.tga"           , 600136 , GL_NEAREST, GL_REPEAT) --INTERFACE BLACK VISION 2

end