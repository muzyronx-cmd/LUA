Warehouse = {}

function Warehouse.Init()
    InterfaceController.MainProc(Warehouse.Interface)
    InterfaceController.InterfaceClickEvent(Warehouse.ClickEvent)
    InterfaceController.UpdateMouse(Warehouse.UpdateMouse)
	InterfaceController.UpdateKey(Warehouse.UpdateKeyboard)
	InterfaceController.MainProcWorldKey(Warehouse.KeyListener)
	InterfaceController.ClientProtocol(Warehouse.Protocol)
	Warehouse_Config.VaultCount = 0
	Warehouse_Config.CurrentVault = 0
	Warehouse_Config.TextArea = ""
	Warehouse_Config.BuyPrice = {
		[1] = {Name = "", Value = 0, Selected = false},
		[2] = {Name = "", Value = 0, Selected = false},
	}
    Warehouse.Define()
end

function Warehouse.Define()
    Warehouse_Config.MenuOpen = false
    Warehouse_Config.MenuType = false
    Warehouse_Config.AlertWindowOpen = false
    Warehouse_Config.WindowOffset = 0
    Warehouse_Config.Button = {}
    Warehouse_Config.ButtonID = {
        anterior = 1, 
        proximo = 2,
		menu = 3,
		ok = 4,
		cancelar = 5,
		comprar = 6,
    }
	Warehouse_Config.Alfabeto = {
		[48] = "0",[49] = "1",[50] = "2",[51] = "3",[52] = "4",[53] = "5",[54] = "6",[55] = "7",[56] = "8",[57] = "9",[96] = "0",[97] = "1",[98] = "2",[99] = "3",[100] = "4",[101] = "5",[102] = "6",[103] = "7",[104] = "8",[105] = "9"
    }
end

--#region FUN��ES DE BOT�O
function Warehouse.CreateButton(ButtonID, x, y, w, h)
	if Warehouse_Config.Button[ButtonID] == nil then
		table.insert(Warehouse_Config.Button, ButtonID)
		Warehouse_Config.Button[ButtonID] = {
			x = x,
			y = y,
			w = w,
			h = h,
			clicked = false,
			timer = 0
		}
	else
		Warehouse_Config.Button[ButtonID].x = x
		Warehouse_Config.Button[ButtonID].y = y
		Warehouse_Config.Button[ButtonID].w = w
		Warehouse_Config.Button[ButtonID].h = h
	end
end

function Warehouse.ButtonClicked(ButtonID)
	if Warehouse_Config.Button[ButtonID] == nil then return false end
	if Warehouse_Config.Button[ButtonID].clicked then
		if Warehouse_Config.Button[ButtonID].timer >= 2 then
			Warehouse_Config.Button[ButtonID].timer = 0
			Warehouse_Config.Button[ButtonID].clicked = false
			return false
		end
		Warehouse_Config.Button[ButtonID].timer = Warehouse_Config.Button[ButtonID].timer + 1
		return true
	end
	return false
end

function Warehouse.ButtonMouseOver(ButtonID, x, y)
	if Warehouse_Config.Button[ButtonID] == nil then return false end
	if x >= Warehouse_Config.Button[ButtonID].x and x <= (Warehouse_Config.Button[ButtonID].x+Warehouse_Config.Button[ButtonID].w) then
		if y >= Warehouse_Config.Button[ButtonID].y and y <= (Warehouse_Config.Button[ButtonID].y+Warehouse_Config.Button[ButtonID].h) then
			return true
		end
	end
	return false
end
--#endregion

function Warehouse.Interface()
    if CheckWindowOpen(UIWarehouse) == 0 then SetHideVaultButtons(0) return end
    if CheckWindowOpen(UIExpandInventory) == 1 then Warehouse_Config.WindowOffset = 190 else Warehouse_Config.WindowOffset = 0 end
	local windowWidth = WindowGetWidth()
	local addX = WindowGetWidthAdd()
	local offset = windowWidth-640
	Warehouse.CreateButton(Warehouse_Config.ButtonID.anterior, 0, 0, 0, 0)
	Warehouse.CreateButton(Warehouse_Config.ButtonID.proximo, 0, 0, 0, 0)
	Warehouse.CreateButton(Warehouse_Config.ButtonID.menu, 260+offset+110, 393, 25, 24)
	Warehouse.CreateButton(Warehouse_Config.ButtonID.ok, 0, 0, 0, 0)
	Warehouse.CreateButton(Warehouse_Config.ButtonID.cancelar, 0, 0, 0, 0)
	Warehouse.CreateButton(Warehouse_Config.ButtonID.comprar, 260+offset+50, 393, 25, 24)

	EnableAlphaTest()
	
	Warehouse.CreateButton(Warehouse_Config.ButtonID.anterior, 260+offset+30-Warehouse_Config.WindowOffset, 353, 25, 24)
    Warehouse.CreateButton(Warehouse_Config.ButtonID.proximo, 260+offset+133-Warehouse_Config.WindowOffset, 353, 25, 24)

	DisableAlphaBlend()

	if Warehouse_Config.MenuOpen then
		SetHideVaultButtons(1)
		EnableAlphaTest()
		--DrawInterface.InfoBox(false, 260+offset+12, 350, 165, 0, false)

		
        SetFontType(1)
        SetTextBg(0,0,0, 0)
        SetTextColor(237, 214, 161, 255)

		if Warehouse_Config.MenuType == 0 then
			RenderText3(260+offset+((190/2)+1), 352, Warehouse_Config.Message[GetLanguage()][2], 150, 8)


        	DrawInterface.TextBox(0, 260+offset+((190/2)-35), 367, 70, 18)

        	EnableAlphaTest()
        	RenderText3(260+offset+((190/2)+1), 372, "                                ", 70, 8)

        	SetTextColor(255, 255, 255, 255)

        	RenderText3(260+offset+((190/2)+1), 372, Warehouse_Config.TextArea, 90, 8)
        else
			RenderText3(260+offset+((190/2)+1), 367, Warehouse_Config.Message[GetLanguage()][9]:format(Warehouse_Config.BuyPrice[2].Value, Warehouse_Config.BuyPrice[2].Name), 150, 8)

		end
        Warehouse.CreateButton(Warehouse_Config.ButtonID.ok, 260+offset+((190/2)-70), 393, 60, 18)
		local btnState = 0
        if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.ok, MousePosX(), MousePosY()) then
           btnState = 1
        end
		DrawButton.Medium(btnState, 260+offset+((190/2)-70), 393, 60, 18)

        Warehouse.CreateButton(Warehouse_Config.ButtonID.cancelar, 260+offset+((190/2)+10), 393, 60, 18)
		btnState = 0
        if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.cancelar, MousePosX(), MousePosY()) then
            btnState = 1
        end
		DrawButton.Medium(btnState, 260+offset+((190/2)+10), 393, 60, 18)

		SetFontType(1)
        SetTextBg(0,0,0, 0)
        SetTextColor(237, 214, 161, 255)
		RenderText3(260+offset+((190/2)-40), 397, "OK", 60, 8)
		RenderText3(260+offset+((190/2)+42), 397, Warehouse_Config.Message[GetLanguage()][1], 60, 8)

		DisableAlphaBlend()
	else
		SetHideVaultButtons(0)
	end
end

function Warehouse.ClickEvent()
    local x = MousePosX()
    local y = MousePosY()

    if CheckWindowOpen(UIWarehouse) == 1 then
		if Warehouse_Config.MenuOpen then
			if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.cancelar, x, y) then
				Warehouse_Config.MenuOpen = false
			end
			if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.ok, x, y) then
				Warehouse_Config.MenuOpen = false
				if Warehouse_Config.MenuType == 0 then
					Warehouse.SendChangeVault2()
				else
					local PacketName = string.format("6-%s-%d", UserGetName(), UserGetIndex())
    				CreatePacket(PacketName, 3)
    				SendPacket(PacketName)
    				ClearPacket(PacketName)
				end
			end
			return true
		end

		if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.menu, x, y) then
			Warehouse_Config.TextArea = ""
			Warehouse_Config.MenuType = 0
			Warehouse_Config.MenuOpen = true
			return true
		end

		if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.comprar, x, y) then
			Warehouse_Config.MenuType = 1
			Warehouse_Config.MenuOpen = true
			return true
		end

		if Warehouse_Config.CurrentVault > 0 then
        	if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.anterior, x, y) then
        	    Warehouse_Config.Button[Warehouse_Config.ButtonID.anterior].clicked = true
				Warehouse.SendChangeVault(0)
        	    return true
        	end
		end
		if Warehouse_Config.CurrentVault < Warehouse_Config.VaultCount then
        	if Warehouse.ButtonMouseOver(Warehouse_Config.ButtonID.proximo, x, y) then
        	    Warehouse_Config.Button[Warehouse_Config.ButtonID.proximo].clicked = true
				Warehouse.SendChangeVault(1)
        	    return true
        	end
		end
    else
        return true
    end
end

function Warehouse.KeyListener(key)
	if Warehouse_Config.MenuOpen then		
        if CheckWindowOpen(UIChatWindow) ~= 1 then

			if key == Keys.Return then
				Warehouse_Config.MenuOpen = false
				Warehouse.SendChangeVault2()
				return true
			end

			if  Warehouse_Config.Alfabeto[key] ~= nil then
				if Warehouse_Config.TextArea:len() < 5 then
					Warehouse_Config.TextArea = Warehouse_Config.TextArea..Warehouse_Config.Alfabeto[key]
					return true
				end
			end
		end
    end

	--region SETINHAS
	if CheckWindowOpen(UIWarehouse) == 1 then
		if CheckWindowOpen(UIChatWindow) ~= 1 then

			--ABRE A CAIXINHA DE ESCOLHER BAU
			if key == Keys.Down or key == Keys.Up then
				if Warehouse_Config.MenuOpen then
					Warehouse_Config.MenuOpen = false
				else
					Warehouse_Config.MenuOpen = true
				end
			end

			--AVANÇA O BAU
			if key == Keys.Right then
				if Warehouse_Config.CurrentVault < Warehouse_Config.VaultCount then
					Warehouse_Config.Button[Warehouse_Config.ButtonID.proximo].clicked = true
					Warehouse.SendChangeVault(1)
					return true
				end
			end

			--VOLTA O BAU
			if key == Keys.Left then
				if Warehouse_Config.CurrentVault > 0 then
					Warehouse_Config.Button[Warehouse_Config.ButtonID.anterior].clicked = true
					Warehouse.SendChangeVault(0)
					return true
				end
			end
		end
	end
	--#endregion
end

function Warehouse.UpdateKeyboard()
	if CheckPressedKey(Keys.B) ~= 0 then
        if CheckWindowOpen(UIChatWindow) == 1 or CheckWindowOpen(UIStore) == 1 or UICustomInterface ~= 0 or CheckWindowOpen(UIGuildNpc) == 1 or CheckWindowOpen(UINPCGuild) == 1 then
            return
        else
            if CheckWindowOpen(UIWarehouse) == 1 then
                CloseWindow(UIWarehouse)
            else
                local PacketName = string.format("3-%s-%d", UserGetName(), UserGetIndex())
                CreatePacket(PacketName, 3)
                SendPacket(PacketName)
                ClearPacket(PacketName)
            end
        end
    end
	
	if Warehouse_Config.MenuOpen then
		DisableClickClient()
		if CheckWindowOpen(UIChatWindow) ~= 1 then
			if CheckPressedKey(Keys.Escape) ~= 0 then
				Warehouse_Config.MenuOpen = false
				return
			end
			if CheckRepeatKey(8) == 1 then
				if string.len(Warehouse_Config.TextArea) > 0 then
					Warehouse_Config.TextArea = Warehouse_Config.TextArea:sub(1, -2)
					return
				end
			end	
        end
    end
end

function Warehouse.UpdateMouse()
	if Warehouse_Config.MenuOpen then
		DisableClickClient()
	end
end

function Warehouse.SendChangeVault(tipo)
	CloseWindow(UIWarehouse)
	CloseWindow(UIExpandWarehouse)
	local name = UserGetName()
    local index = UserGetIndex()
    local PacketName = string.format("2-%s-%d", name, index)
    CreatePacket(PacketName, Warehouse_Config.Packet)
	SetBytePacket(PacketName, tipo)
	SendPacket(PacketName)
	ClearPacket(PacketName)
end

function Warehouse.SendChangeVault2()
	CloseWindow(UIWarehouse)
	CloseWindow(UIExpandWarehouse)	

	local bau = 0
	if Warehouse_Config.TextArea:len() > 0 then
		bau = tonumber(Warehouse_Config.TextArea)
	end
	local name = UserGetName()
    local index = UserGetIndex()
    local PacketName = string.format("4-%s-%d", name, index)
    CreatePacket(PacketName, Warehouse_Config.Packet)
	SetWordPacket(PacketName, bau)
	SendPacket(PacketName)
	ClearPacket(PacketName)
end

function Warehouse.Protocol(Packet, PacketName)
	if Packet ~= Warehouse_Config.Packet then return end
	
	local name = UserGetName()
    local index = UserGetIndex()
    if PacketName == string.format("1-%s-%d", name, index) then
		local count = GetWordPacket(PacketName, -1)
		local current = GetWordPacket(PacketName, -1)
		ClearPacket(PacketName)
		
		Warehouse_Config.CurrentVault = current
		Warehouse_Config.VaultCount = count
		SetCurrentVault(current)
		SetTotalVaults(count)

		return true
	end

	if PacketName == string.format("3-%s-%d", name, index) then
		local count = GetWordPacket(PacketName, -1)
		local current = GetWordPacket(PacketName, -1)
		ClearPacket(PacketName)
		
		Warehouse_Config.CurrentVault = current
		Warehouse_Config.VaultCount = count

		SetCurrentVault(current)
		SetTotalVaults(count)
		return true
	end
end

Warehouse.Init()

return Warehouse