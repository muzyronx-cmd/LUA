Warehouse_Config = {
    Packet = 1,

    Message = {
        ["Eng"] = {
            [1] = "Cancel",
            [2] = "Insert the desired vault",
            [3] = "Current Ware",
            [4] = "CHANGE WARE",
            [5] = "Buy Extra Warehouse",
            [6] = "Wares",
            [7] = "Payment Method",
            [8] = "BUY WARE",
            [9] = "Buy a ware for %d %s?",
        },

        ["Por"] = {
            [1] = "Cancelar",
            [2] = "Digite o bau desejado",
            [3] = "Baú Atual",
            [4] = "TROCAR BAÚ",
            [5] = "Comprar Baú",
            [6] = "Baús",
            [7] = "Forma de pagamento",
            [8] = "COMPRAR BAÚ",
            [9] = "Comprar um baú por %d %s?",
        },

        ["Spn"] = {
            [1] = "Cancelar",
            [2] = "Digite o bau desejado",
            [3] = "Cofre Actual",
            [4] = "CAMBIAR COFRE",
            [5] = "Comprar Cofre",
            [6] = "Cofres",
            [7] = "Forma de pago",
            [8] = "COMPRAR COFRE",
            [9] = "�Comprar un cofre por %d %s?",
        }

    }

}