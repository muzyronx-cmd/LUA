Warehouse_Config = {
    Enabled = true,
    Packet = 1,

    AllowKeys = {
        "Admin",
    },

    Command = {
        [1]  = "/bau",
        [2]  = "/chest",
        [3]  = "/cofre",
        [4]  = "/warehouse",
        [5]  = "/deposito",
        [6]  = "/armazem",
        [7]  = "/storage",
        [8]  = "/guardar",
        [9]  = "/mochila",
        [10] = "/backpack",
        [11] = "/bag",
        [12] = "/abrirbau",
        [13] = "/openwarehouse",
    },

    BuyPrice = {
        [1] = {Coin = Config.Coin.HCash, Value = {[0] = 1,     [1] = 1,    [2] = 1,    [3] = 1, [4] = 1}},
        [2] = {Coin = Config.Coin.HGold, Value = {[0] = 10000, [1] = 5000, [2] = 1000, [3] = 0, [4] = 500}}
    },

    MaxVault = {
        [0] = 99,   --VIP FREE
        [1] = 399,  --VIP NORMAL
        [2] = 799,  --VIP PREMIUM
        [3] = 1000, --VIP STAFF
        [4] = 1000, --VIP ?
    },

    Message = {
        ["Eng"] = {
            [1] = {Text = "You need %d %s to buy a extra warehouse", Color = 27},
            [2] = {Text = "Extra warehouse purchase was successfull", Color = 28},
            [3] = {Text = "You reached the maximum amount of extra warehouses", Color = 27},
            [4] = "Close other windows to change the chest",
            [5] = "Your smallest chest is number (1)",
            [6] = "Successfully changed chest to %d!",
            [7] = {Text = "Vault added successfully", Color = 28},
        },

        ["Por"] = {
            [1] = {Text = "Você precisa de %d %s para comprar um baú", Color = 27},
            [2] = {Text = "Baú comprado com sucesso", Color = 28},
            [3] = {Text = "Você atingiu o limite de baús para o seu plano vip", Color = 27},
            [4] = "Feche outras janelas para alterar o baú",
            [5] = "Seu menor baú é o de número (1)",
            [6] = "Baú alterado para %d com sucesso!",
            [7] = {Text = "Baú adicionado com sucesso", Color = 28},
        },

        ["Spn"] = {
            [1] = {Text = "Você precisa de %d %s para comprar um baú", Color = 27},
            [2] = {Text = "Baú comprado com sucesso", Color = 28},
            [3] = {Text = "Você atingiu o limite de baús para o seu plano vip", Color = 27},
            [4] = "Feche outras janelas para alterar o baú",
            [5] = "Seu menor baú é o de número (1)",
            [6] = "Baú alterado para %d com sucesso!",
            [7] = {Text = "Baú adicionado com sucesso", Color = 28},
        }
    } 
}