---@diagnostic disable: trailing-space
Warehouse = {}

function Warehouse.Init()
    if Warehouse_Config.Enabled then
        GameServerFunctions.GameServerProtocol(Warehouse.Protocol)
        GameServerFunctions.EnterCharacter(Warehouse.EnterCharacter)
        for i in ipairs(Warehouse_Config.Command) do
            Commands.Register(Warehouse_Config.Command[i], Warehouse.Command)
        end
    end
end

function Warehouse.EnterCharacter(aIndex)
    local player = User.new(aIndex)
    local playerInfo = Utils.GetPlayerInfo(player)

    local count = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])
    local number = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Last, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    if number < 0 then number = 0 end

    if number > count then 
        number = count
    end

    DataBaseAsync.SetValue(Config.Warehouse.Table, Config.Warehouse.Column.Last, number, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    player:setWarehouseNumber(number)

    local keys = 0

    for i in ipairs(Warehouse_Config.AllowKeys) do
        if Warehouse_Config.AllowKeys[i] == playerInfo[1] then
            keys = 1
        end
    end

    local PacketName = string.format("1-%s-%d", playerInfo[1], playerInfo[2])
    CreatePacket(PacketName, Warehouse_Config.Packet)
    SetWordPacket(PacketName, count)
    SetWordPacket(PacketName, number)
    SetWordPacket(PacketName, keys)
    SendPacket(PacketName, playerInfo[2])
    ClearPacket(PacketName)

    local price = Warehouse_Config.BuyPrice[2].Value[playerInfo[4]]
    local newpacket = "wareHousePrice"
    CreatePacket(newpacket, 31)
    SetDwordPacket(newpacket, price)
    SendPacket(newpacket, aIndex)
    ClearPacket(newpacket)
end

function Warehouse.Command(aIndex, Arguments)
    local player = User.new(aIndex)
    local playerInfo = Utils.GetPlayerInfo(player)
    local target = player:getWarehouseNumber()

    local count = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])
    local number = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Last, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    if number < 0 then number = 0 end

    if number > count then 
        number = count
    end

    DataBaseAsync.SetValue(Config.Warehouse.Table, Config.Warehouse.Column.Last, number, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    local bau = Cmd:getNumber(Arguments, 1)

    local vaultnum = nil

    if bau == nil then
        vaultnum = number
    else
        local permition = false

        if CharacterPermition.Enabled then
            for i in ipairs (CharacterPermition.Permition_Players) do
                if player:getName() == CharacterPermition.Permition_Players[i] then
                    permition = true
                end
            end
        end
    
        if not StaffManager.IsPlayerAuthorized(player:getName(), CommandFireWorks_Config.UseLevel) and not permition then
            if bau < 0 then bau = 0 end
            if bau > count then 
                bau = count
            end
        end

        vaultnum = bau
    end
    player:setWarehouseNumber(vaultnum)
    local ret = TrocarBauPlayer(playerInfo[2], vaultnum)

    local PacketName = string.format("3-%s-%d", playerInfo[1], playerInfo[2])
    CreatePacket(PacketName, Warehouse_Config.Packet)
    SetWordPacket(PacketName, count)
    SetWordPacket(PacketName, vaultnum)
    SendPacket(PacketName, playerInfo[2])
    ClearPacket(PacketName)
	    
    if ret == 0 then
        player:setTargetShopNumber(100)
        player:setReqWarehouseOpen(1)
        player:setWarehouseCount(0)
        player:setInterfaceUse(1)
        player:setInterfaceType(6)
        player:setInterfaceState(0)
        GetWarehouseList(playerInfo[2], playerInfo[0])
    end
end

function Warehouse.Protocol(aIndex, Packet, PacketName)
    if Packet ~= Warehouse_Config.Packet then return false end

    local player = User.new(aIndex)
    local playerInfo = Utils.GetPlayerInfo(player)

    if PacketName == string.format("2-%s-%d", playerInfo[1], playerInfo[2]) then
        local tipo = GetBytePacket(PacketName, -1)
        ClearPacket(PacketName)
        Warehouse.MudarBau(player, playerInfo, tipo)
        return true
    end

    if PacketName == string.format("4-%s-%d", playerInfo[1], playerInfo[2]) then
        local tipo = GetWordPacket(PacketName, -1)
        ClearPacket(PacketName)
        Warehouse.MudarBau2(player, playerInfo, tipo)
        return true
    end
end

function Warehouse.MudarBau(player, playerInfo, tipo)
    local target = player:getWarehouseNumber()

    if tipo == 0 then
        target = target - 1
    else
        target = target + 1
    end

    local count = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    if target < 0 then
        target = 0
    end

    if target > count then
        target = count
    end

	local ret = TrocarBauPlayer(playerInfo[2], target)
    
    target = player:getWarehouseNumber()
    DataBaseAsync.SetValue(Config.Warehouse.Table, Config.Warehouse.Column.Last, target, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    local PacketName = string.format("3-%s-%d", playerInfo[1], playerInfo[2])
    CreatePacket(PacketName, Warehouse_Config.Packet)
    SetWordPacket(PacketName, count)
    SetWordPacket(PacketName, target)
    SendPacket(PacketName, playerInfo[2])
    ClearPacket(PacketName)
	    
    if ret == 0 then
        player:setTargetShopNumber(100)
        player:setReqWarehouseOpen(1)
        player:setWarehouseCount(0)
        player:setInterfaceUse(1)
        player:setInterfaceType(6)
        player:setInterfaceState(0)
        GetWarehouseList(playerInfo[2], playerInfo[0])
    end
end

function Warehouse.MudarBau2(player, playerInfo, target)
    local current = player:getWarehouseNumber()

   if target < 0 then
       target = 0
   end

    local count = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    if target > count then
        target = count
    end

	local ret = TrocarBauPlayer(playerInfo[2], target)
    
    target = player:getWarehouseNumber()
    DataBaseAsync.SetValue(Config.Warehouse.Table, Config.Warehouse.Column.Last, target, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    local PacketName = string.format("3-%s-%d", playerInfo[1], playerInfo[2])
    CreatePacket(PacketName, Warehouse_Config.Packet)
    SetWordPacket(PacketName, count)
    SetWordPacket(PacketName, target)
    SendPacket(PacketName, playerInfo[2])
    ClearPacket(PacketName)
	
    if ret == 0 then
        player:setTargetShopNumber(100)
        player:setReqWarehouseOpen(1)
        player:setWarehouseCount(0)
        player:setInterfaceUse(1)
        player:setInterfaceType(6)
        player:setInterfaceState(0)
        GetWarehouseList(playerInfo[2], playerInfo[0])
    end
end

function Warehouse.BuyWare(aIndex)
    local player = User.new(aIndex)
    local playerInfo = Utils.GetPlayerInfo(player)

    local saldo = DataBase.GetValue(Warehouse_Config.BuyPrice[2].Coin.Table, Warehouse_Config.BuyPrice[2].Coin.Column, Warehouse_Config.BuyPrice[2].Coin.Where, playerInfo[Warehouse_Config.BuyPrice[2].Coin.IdType])
    local count = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    if saldo < Warehouse_Config.BuyPrice[2].Value[playerInfo[4]] then
        SendMessage(string.format(Warehouse_Config.Message[playerInfo[3]][1].Text, Warehouse_Config.BuyPrice[2].Value[playerInfo[4]], Warehouse_Config.BuyPrice[2].Coin.Name[0]), playerInfo[2], Warehouse_Config.Message[playerInfo[3]][1].Color)  
        return
    end
    if count >= Warehouse_Config.MaxVault[playerInfo[4]] then
        SendMessage(Warehouse_Config.Message[playerInfo[3]][3].Text, playerInfo[2], Warehouse_Config.Message[playerInfo[3]][3].Color)
        return
    end
    
    DataBaseAsync.SetDecreaseValue(Warehouse_Config.BuyPrice[2].Coin.Table, Warehouse_Config.BuyPrice[2].Coin.Column, Warehouse_Config.BuyPrice[2].Value[playerInfo[4]], Warehouse_Config.BuyPrice[2].Coin.Where, playerInfo[Warehouse_Config.BuyPrice[2].Coin.IdType])
    DataBase.SetAddValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, 1, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])
    SendMessage(Warehouse_Config.Message[playerInfo[3]][2].Text, playerInfo[2], Warehouse_Config.Message[playerInfo[3]][2].Color)    
end

function Warehouse.AddWare(aIndex)
    local player = User.new(aIndex)
    local playerInfo = Utils.GetPlayerInfo(player)

    local count = DataBase.GetValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])

    if count >= Warehouse_Config.MaxVault[playerInfo[4]] then
        SendMessage(Warehouse_Config.Message[playerInfo[3]][3].Text, playerInfo[2], Warehouse_Config.Message[playerInfo[3]][3].Color)
        return 0
    end
    
    DataBaseAsync.SetDecreaseValue(Warehouse_Config.BuyPrice[2].Coin.Table, Warehouse_Config.BuyPrice[2].Coin.Column, Warehouse_Config.BuyPrice[2].Value[playerInfo[4]], Warehouse_Config.BuyPrice[2].Coin.Where, playerInfo[Warehouse_Config.BuyPrice[2].Coin.IdType])
    DataBase.SetAddValue(Config.Warehouse.Table, Config.Warehouse.Column.Count, 1, Config.Warehouse.Where, playerInfo[Config.Warehouse.IdType])
    SendMessage(Warehouse_Config.Message[playerInfo[3]][7].Text, playerInfo[2], Warehouse_Config.Message[playerInfo[3]][7].Color)   
    return 1 
end

Warehouse.Init()

return Warehouse