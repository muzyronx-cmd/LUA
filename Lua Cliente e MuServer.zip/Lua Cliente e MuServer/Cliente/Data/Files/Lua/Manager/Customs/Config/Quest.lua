Quest_Config = {
    Enabled = true,

    Packet = 23,

    WindowID = 23,

    Texts = {
        ["Por"] = {
            [1] = "Quest",
            [2] = "Requisitos",
            [3] = "Recompensas",
            [4] = "Resgatar",
            [5] = "Maravilha!",
            [6] = "Suas recompensas est�o te aguardando",
            [7] = "no Guardi�o dos Pr�mios em Loreencia/Devias",
            [8] = "Fechar",
            [9] = "Erro!",
            [10] = "N�o foi poss�vel resgatar seus pr�mios",
            [11] = "Tente novamente em alguns instantes",
        },

        ["Eng"] = {
            [1] = "Quest",
            [2] = "Requisitos",
            [3] = "Recompensas",
            [4] = "Resgatar",
            [5] = "Maravilha!",
            [6] = "Suas recompensas est�o te aguardando",
            [7] = "no Guardi�o dos Pr�mios em Loreencia/Devias",
            [8] = "Fechar",
            [9] = "Erro!",
            [10] = "N�o foi poss�vel resgatar seus pr�mios",
            [11] = "Tente novamente em alguns instantes",
        },

        ["Spn"] = {
            [1] = "Quest",
            [2] = "Requisitos",
            [3] = "Recompensas",
            [4] = "Resgatar",
            [5] = "Maravilha!",
            [6] = "Suas recompensas est�o te aguardando",
            [7] = "no Guardi�o dos Pr�mios em Loreencia/Devias",
            [8] = "Fechar",
            [9] = "Erro!",
            [10] = "N�o foi poss�vel resgatar seus pr�mios",
            [11] = "Tente novamente em alguns instantes",
        },
    }
}

return Quest_Config