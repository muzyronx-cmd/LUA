INVASION_NOTIFICATIONS_CONFIG = {
    Enabled = true,
    Packet = 217, -- Igual ao servidor.
    PollSeconds = 5,
    StaleSeconds = 15,
    ToastSeconds = 6,
    -- O cliente usa coordenadas logicas 640x480, como as outras interfaces.
    CanvasWidth = 640,
    Button = {Width = 116, Height = 19, Y = 2, OffsetX = 0},
    Panel = {Width = 240, Height = 244, Y = 30, Rows = 9},
    -- Textura do acabamento escuro da janela enviada no print.
    Window = {UseClientTextures = true, BackgroundImage = 620110,
        BackgroundFile = "Custom\\Interface\\invasion_inventory.jpg"},
    Colors = {
        Background = {0.08, 0.08, 0.075, 1},
        Hover = {0.20, 0.19, 0.15, 0.7},
        Border = {0.36, 0.31, 0.20, 1},
        BorderLight = {0.49, 0.43, 0.29, 1},
        BorderShadow = {0.12, 0.105, 0.075, 1},
        Title = {184, 203, 225},
        Panel = {0.08, 0.08, 0.075, 1},
    },
}
