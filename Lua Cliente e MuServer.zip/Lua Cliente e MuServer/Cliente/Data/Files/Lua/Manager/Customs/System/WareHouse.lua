-- Lua 5.1. Interface do bau multiplo: setas, "Bau N / TOTAL" e botoes de Zen/Trava.
-- Este arquivo e carregado pelo cliente (ReaderIMG.lua chama Warehouse.*), por isso
-- TODO o desenho fica aqui. Nao le nem escreve memoria nativa.
-- As transacoes de Zen continuam nos botoes originais do cliente.
Warehouse = Warehouse or {}
local UI = Warehouse
local packetNumber = 0x66
local maximum, selected, ready = 0, 0, false
local wasOpen, popup, input = false, false, ""
local lastRequest, pending = nil, false
local lastError, openInfo, registered = nil, "?", false

-- ---------------------------------------------------------------------------
-- CONFIGURACAO  (coordenadas virtuais 640x480, esticadas na tela)
--  btnX/btnY : canto dos botoes Dep./Ret./Trava (sobre os botoes nativos).
--              Posicao ja confirmada no servidor. TUDO e posicionado a partir daqui.
--  navDX/navDY : posicao de [<] Bau N / TOTAL [>] em relacao aos botoes
--              (fica na linha do saldo de Zen, a esquerda do valor).
-- Ajuste AO VIVO com o bau aberto (precisa status = true para ver os valores):
--    SHIFT + setas  -> move tudo
--    CTRL  + setas  -> move so as setas / contador
-- Os valores aparecem na linha de diagnostico; copie-os para ca e volte status = false.
-- ---------------------------------------------------------------------------
local CONFIG = {
    btnX = 287, btnY = 388,
    navDX = -12, navDY = -39,
    arrowW = 18, counterW = 62, navH = 14,
    label = "Bau",      -- para acento use "Ba\250" (se aparecer estranho, volte para "Bau")
    status = true,      -- diagnostico + lista de funcoes de imagem do cliente (false = desligado)
}
local allNX, allNY, navNX, navNY, tick = 0, 0, 0, 0, 0

local function integer(n)
    return type(n) == "number" and n == n and n >= 0
        and n <= 2147483647 and n == math.floor(n)
end

local function btnOrigin()
    return CONFIG.btnX + allNX, CONFIG.btnY + allNY
end

-- Retangulos da linha de navegacao: seta esquerda, contador, seta direita.
local function navRects()
    local bx, by = btnOrigin()
    local x, y = bx + CONFIG.navDX + navNX, by + CONFIG.navDY + navNY
    local aw, cw, h = CONFIG.arrowW, CONFIG.counterW, CONFIG.navH
    return {x = x, y = y, w = aw, h = h},
           {x = x + aw + 2, y = y, w = cw, h = h},
           {x = x + aw + cw + 4, y = y, w = aw, h = h}
end

local function hover(x, y, w, h)
    local mx, my = MousePosX(), MousePosY()
    return mx >= x and mx < x + w and my >= y and my < y + h
end

local function hoverRect(r) return hover(r.x, r.y, r.w, r.h) end

local function box(x, y, w, h, border)
    SetBlend()
    glColor4f(0.47, 0.40, 0.26, 1)
    DrawBar(x, y, w, h)
    EndDrawBar()
    SetBlend()
    if border then glColor4f(0.17, 0.15, 0.10, 1)
    else glColor4f(0.04, 0.04, 0.035, 1) end
    DrawBar(x + 1, y + 1, w - 2, h - 2)
    EndDrawBar()
end

local function bar(x, y, w, h)
    SetBlend()
    DrawBar(x, y, w, h)
    EndDrawBar()
end

local function text(x, y, value, width, enabled)
    SetFontType(0)
    SetTextBg(0, 0, 0, 0)
    if enabled == false then SetTextColor(110, 105, 90, 255)
    else SetTextColor(237, 206, 133, 255) end
    RenderText2(x, y, value, width, 3)
end

local function button(x, y, w, h, label, enabled)
    box(x, y, w, h, enabled ~= false and hover(x, y, w, h))
    text(x, y + math.floor((h - 10) / 2), label, w, enabled)
end

-- Seta dourada no estilo das setas do Inventario (haste + ponta triangular).
local function arrow(r, dir, enabled)
    box(r.x, r.y, r.w, r.h, enabled and hoverRect(r))
    if enabled then
        if hoverRect(r) then glColor4f(1, 0.95, 0.70, 1) else glColor4f(0.93, 0.81, 0.52, 1) end
    else
        glColor4f(0.35, 0.33, 0.28, 1)
    end
    local cy = r.y + math.floor(r.h / 2)
    local x = r.x + math.floor((r.w - 12) / 2)       -- seta tem 12 de largura
    if dir < 0 then
        bar(x + 4, cy - 1, 8, 2)                      -- haste
        bar(x,     cy - 1, 1, 2)                      -- ponta (colunas crescentes)
        bar(x + 1, cy - 2, 1, 4)
        bar(x + 2, cy - 3, 1, 6)
        bar(x + 3, cy - 4, 1, 8)
    else
        bar(x, cy - 1, 8, 2)
        bar(x + 8,  cy - 4, 1, 8)
        bar(x + 9,  cy - 3, 1, 6)
        bar(x + 10, cy - 2, 1, 4)
        bar(x + 11, cy - 1, 1, 2)
    end
end

function UI.Close()
    popup, input = false, ""
end

-- Janela do bau aberta? (protegido: se UIWarehouse nao existir, o diagnostico avisa)
local function visible()
    if UIWarehouse == nil then openInfo = "UIWarehouse=nil"; return false end
    local ok, r = pcall(CheckWindowOpen, UIWarehouse)
    if not ok then openInfo = "erro CheckWindowOpen"; return false end
    if r ~= 1 then
        openInfo = "fechada"
        wasOpen = false
        UI.Close()
        return false
    end
    openInfo = "aberta"
    return true
end

local function requestInfo()
    local now = os.time()
    if lastRequest and now >= lastRequest and now - lastRequest < 3 then return end
    lastRequest = now
    local name = string.format("WHouse_Info_%s", UserGetName())
    CreatePacket(name, packetNumber)
    SendPacket(name)
    ClearPacket(name)
end

-- Lista as funcoes do cliente ligadas a imagem/desenho (so para diagnostico).
local apiNames
local function scanApi()
    local ok, res = pcall(function()
        local t = {}
        for k, v in pairs(_G) do
            if type(v) == "function" and type(k) == "string" then
                local l = k:lower()
                if l:find("image") or l:find("bitmap") or l:find("textur")
                    or l:find("sprite") or l:find("render") or l:find("draw") then
                    t[#t + 1] = k
                end
            end
        end
        table.sort(t)
        return table.concat(t, " ")
    end)
    apiNames = ok and res or "erro ao listar"
end

local function drawStatus()
    local bx, by = btnOrigin()
    local o = string.format("[Bau] script OK | janela: %s | servidor: %s | %s | btn %d,%d nav %d,%d | ctrl: %s",
        openInfo, ready and (selected + 1) .. "/" .. (maximum + 1) or "sem resposta",
        lastError and ("ERRO: " .. lastError) or "sem erro",
        bx, by, CONFIG.navDX + navNX, CONFIG.navDY + navNY,
        registered and "sim" or "NAO")
    box(2, 118, 420, 14, false)
    text(5, 120, o, 416)
    -- Funcoes de imagem/desenho disponiveis (em linhas de ~140 caracteres)
    if not apiNames then scanApi() end
    local y, s = 134, "API: " .. apiNames
    for i = 1, 6 do
        if #s == 0 then break end
        box(2, y, 420, 12, false)
        text(5, y + 1, s:sub(1, 140), 416)
        s = s:sub(141)
        y = y + 12
    end
end

local function drawWindow()
    if not wasOpen then
        wasOpen, pending, ready = true, false, false
        lastRequest = nil
    end
    if not ready or pending then requestInfo() end
    local bx, by = btnOrigin()
    local left, mid, right = navRects()

    -- Linha na altura do saldo de Zen:  [<]  Bau: N / TOTAL  [>]
    arrow(left, -1, ready and selected > 0 and not pending)
    button(mid.x, mid.y, mid.w, mid.h,
        ready and string.format("%s: %d | Total: %d", CONFIG.label, selected + 1, maximum + 1) or "Aguardando...", ready)
    arrow(right, 1, ready and selected < maximum and not pending)

    -- Botoes de Zen/Trava: NAO sao desenhados (como no original). So o clique nativo do cliente.

    if popup then
        local px, py = bx + 10, by - 270
        box(px, py, 140, 77, false)
        text(px, py + 5, "Escolha o bau (1 a " .. (maximum + 1) .. ")", 140)
        box(px + 10, py + 20, 120, 18, true)
        text(px + 10, py + 24, input .. "|", 120)
        button(px + 10, py + 47, 57, 20, "Alterar", true)
        button(px + 73, py + 47, 57, 20, "Fechar", true)
    end
end

function UI.SendPacket(number)
    if not ready or pending or not integer(number) or number > maximum
        or number == selected or not visible() then return false end
    UI.Close()
    pending = true
    CloseWindow(UIWarehouse)   -- o servidor exige o bau fechado antes de trocar
    local name = string.format("WHouse_Change_%s", UserGetName())
    CreatePacket(name, packetNumber)
    SetDwordPacket(name, number)
    SendPacket(name)
    ClearPacket(name)
    return true
end

function UI.InterfaceClickEvent()
    if not visible() then return end
    local left, mid, right = navRects()
    local bx, by = btnOrigin()
    if popup then
        local px, py = bx + 10, by - 270
        if hover(px + 10, py + 47, 57, 20) then
            local number = tonumber(input)
            if number == selected + 1 then UI.Close()
            elseif number then UI.SendPacket(number - 1) end
        elseif hover(px + 73, py + 47, 57, 20) then UI.Close() end
        return true
    end
    if not ready or pending then return end
    if hoverRect(left) then return UI.SendPacket(selected - 1) end
    if hoverRect(right) then return UI.SendPacket(selected + 1) end
    if hoverRect(mid) then
        popup, input = true, tostring(selected + 1)
        return true
    end
end

function UI.UpdateMouse()
    if not visible() then return end
    local left, mid, right = navRects()
    if popup or hoverRect(left) or hoverRect(mid) or hoverRect(right) then DisableClickClient() end
end

function UI.KeyListener(key)
    if not visible() or not popup then return end
    if key == 27 then UI.Close(); return true end
    if key == 13 then
        local number = tonumber(input)
        if number == selected + 1 then UI.Close()
        elseif number then UI.SendPacket(number - 1) end
        return true
    end
    local digit
    if key >= 48 and key <= 57 then digit = key - 48
    elseif key >= 96 and key <= 105 then digit = key - 96 end
    if digit and #input < 10 then input = input .. digit; return true end
end

local function keyStep()
    if not visible() then return end
    if popup then
        DisableClickClient()
        if CheckRepeatKey(8) == 1 then input = input:sub(1, -2) end
        return
    end
    -- Calibracao: SHIFT+setas move tudo; CTRL+setas move so a linha das setas.
    local shift, ctrl = CheckRepeatKey(16) == 1, CheckRepeatKey(17) == 1
    if not (shift or ctrl) then return end
    tick = tick + 1
    if tick % 3 ~= 0 then return end
    local dx, dy = 0, 0
    if CheckRepeatKey(37) == 1 then dx = -1 end
    if CheckRepeatKey(39) == 1 then dx = 1 end
    if CheckRepeatKey(38) == 1 then dy = -1 end
    if CheckRepeatKey(40) == 1 then dy = 1 end
    if shift then allNX, allNY = allNX + dx, allNY + dy
    else navNX, navNY = navNX + dx, navNY + dy end
end

function UI.ClientProtocol(packet, name)
    if packet ~= packetNumber or name ~= string.format("WHouse_%s", UserGetName()) then
        return false
    end
    local limit, current = GetDwordPacket(name, -1), GetDwordPacket(name, -1)
    if integer(limit) and integer(current) then
        maximum, selected, ready, pending = limit, current, true, false
    end
    ClearPacket(name)
    return true
end

-- Desenho. Chamado pelo ReaderIMG (Warehouse.MakeIcons/MakeInterface) e/ou pelo
-- InterfaceController. Desenhar duas vezes no mesmo quadro e inofensivo.
local function draw()
    local ok, err = pcall(function()
        UI.Register()
        EnableAlphaTest()
        if visible() then drawWindow() end
        if CONFIG.status then drawStatus() end
        GLSwitch()
        glColor4f(1, 1, 1, 1)
        DisableAlphaBlend()
    end)
    if ok then lastError = nil else lastError = tostring(err):sub(1, 70) end
end

-- Registra cliques, mouse, teclas e o pacote do servidor (uma unica vez).
function UI.Register()
    if registered or type(InterfaceController) ~= "table" then return end
    registered = true
    InterfaceController.ClientProtocol(UI.ClientProtocol)
    InterfaceController.InterfaceClickEvent(UI.InterfaceClickEvent)
    InterfaceController.UpdateMouse(UI.UpdateMouse)
    InterfaceController.MainProcWorldKey(UI.KeyListener)
    InterfaceController.UpdateKey(keyStep)
end

UI.MakeInterface = draw
UI.MakeIcons = draw
function UI.Init() UI.Register() end
function UI.LoadImages() end
-- Se o cliente chamar Warehouse.UpdateKey diretamente e o controller nao existir:
function UI.UpdateKey() if not registered then keyStep() end end

UI.Register()
return UI
