-- VERSAO v8 (visual da roleta; navegacao e saldos na lateral)
--[[
    Shop.lua (CLIENTE) - janela da loja in-game.

    Fluxo:
      ShopButton -> Shop.Open() -> envia SHOPI_OPEN
      servidor   -> SHOPI_DATA (moedas+saldos + catalogo) -> janela abre
      jogador    -> Comprar -> confirmacao -> envia SHOPI_BUY (so o ID do produto)
      servidor   -> SHOPI_RESULT (codigo + saldos) -> entrega no inventario

    O cliente NUNCA decide preco/moeda/itens: so exibe o que o servidor enviou
    e pede a compra por ID. Configuracao visual: ShopConfig.lua (mesma pasta).

    Obs: este arquivo nao le SHOP_CONFIG no carregamento (so em tempo de
    execucao), pois Shop.lua pode ser carregado antes de ShopConfig.lua.
]]

Shop = {}

local SHOP_PACKET_OPEN   = "SHOPI_OPEN"
local SHOP_PACKET_BUY    = "SHOPI_BUY"
local SHOP_PACKET_DATA   = "SHOPI_DATA"
local SHOP_PACKET_RESULT = "SHOPI_RESULT"

local OPEN_TIMEOUT_FRAMES = 600   -- espera pelo catalogo apos pedir a abertura
local BUY_TIMEOUT_FRAMES  = 900   -- espera pelo resultado apos pedir a compra
local MESSAGE_FRAMES      = 500   -- tempo da mensagem na janela

local Visible    = 0
local Pending    = 0      -- frames restantes aguardando SHOPI_DATA
local Waiting    = 0      -- frames restantes aguardando SHOPI_RESULT
local Products   = {}     -- lista na ordem recebida
local View       = {}     -- produtos da aba atual
local Coins      = {}     -- lista { Id, Name, Balance } enviada pelo servidor
local CoinById   = {}     -- Id -> entrada de Coins
local MainIdx    = 1      -- aba principal aberta (indice em Categories)
local SubIdx     = 1      -- subaba aberta (indice em Categories[MainIdx].Sub)
local Category   = 0      -- Id de categoria usado no filtro (calculado em Rebuild)
local IconQueue  = {}     -- icones 3D desenhados por ultimo (por cima das linhas)
local Page       = 0
local Confirm    = nil    -- produto aguardando confirmacao
local MsgText    = nil
local MsgFrames  = 0
local MsgError   = false
local Calib      = {}     -- ajustes feitos no modo Calibrate (ItemIndex -> {X,Y,W,H,S})

local COLOR_GOLD_R, COLOR_GOLD_G, COLOR_GOLD_B = 0.73, 0.56, 0.26
local IMAGE = 620121
local NavOffset, SubOffset, CoinPage = 0, 0, 0
local HasPending = false

------------------------------------------------------------------------------
-- Utilitarios
------------------------------------------------------------------------------

local function Texts()
    return SHOP_CONFIG.Texts[GetLanguage()] or SHOP_CONFIG.Texts["Eng"]
end

local function Inside(x, y, w, h)
    local mx = MousePosX()
    local my = MousePosY()
    return mx >= x and mx <= x + w and my >= y and my <= y + h
end

local function Geo()
    local win = SHOP_CONFIG.Window
    local g = { x = win.X, y = win.Y, w = win.W, h = win.H }
    g.headerH = 28
    g.close = { x = g.x + g.w - 30, y = g.y + 7, w = 22, h = 20 }
    g.sideX, g.sideW = g.x + 12, 142
    g.tabsY, g.tabH, g.navRows = g.y + 60, 18, 5
    g.catPrev = {x=g.sideX+98, y=g.y+38, w=18, h=16}
    g.catNext = {x=g.sideX+120, y=g.y+38, w=18, h=16}
    g.balY, g.balH = g.y + 175, 126
    g.listX, g.listY = g.x + 166, g.y + 58
    g.listW = g.w - 178
    g.collect = {x=g.listX+g.listW-80,y=g.y+36,w=80,h=18}
    g.selector = {x=g.listX,y=g.y+36,w=g.listW-(HasPending and 88 or 0),h=20}
    g.subY, g.subH, g.subSlots = g.selector.y, 20, 5
    local c=SHOP_CONFIG.Categories[MainIdx]
    local count=c and c.Sub and #c.Sub or 0
    local overflow=count>g.subSlots and 48 or 0
    g.subX=g.listX+4+overflow/2
    g.subW=math.floor((g.selector.w-8-overflow)/math.max(1,math.min(count,g.subSlots)))
    g.dropH=20
    g.subPrev={x=g.listX+2,y=g.subY,w=20,h=20}
    g.subNext={x=g.listX+g.selector.w-22,y=g.subY,w=20,h=20}
    -- Keep rows inside the content area even with a customized configuration.
    g.rowH = math.max(58, SHOP_CONFIG.RowH)
    g.rows = math.max(1, math.min(SHOP_CONFIG.RowsPerPage, math.floor((g.h-112)/g.rowH)))
    g.buyW, g.buyH = 72, 22
    g.footY = g.listY + g.rows * g.rowH + 2
    g.navY, g.msgY = g.footY + 4, g.y + g.h - 29
    g.prev = { x = g.listX, y = g.navY, w = 24, h = 20 }
    g.next = { x = g.listX+g.listW-24, y = g.navY, w = 24, h = 20 }
    g.cw, g.ch = math.min(g.w-24, 350), 132
    g.cx = g.x + math.floor((g.w-g.cw)/2)
    g.cy = g.y + math.floor((g.h-g.ch)/2)
    g.ok = { x = g.cx + 30, y = g.cy + g.ch-34, w = 110, h = 24 }
    g.cancel = { x = g.cx+g.cw-140, y = g.cy+g.ch-34, w = 110, h = 24 }
    return g
end

local function BuyButtonRect(g, row)
    local y = g.listY + row * g.rowH
    return g.listX + g.listW - g.buyW - 8, y + g.rowH - g.buyH - 8, g.buyW, g.buyH


end

local function CatName(c)
    return c.Name[GetLanguage()] or c.Name["Eng"] or c.Name["Por"] or "?"
end

-- Abas principais. Cada uma pode ter Sub = { {Id, Name}, ... } (subcategorias).
local function Tabs()
    local list = {}
    for i = 1, #SHOP_CONFIG.Categories do
        local c = SHOP_CONFIG.Categories[i]
        table.insert(list, { Id = c.Id, Name = CatName(c), Sub = c.Sub })
    end
    return list
end

local function SubTabs()
    local c = SHOP_CONFIG.Categories[MainIdx]
    local list = {}
    if c ~= nil and c.Sub ~= nil then
        for i = 1, #c.Sub do
            table.insert(list, { Id = c.Sub[i].Id, Name = CatName(c.Sub[i]) })
        end
    end
    return list
end

-- true se alguma categoria tem subcategorias (reserva a linha extra da janela)
function Shop.HasSubTabs()
    if SHOP_CONFIG == nil or SHOP_CONFIG.Categories == nil then return false end
    for i = 1, #SHOP_CONFIG.Categories do
        local c = SHOP_CONFIG.Categories[i]
        if c.Sub ~= nil and #c.Sub > 0 then return true end
    end
    return false
end

-- Separate lists: changing a main category only replaces the subcategory block.
local function Navigation()
    local entries = {}
    for i, c in ipairs(Tabs()) do
        entries[#entries+1] = {Name=c.Name, Main=i, Active=i==MainIdx}
    end
    return entries
end

local function ScrollNavigation(delta)
    NavOffset = math.max(0, math.min(NavOffset+delta, #Navigation()-Geo().navRows))
end

local function ScrollSubcategories(delta)
    SubOffset=math.max(0,math.min(SubOffset+delta,#SubTabs()-Geo().subSlots))
end

local function PageCount()
    local rows = Geo().rows
    return math.max(1, math.ceil(#View / rows))
end

-- Id de categoria dos produtos mostrados agora: a subaba (se a principal tiver) ou a propria principal
local function ActiveCategoryId()
    local c = SHOP_CONFIG.Categories[MainIdx]
    if c == nil then return 0 end
    if c.Sub ~= nil and #c.Sub > 0 then
        local sc = c.Sub[SubIdx] or c.Sub[1]
        return sc.Id
    end
    return c.Id
end

local function Rebuild()
    View = {}
    Category = ActiveCategoryId()
    for i = 1, #Products do
        if Products[i].Category == Category then
            table.insert(View, Products[i])
        end
    end
    if Page > PageCount() - 1 then Page = PageCount() - 1 end
    if Page < 0 then Page = 0 end
end

local function SetMessage(text, isError)
    MsgText = text
    MsgError = isError
    MsgFrames = MESSAGE_FRAMES
end

local function CoinName(id)
    local c = CoinById[id]
    if c ~= nil then return c.Name end
    return "#" .. tostring(id)
end

------------------------------------------------------------------------------
-- Desenho (todo texto passa por Text(): o fundo preto do texto some)
------------------------------------------------------------------------------

local function Text(x, y, str, w, align, font, r, g, b)
    EnableAlphaTest()
    SetFontType(font)
    SetTextBg(0, 0, 0, 0)
    SetTextColor(r, g, b, 255)
    RenderText3(x, y, str, w, align)
    DisableAlphaBlend()
end

local function Bar(x, y, w, h, r, g, b, a)
    EnableAlphaTest()
    SetBlend()
    glColor4f(r, g, b, a)
    DrawBar(x, y, w, h)
    EndDrawBar()
    GLSwitchBlend()
    glColor3f(1.0, 1.0, 1.0)
    GLSwitch()
    glColor3f(1.0, 1.0, 1.0)
    DisableAlphaBlend()
end

local function Frame(x, y, w, h, r, g, b, a)
    EnableAlphaTest()
    SetBlend()
    glColor4f(r, g, b, a)
    DrawBox(x, y, w, h)
    EndDrawBar()
    GLSwitchBlend()
    glColor3f(1.0, 1.0, 1.0)
    GLSwitch()
    glColor3f(1.0, 1.0, 1.0)
    DisableAlphaBlend()
end

-- Botao proprio (sem imagem): preenchimento + moldura dourada + texto centralizado.
local function Button(x, y, w, h, label, enabled, selected)
    local hover = enabled and Confirm == nil and Inside(x,y,w,h)
    local bright = selected or hover
    Bar(x,y,w,h, bright and .73 or .34, bright and .56 or .29, bright and .26 or .20,1)
    Bar(x+1,y+1,w-2,h-2,bright and .20 or .065,bright and .17 or .07,bright and .11 or .07,1)
    Bar(x+2,y+2,w-4,1,.48,.41,.28,enabled and 1 or .3)
    local r,g,b = 230,193,119
    if not enabled then r,g,b=100,98,88 end
    if label=='<' or label=='>' or label=='X' then
        local width=label=='X' and 9 or 6
        local left,top=x+(w-width)/2,y+(h-9)/2
        for row=0,8 do
            if label=='X' then
                Bar(left+row,top+row,1,1,r/255,g/255,b/255,1)
                if row~=4 then Bar(left+8-row,top+row,1,1,r/255,g/255,b/255,1) end
            else
                local column=label=='<' and math.abs(row-4) or 4-math.abs(row-4)
                Bar(left+column,top+row,2,1,r/255,g/255,b/255,1)
            end
        end
    else
        Text(x+4,y+math.floor((h-10)/2),label,w-8,3,1,r,g,b)
    end
end

local function Fit(str, width)
    local n=math.max(1,math.floor(width/5))
    if #str>n then return string.sub(str,1,math.max(1,n-3))..'...' end
    return str
end

local function Wrapped(x,y,str,w,r,g,b)
    local line, row = '', 0
    local limit=math.floor(w/5)
    for word in string.gmatch(str,'%S+') do
        if #line+#word+1>limit and line~='' then
            Text(x,y+row*12,line,w,3,0,r,g,b)
            line=''; row=row+1
        end
        line=line=='' and word or line..' '..word
    end
    Text(x,y+row*12,line,w,3,0,r,g,b)
end

local function IconSettings(itemIndex)
    local d = SHOP_CONFIG.ItemIconDefault
    local c = Calib[itemIndex] or SHOP_CONFIG.ItemIcons[itemIndex] or d
    return {
        X = c.X or d.X, Y = c.Y or d.Y, W = c.W or d.W, H = c.H or d.H, S = c.S or d.S,
    }
end

-- Desenha o icone do item centralizado no quadro (cx, cy).
-- Usa o modelo (BMD) que o proprio cliente ja carrega para esse item (CreateItem),
-- igual ao NpcRescueItem/JewelBank. Nao depende de nenhum arquivo de imagem.
local function RenderItemIcon(cx, cy, item, slot)
    local s = IconSettings(item.ItemIndex)
    local x = cx - 13 + s.X
    local y = cy - 15 + s.Y

    -- Mesmos ajustes de posicao por grupo usados no NpcRescueItem
    if item.ItemIndex >= GET_ITEM(0, 15) and item.ItemIndex < GET_ITEM(5, 0) then
        y = y + 17 * s.S
    end
    if item.ItemIndex >= GET_ITEM(5, 0) and item.ItemIndex < GET_ITEM(6, 0) then
        y = y + 10 * s.S
    end

    DisableAlphaBlend()
    CreateItem(x, y, s.W, s.H, item.ItemIndex, item.Level, 0, 0, s.S)
    EndDrawBar()
end

local function RenderRow(g, row, product, labelsOnly)
    local x, y = g.listX, g.listY + row * g.rowH
    local h, slot = g.rowH-4, 50
    if not labelsOnly then
        Bar(x,y,g.listW,h,.34,.29,.20,1)
        Bar(x+1,y+1,g.listW-2,h-2,.065,.07,.07,1)
        Bar(x+4,y+4,slot,slot,.025,.03,.03,1)
        Frame(x+4,y+4,slot,slot,.34,.29,.20,1)
        table.insert(IconQueue,{cx=x+29,cy=y+29,item=product.Items[1],slot=slot})
        return
    end
    -- Opaque text area after ALL models: custom BMDs cannot cover the labels.
    Bar(x+60,y+2,g.listW-62,h-4,.065,.07,.07,1)
    local width=g.listW-70
    Text(x+64,y+7,Fit(product.Name,width),width,1,1,222,222,214)
    Text(x+64,y+21,Fit(product.Desc,width),width,1,0,148,147,133)
    local bx,by,bw,bh=BuyButtonRect(g,row)
    Text(x+64,y+40,Fit(string.format('%d %s',product.Price,CoinName(product.Coin)),width-bw-8),width-bw-8,1,1,230,193,119)
    Button(bx,by,bw,bh,Texts().Buy,Waiting==0 and Confirm==nil)
end

local function RenderTooltip(g)
    if Confirm ~= nil then return end
    for row = 0, g.rows - 1 do
        local product = View[Page * g.rows + row + 1]
        if product ~= nil then
            local y = g.listY + row * g.rowH
            if Inside(g.listX+4, y+4, 50, 50) then
                local it = product.Items[1]
                EnableAlphaTest()
                glColor4f(1.0, 1.0, 1.0, 1.0)
                -- SockCount/sockets em 255 = sem socket (mesmo valor usado pelo DropBox no servidor)
                ShowDescriptionComplete(MousePosX() + 20, MousePosY(), it.ItemIndex, it.Level, it.Skill, it.Luck, it.Option, it.Exc, 0, 0, 255, 255, 255, 255, 255, 255)
                DisableAlphaBlend()
                return
            end
        end
    end
end

local function RenderConfirm(g)
    local t = Texts()
    Bar(g.x, g.y, g.w, g.h, 0.0, 0.0, 0.0, 0.7)
    Bar(g.cx, g.cy, g.cw, g.ch, 0.065, 0.07, 0.07, 1.0)
    Frame(g.cx, g.cy, g.cw, g.ch, COLOR_GOLD_R, COLOR_GOLD_G, COLOR_GOLD_B, 1.0)

    Text(g.cx, g.cy + 10, t.ConfirmTitle, g.cw, 3, 1, 255, 189, 25)
    Wrapped(g.cx + 10, g.cy + 34, string.format(t.ConfirmText, Confirm.Name, Confirm.Price, CoinName(Confirm.Coin)), g.cw - 20, 222, 222, 214)

    Button(g.ok.x, g.ok.y, g.ok.w, g.ok.h, t.Ok, true)
    Button(g.cancel.x, g.cancel.y, g.cancel.w, g.cancel.h, t.Cancel, true)
end

-- Linha pronta para colar em ItemIcons (modo Calibrate)
local function CalibLine(itemIndex)
    local s = IconSettings(itemIndex)
    return string.format("[GET_ITEM(%d, %d)] = { X = %d, Y = %d, W = %d, H = %d, S = %.2f },",
        math.floor(itemIndex / 512), itemIndex % 512, s.X, s.Y, s.W, s.H, s.S)
end

local function HoveredRowItem(g)
    for row = 0, g.rows - 1 do
        local product = View[Page * g.rows + row + 1]
        if product ~= nil then
            local y = g.listY + row * g.rowH
            if Inside(g.listX, y, g.listW - g.buyW - 100, g.rowH - 2) then
                return product.Items[1]
            end
        end
    end
    return nil
end

local function BalanceText(value)
    local separator=GetLanguage()=='Eng' and ',' or '.'
    return (tostring(value):reverse():gsub('(%d%d%d)','%1'..separator):reverse():gsub('^['..separator..']',''))
end

local function DrawSidebar(g)
    local t=Texts()
    Bar(g.sideX-3,g.y+34,g.sideW+6,g.h-64,.035,.04,.04,.92)
    Text(g.sideX+4,g.y+41,t.Categories,g.sideW-48,1,0,148,147,133)
    local entries=Navigation()
    ScrollNavigation(0)
    if #entries>g.navRows then
        Button(g.catPrev.x,g.catPrev.y,18,16,'<',NavOffset>0)
        Button(g.catNext.x,g.catNext.y,18,16,'>',NavOffset<#entries-g.navRows)
    end
    Frame(g.sideX-1,g.tabsY-3,g.sideW,g.navRows*g.tabH+2,.22,.20,.15,1)
    for row=0,g.navRows-1 do
        local e=entries[NavOffset+row+1]
        if e then
            Button(g.sideX+3,g.tabsY+row*g.tabH,g.sideW-10,g.tabH-2,Fit(e.Name,g.sideW-18),true,e.Active)
        end
    end
    Bar(g.sideX,g.balY-8,g.sideW-4,1,.34,.29,.20,1)
    Bar(g.sideX,g.balY-3,g.sideW-4,18,.13,.11,.075,1)
    Text(g.sideX+8,g.balY+1,t.Balance,g.sideW-16,1,1,230,193,119)
    local pages=math.max(1,math.ceil(#Coins/3))
    CoinPage=math.min(CoinPage,pages-1)
    for row=0,2 do
        local c=Coins[CoinPage*3+row+1]
        if c then
            local y=g.balY+21+row*36
            local w=g.sideW-4
            Bar(g.sideX,y,w,30,.055,.06,.06,1)
            Frame(g.sideX,y,w,30,.48,.39,.25,1)
            Bar(g.sideX+1,y+1,3,28,.73,.56,.26,1)
            Bar(g.sideX+6,y+1,w-8,1,.25,.22,.16,1)
            Text(g.sideX+11,y+4,Fit(c.Name,w-22),w-22,1,1,232,228,211)
            Text(g.sideX+11,y+17,BalanceText(c.Balance),w-22,2,1,255,216,139)
        end
    end
end

local function DrawSubcategories(g)
    local subs=SubTabs()
    if #subs==0 then return end
    ScrollSubcategories(0)
    -- Subcategory tabs appear immediately when their parent category is selected.
    Bar(g.listX,g.subY,g.selector.w,g.dropH,.055,.06,.06,1)
    for column=0,g.subSlots-1 do
        local index=SubOffset+column+1
        if subs[index] then
            Button(g.subX+column*g.subW,g.subY,g.subW-2,g.subH,Fit(subs[index].Name,g.subW-10),true,index==SubIdx)
        end
    end
    if #subs>g.subSlots then
        Button(g.subPrev.x,g.subPrev.y,20,20,'<',SubOffset>0)
        Button(g.subNext.x,g.subNext.y,20,20,'>',SubOffset<#subs-g.subSlots)
    end
end

function Shop.Render()
    if Pending > 0 then
        Pending = Pending - 1
    end

    if Waiting > 0 then
        Waiting = Waiting - 1
        if Waiting == 0 then
            SetMessage(Texts().Timeout, true)
        end
    end

    if Visible ~= 1 then
        return
    end

    if MsgFrames > 0 then
        MsgFrames = MsgFrames - 1
        if MsgFrames == 0 then MsgText = nil end
    end

    local g = Geo()
    local t = Texts()
    local bg = SHOP_CONFIG.Background
    Bar(g.x,g.y,g.w,g.h,bg.R,bg.G,bg.B,1)
    EnableAlphaTest()
    glColor4f(1,1,1,1)
    RenderImage2(IMAGE,g.x,g.y,g.w,g.h,0,0,1,1,1,1,1)
    DisableAlphaBlend()
    Bar(g.x+3,g.y+3,g.w-6,g.h-6,.035,.04,.045,.55)
    Frame(g.x,g.y,g.w,g.h,.34,.29,.20,1)
    Frame(g.x+3,g.y+3,g.w-6,g.h-6,.48,.41,.28,1)
    Bar(g.x+7,g.y+7,g.w-14,25,.035,.04,.04,.92)
    Text(g.x+12,g.y+14,t.Title,g.w-52,3,1,230,193,119)
    Button(g.close.x,g.close.y,g.close.w,g.close.h,'X',true)
    DrawSidebar(g)
    Bar(g.x+159,g.y+38,1,g.h-77,.34,.29,.20,1)
    local category=SHOP_CONFIG.Categories[MainIdx]
    local sub=SubTabs()[SubIdx]
    local breadcrumb=category and CatName(category) or ''
    if sub then breadcrumb=breadcrumb..' / '..sub.Name end
    if not sub then
        Text(g.listX,g.y+42,Fit(breadcrumb,g.selector.w),g.selector.w,1,1,230,193,119)
    end
    if HasPending then Button(g.collect.x,g.collect.y,g.collect.w,g.collect.h,t.Collect,Waiting==0) end


    -- produtos
    IconQueue = {}
    if #View == 0 then
        Text(g.listX, g.listY + 20, t.NoProducts, g.listW, 3, 1, 180, 180, 180)
    else
        for row = 0, g.rows - 1 do
            local product = View[Page * g.rows + row + 1]
            if product ~= nil then
                RenderRow(g, row, product)
            end
        end
    end

    -- icones 3D por ultimo: nada desenhado depois cobre o item
    for i = 1, #IconQueue do
        local q = IconQueue[i]
        RenderItemIcon(q.cx, q.cy, q.item, q.slot)
    end
    IconQueue = {}

    for row=0,g.rows-1 do
        local product=View[Page*g.rows+row+1]
        if product then RenderRow(g,row,product,true) end
    end
    Bar(g.listX,g.footY,g.listW,1,.34,.29,.20,1)
    Button(g.prev.x,g.prev.y,g.prev.w,g.prev.h,'<',Page>0)
    Button(g.next.x,g.next.y,g.next.w,g.next.h,'>',Page<PageCount()-1)
    Text(g.listX+30,g.navY+5,string.format(t.Page,Page+1,PageCount()),g.listW-60,3,0,148,147,133)


    -- mensagem
    if Waiting > 0 then
        Text(g.listX, g.msgY, t.Processing, g.listW, 3, 1, 255, 255, 255)
    elseif MsgText ~= nil then
        if MsgError then
            Wrapped(g.x+12, g.msgY, MsgText, g.w-24, 255, 120, 100)
        else
            Wrapped(g.x+12, g.msgY, MsgText, g.w-24, 151, 210, 155)
        end
    end

    -- modo calibrar: mostra a linha para colar em ItemIcons
    if SHOP_CONFIG.Calibrate then
        local it = HoveredRowItem(g)
        if it ~= nil then
            Text(g.listX, g.msgY - 12, CalibLine(it.ItemIndex), g.listW, 1, 0, 255, 255, 0)
        else
            Text(g.listX, g.msgY - 12, "CALIBRAR: passe o mouse na linha do item (setas, +/-, PgUp/PgDn)", g.listW, 1, 0, 255, 255, 0)
        end
    end

    DrawSubcategories(g)
    RenderTooltip(g)

    if Confirm ~= nil then
        RenderConfirm(g)
    end
end

------------------------------------------------------------------------------
-- Cliques / teclado
------------------------------------------------------------------------------

function Shop.UpdateMouse()
    if Visible ~= 1 then return end

    local g = Geo()

    if not Inside(g.x, g.y, g.w, g.h) then return end
    local click=CheckClickClient()
    DisableClickClient()
    if click ~= 1 then return end

    -- Tudo que for clique dentro da janela e consumido (nao atravessa para o mundo)
    DisableClickClient()

    -- Janela de confirmacao e modal
    if Confirm ~= nil then
        if Inside(g.ok.x, g.ok.y, g.ok.w, g.ok.h) then
            local product = Confirm
            Confirm = nil
            Shop.SendBuy(product.Id)
        elseif Inside(g.cancel.x, g.cancel.y, g.cancel.w, g.cancel.h) then
            Confirm = nil
        end
        return
    end

    if Inside(g.close.x, g.close.y, g.close.w, g.close.h) then
        Shop.Close()
        return
    end

    if HasPending and Waiting==0 and Inside(g.collect.x,g.collect.y,g.collect.w,g.collect.h) then
        Shop.SendCollect(); return
    end
    if Inside(g.catPrev.x,g.catPrev.y,18,16) then ScrollNavigation(-1); return end
    if Inside(g.catNext.x,g.catNext.y,18,16) then ScrollNavigation(1); return end
    local subs=SubTabs()
    if #subs>0 then
        if #subs>g.subSlots and Inside(g.subPrev.x,g.subPrev.y,20,20) then ScrollSubcategories(-1); return end
        if #subs>g.subSlots and Inside(g.subNext.x,g.subNext.y,20,20) then ScrollSubcategories(1); return end
        for column=0,g.subSlots-1 do
            local index=SubOffset+column+1
            if subs[index] and Inside(g.subX+column*g.subW,g.subY,g.subW-2,g.subH) then
                SubIdx=index; Page=0; Rebuild(); return
            end
        end
    end
    local entries=Navigation()
    for row=0,g.navRows-1 do
        local e=entries[NavOffset+row+1]
        if e and Inside(g.sideX,g.tabsY+row*g.tabH,g.sideW-4,g.tabH-2) then
            MainIdx=e.Main
            SubIdx,SubOffset=1,0
                    Page=0
            Rebuild()
            ScrollNavigation(0)
            return
        end
    end


    -- paginacao
    if Page > 0 and Inside(g.prev.x, g.prev.y, g.prev.w, g.prev.h) then
        Page = Page - 1
        return
    end
    if Page < PageCount() - 1 and Inside(g.next.x, g.next.y, g.next.w, g.next.h) then
        Page = Page + 1
        return
    end

    -- botoes Comprar
    if Waiting > 0 then return end
    for row = 0, g.rows - 1 do
        local product = View[Page * g.rows + row + 1]
        if product ~= nil then
            local bx, by, bw, bh = BuyButtonRect(g, row)
            if Inside(bx, by, bw, bh) then
                Confirm = product
                return
            end
        end
    end
end

function Shop.ScrollMouse(value)
    if Visible ~= 1 or Confirm ~= nil then return end
    local g = Geo()
    if not Inside(g.x, g.y, g.w, g.h) then return end

    if #SubTabs()>0 and Inside(g.listX,g.subY,g.selector.w,g.dropH) then
        ScrollSubcategories(value>0 and -1 or 1); return
    end
    if Inside(g.sideX,g.tabsY,g.sideW,g.navRows*g.tabH) then
        ScrollNavigation(value>0 and -1 or 1); return
    end
    if Inside(g.sideX,g.balY,g.sideW,g.balH) then
        CoinPage=math.max(0,math.min(CoinPage+(value>0 and -1 or 1),math.max(0,math.ceil(#Coins/3)-1))); return
    end
    if not Inside(g.listX,g.listY,g.listW,g.rows*g.rowH) then return end
    if value > 0 and Page > 0 then
        Page = Page - 1
    elseif value < 0 and Page < PageCount() - 1 then
        Page = Page + 1
    end
end

-- Modo Calibrate: ajusta o icone do item sob o mouse
local function CalibrateKeys()
    if not SHOP_CONFIG.Calibrate or Confirm ~= nil then return end

    local g = Geo()
    local it = HoveredRowItem(g)
    if it == nil then return end

    local s = IconSettings(it.ItemIndex)
    local changed = false

    if CheckRepeatKey(Keys.Left)  == 1 then s.X = s.X - 1; changed = true end
    if CheckRepeatKey(Keys.Right) == 1 then s.X = s.X + 1; changed = true end
    if CheckRepeatKey(Keys.Up)    == 1 then s.Y = s.Y - 1; changed = true end
    if CheckRepeatKey(Keys.Down)  == 1 then s.Y = s.Y + 1; changed = true end
    if CheckRepeatKey(Keys.Add)      == 1 then s.W = s.W + 1; s.H = s.H + 1; changed = true end
    if CheckRepeatKey(Keys.Subtract) == 1 then s.W = math.max(4, s.W - 1); s.H = math.max(4, s.H - 1); changed = true end
    if CheckRepeatKey(Keys.PageUp) == 1 then s.S = s.S + 0.05; changed = true end
    if CheckRepeatKey(Keys.Next)   == 1 then s.S = math.max(0.1, s.S - 0.05); changed = true end

    if changed then
        Calib[it.ItemIndex] = s
    end
end

function Shop.UpdateKey()
    if Visible ~= 1 then return end

    if CheckPressedKey(Keys.Escape) == 1 then
        if Confirm ~= nil then
            Confirm = nil
        else
            Shop.Close()
        end
        return
    end

    CalibrateKeys()

    -- Se outra janela do jogo abrir (inclusive o menu ESC), a loja fecha
    if CheckWindowOpen(UIFriendList)    == 1
        or CheckWindowOpen(UIMoveList)      == 1
        or CheckWindowOpen(UIParty)         == 1
        or CheckWindowOpen(UIQuest)         == 1
        or CheckWindowOpen(UIGuild)         == 1
        or CheckWindowOpen(UITrade)         == 1
        or CheckWindowOpen(UIWarehouse)     == 1
        or CheckWindowOpen(UIChaosBox)      == 1
        or CheckWindowOpen(UICommandWindow) == 1
        or CheckWindowOpen(UIPetInfo)       == 1
        or CheckWindowOpen(UIShop)          == 1
        or CheckWindowOpen(UIStore)         == 1
        or CheckWindowOpen(UIOtherStore)    == 1
        or CheckWindowOpen(UICharacter)     == 1
        or CheckWindowOpen(UIFastMenu)      == 1
        or CheckWindowOpen(UIOptions)       == 1
        or CheckWindowOpen(UIHelp)          == 1
        or CheckWindowOpen(UIFastDial)      == 1
        or CheckWindowOpen(UISkillTree)     == 1
        or CheckWindowOpen(UINPC_Titus)     == 1
        or CheckWindowOpen(UICashShop)      == 1
        or CheckWindowOpen(UIFullMap)       == 1
        or CheckWindowOpen(UINPC_Dialog)    == 1
        or CheckWindowOpen(UIGensInfo)      == 1
        or CheckWindowOpen(UINPC_Julia)     == 1
        or CheckWindowOpen(UIExpandWarehouse) == 1
        or CheckWindowOpen(UIMuHelper)      == 1
    then
        Shop.Close()
    end
end

------------------------------------------------------------------------------
-- Abrir / fechar
------------------------------------------------------------------------------

function Shop.IsOpen()
    return Visible == 1
end

function Shop.Open()
    if SHOP_CONFIG == nil or not SHOP_CONFIG.Enabled then return end
    if Visible == 1 or Pending > 0 then return end
    if UICustomInterface ~= 0 then return end

    -- Mesmo criterio do MenuWindow.Open: algumas janelas impedem abrir, outras sao fechadas
    if  CheckWindowOpen(UIFriendList)    == 1 then return end
    if  CheckWindowOpen(UIMoveList)      == 1 then return end
    if  CheckWindowOpen(UIQuest)         == 1 then return end
    if  CheckWindowOpen(UITrade)         == 1 then return end
    if  CheckWindowOpen(UIWarehouse)     == 1 then return end
    if  CheckWindowOpen(UIChaosBox)      == 1 then return end
    if  CheckWindowOpen(UICommandWindow) == 1 then return end
    if  CheckWindowOpen(UIPetInfo)       == 1 then return end
    if  CheckWindowOpen(UIShop)          == 1 then return end
    if  CheckWindowOpen(UIOtherStore)    == 1 then return end
    if  CheckWindowOpen(UIFastMenu)      == 1 then return end
    if  CheckWindowOpen(UIOptions)       == 1 then return end
    if  CheckWindowOpen(UIHelp)          == 1 then return end
    if  CheckWindowOpen(UIFastDial)      == 1 then return end
    if  CheckWindowOpen(UISkillTree)     == 1 then return end
    if  CheckWindowOpen(UINPC_Titus)     == 1 then return end
    if  CheckWindowOpen(UICashShop)      == 1 then return end
    if  CheckWindowOpen(UIFullMap)       == 1 then return end
    if  CheckWindowOpen(UINPC_Dialog)    == 1 then return end
    if  CheckWindowOpen(UINPC_Julia)     == 1 then return end
    if  CheckWindowOpen(UIExpandWarehouse) == 1 then return end

    Pending = OPEN_TIMEOUT_FRAMES

    local packet = string.format("%s-%s", SHOP_PACKET_OPEN, UserGetName())
    CreatePacket(packet, SHOP_CONFIG.Packet)
    SendPacket(packet)
    ClearPacket(packet)
end

local function Show()
    if CheckWindowOpen(UIParty)           == 1 then CloseWindow(UIParty)           end
    if CheckWindowOpen(UIGuild)           == 1 then CloseWindow(UIGuild)           end
    if CheckWindowOpen(UIStore)           == 1 then CloseWindow(UIStore)           end
    if CheckWindowOpen(UICharacter)       == 1 then CloseWindow(UICharacter)       end
    if CheckWindowOpen(UIGensInfo)        == 1 then CloseWindow(UIGensInfo)        end
    if CheckWindowOpen(UIExpandInventory) == 1 then CloseWindow(UIExpandInventory) end
    if CheckWindowOpen(UIMuHelper)        == 1 then CloseWindow(UIMuHelper)        end
    if CheckWindowOpen(UIInventory)       == 1 then CloseWindow(UIInventory)       end

    Pending = 0
    NavOffset, SubOffset, CoinPage = 0, 0, 0
    HasPending = false
    Confirm = nil
    MainIdx = 1
    SubIdx = 1
    Page = 0
    Waiting = 0
    Rebuild()

    if Visible ~= 1 then
        Visible = 1
        SetLockInterfaces()
    end
end

function Shop.Close()
    if Visible == 1 then
        SetUnlockInterfaces()
    end
    Visible = 0
    Pending = 0
    Waiting = 0
    Confirm = nil
    MsgText = nil
    MsgFrames = 0
    Products = {}
    View = {}
    Coins = {}
    CoinById = {}
end

------------------------------------------------------------------------------
-- Rede
------------------------------------------------------------------------------

function Shop.SendBuy(productId)
    if Visible ~= 1 or Waiting > 0 then return end

    Waiting = BUY_TIMEOUT_FRAMES
    MsgText = nil

    local packet = string.format("%s-%s", SHOP_PACKET_BUY, UserGetName())
    CreatePacket(packet, SHOP_CONFIG.Packet)
    SetDwordPacket(packet, productId)
    SendPacket(packet)
    ClearPacket(packet)
end

function Shop.SendCollect()
    if Visible~=1 or Waiting>0 then return end
    Waiting=BUY_TIMEOUT_FRAMES
    MsgText=nil
    local packet=string.format("SHOPI_CLAIM-%s",UserGetName())
    CreatePacket(packet,SHOP_CONFIG.Packet)
    SendPacket(packet)
    ClearPacket(packet)
end

local function ReadData(packet)
    -- moedas: byte quantidade; cada uma: id, nome (byte+texto), saldo
    Coins = {}
    CoinById = {}
    local coinCount = GetBytePacket(packet, -1)
    for i = 1, coinCount do
        local c = {}
        c.Id = GetBytePacket(packet, -1)
        local len = GetBytePacket(packet, -1)
        c.Name = GetCharPacketLength(packet, -1, len)
        c.Balance = GetDwordPacket(packet, -1)
        table.insert(Coins, c)
        CoinById[c.Id] = c
    end

    local count = GetDwordPacket(packet, -1)
    Products = {}

    for i = 1, count do
        local p = {}
        p.Id = GetDwordPacket(packet, -1)

        local len = GetBytePacket(packet, -1)
        p.Name = GetCharPacketLength(packet, -1, len)

        len = GetBytePacket(packet, -1)
        if len > 0 then
            p.Desc = GetCharPacketLength(packet, -1, len)
        else
            p.Desc = ""
        end

        p.Category = GetBytePacket(packet, -1)
        p.Coin = GetBytePacket(packet, -1)
        p.Price = GetDwordPacket(packet, -1)

        local itemCount = GetBytePacket(packet, -1)
        p.Items = {}
        for j = 1, itemCount do
            local it = {}
            it.ItemIndex = GetWordPacket(packet, -1)
            it.Level = GetBytePacket(packet, -1)
            it.Skill = GetBytePacket(packet, -1)
            it.Luck = GetBytePacket(packet, -1)
            it.Option = GetBytePacket(packet, -1)
            it.Exc = GetBytePacket(packet, -1)
            table.insert(p.Items, it)
        end

        -- produto sem item nao tem o que mostrar: descarta
        if itemCount > 0 then
            table.insert(Products, p)
        end
    end

end

function Shop.ClientProtocol(Packet, PacketName)
    if SHOP_CONFIG == nil or Packet ~= SHOP_CONFIG.Packet then return end

    local name = UserGetName()

    if PacketName == string.format("%s-%s", SHOP_PACKET_DATA, name) then
        if Pending > 0 or Visible == 1 then
            ReadData(PacketName)
            Show()
        end
        ClearPacket(PacketName)
        return 1
    end

    if PacketName == string.format("%s-%s", SHOP_PACKET_RESULT, name) then
        local code = GetBytePacket(PacketName, -1)
        local count = GetBytePacket(PacketName, -1)
        for i = 1, count do
            local id = GetBytePacket(PacketName, -1)
            local value = GetDwordPacket(PacketName, -1)
            if CoinById[id] ~= nil then
                CoinById[id].Balance = value
            end
        end
        ClearPacket(PacketName)

        local t = Texts()
        local wasOpening = (Visible ~= 1 and Pending > 0)

        if wasOpening then
            -- Resposta ao pedido de abertura (ex.: loja desativada): mostra a janela vazia com a mensagem
            Products = {}
            Coins = {}
            CoinById = {}
            Show()
        end

        Waiting = 0
        HasPending = code==8 or code==10
        local text = t.Results[code]
        if text == nil then
            SetMessage(t.Unknown, true)
        else
            SetMessage(text, code ~= 1)
        end
        return 1
    end
end

------------------------------------------------------------------------------
-- Inicializacao (registra cada callback uma unica vez)
------------------------------------------------------------------------------

function Shop.Init()
    -- BeforeMainProc (igual ao NpcRescueItem/JewelBank): e nessa etapa que o CreateItem (modelo 3D)
    -- desenha na posicao certa. Em MainProc o item 3D aparece fora do lugar.
    InterfaceController.LoadImages(function() LoadImage("Custom\\Interface\\shop_inventory.jpg",IMAGE) end)
    InterfaceController.BeforeMainProc(Shop.Render)
    InterfaceController.UpdateMouse(Shop.UpdateMouse)
    InterfaceController.UpdateKey(Shop.UpdateKey)
    InterfaceController.ScrollMouse(Shop.ScrollMouse)
    InterfaceController.ClientProtocol(Shop.ClientProtocol)
end

Shop.Init()

return Shop
