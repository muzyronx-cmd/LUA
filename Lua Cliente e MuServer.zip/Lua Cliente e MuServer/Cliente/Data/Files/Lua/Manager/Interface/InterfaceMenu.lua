OtherInterface = {}

function OtherInterface.Start()

MemorySetByte    (0x0059AF53+2,0);
MemorySetByte    (0x0059B248+2,0);

MemorySet        (0x00D20170, 0x90, 0x1B)       -- Remove MuError.log
MemorySetByte    (0x004D1CF0,0xC3)              -- Remove MuError.dmp
MemorySetByte    (0x0082B400, 0xC3)             -- desabilitar load de minimap
--MemorySet        (0x007A8330,0x90,0x198);       -- SHOPPING X
--MemorySet        (0x009D0268, 0xC3, 1 )         -- SHOPPING X
MemorySetByte    (0x00785B33, 0x01)             -- qualidade
MemorySetByte    (0x005BAFAB, 0xE8)             -- (CRenderBoolean)
MemorySetByte    (0x00661700, 0x90, 0x43)
MemorySetByte    (0x007D3D7A, 0x90, 0x05)
MemorySetByte    ((0x007D3D56+1), 0xFF)
MemorySetByte    (0x005528A0,0xC3)
MemorySetByte    (0x006097B0, 0xC3)			    --PLUS EFFECT +15	
MemorySet        (0x006097B0,0x90,0x69D) 		--Remove +15 Effects (ALTERADO)
MemorySet        (0x0057BF78, 0x90, 0x05) 		--pin_lights eyes
MemorySet        (0x0057C125, 0x90, 0x05)		--pin_lights eyes
MemorySet        (0x0057BE80, 0x90, 0x05) 		--JointLaser01 eyes
MemorySet        (0x0057C057, 0x90, 0x05) 		--JointLaser01 eyes
MemorySet        (0x0057BF0E, 0x90, 0x05) 		--shiny05 eyes
MemorySet        (0x0057C0BB, 0x90, 0x05) 		--shiny05 eyes
MemorySet        (0x0057ABA9, 0x90, 0x05) 		--flare01 Gloves
MemorySet        (0x0057ACBF, 0x90, 0x05) 		--flare01 Gloves
MemorySet        (0x0057AD03, 0x90, 0x05) 		--flare01 Gloves
MemorySet        (0x0057AD47, 0x90, 0x05) 		--flare01 Gloves
MemorySetFloat   (0x00D43220, 0x00);            -- DESABILITAR ICONS B
MemorySetFloat   (0x00D43224, 0x00);            -- DESABILITAR ICONS B
MemorySet        (0x0085B6AC, 0x90, 0x05); 	    -- Remove Helper Top Screen
MemorySetByte    (0x00552DEB+1, 0xE7);


end

OtherInterface.Start()

return OtherInterface