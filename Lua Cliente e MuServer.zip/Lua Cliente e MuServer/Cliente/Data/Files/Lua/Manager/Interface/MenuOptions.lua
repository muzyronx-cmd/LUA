local MENU_OPTIONS_SWITCH = 1 -- 0 disable

local Menu_WindowID = 2

local Menu_ResOptions = {
{ListID = 1, Value = 0, Nome = "640 x 480"},
{ListID = 2, Value = 1, Nome = "800 x 600"},
{ListID = 3, Value = 2, Nome = "1024 x 768"},
{ListID = 4, Value = 3, Nome = "1280 x 1024"},
{ListID = 5, Value = 4, Nome = "1366 x 768"},
{ListID = 6, Value = 5, Nome = "1440 x 900"},
{ListID = 7, Value = 6, Nome = "1600 x 900"},
{ListID = 8, Value = 7, Nome = "1680 x 1050"},
{ListID = 9, Value = 8, Nome = "1920 x 1080"},
}

local Menu_LangOptions = {
{ListID = 1, Value = "Por", Nome = "Português"},
{ListID = 2, Value = "Eng", Nome = "English"},
{ListID = 3, Value = "Spn", Nome = "Español"},
}

local Menu_FontOptions = {
{ListID = 1, Value = 11, Nome = "11"},
{ListID = 2, Value = 12, Nome = "12"},
{ListID = 3, Value = 13, Nome = "13"},
{ListID = 4, Value = 14, Nome = "14"},
{ListID = 5, Value = 15, Nome = "15"},
}

local Menu_Texts = {}

Menu_Texts["Eng"] ={
[1] = " Resolution ",
[2] = " Language ",
[3] = " Font Size ",
[4] = " Volume: %d ",
[5] = " Disable Monsters health bar ",
[6] = " Disable Static Effects ",
[7] = " Disable Dynamic Effects ",
[8] = " Disable Glow of Items ",
[9] = " Disable Shadow ",
[10] = " Disable Wing/Cloak ",
[11] = " Auto Ctrl ",
[12] = " CLOSE ",
}

Menu_Texts["Por"] ={
[1] = " Resolução ",
[2] = " Idioma ",
[3] = " Tamanho da Fonte ",
[4] = " Volume: %d ",
[5] = " Desativar Barra de vida monstros ",
[6] = " Desativar Efeitos Estáticos ",
[7] = " Desativar Efeitos Dinâmicos ",
[8] = " Desativar Glow dos Itens ",
[9] = " Desativar Sombra ",
[10] = " Desativar Asa/Capa ",
[11] = " Auto Ctrl ",
[12] = " FECHAR ",
}

Menu_Texts["Spn"] ={
[1] = " Resolución ",
[2] = " Idioma ",
[3] = " Tamaño de fuente ",
[4] = " Volume: %d ",
[5] = " Desactivar Barra de salud de monstruos ",
[6] = " Desactivar Efectos estáticos ",
[7] = " Desactivar Efectos dinámicos ",
[8] = " Desactivar Glow dos Itens ",
[9] = " Desactivar Sombra ",
[10] = " Desactivar Asa/Capa ",
[11] = " Auto Ctrl ",
[12] = " CERRAR ",
}

Menu = {}
Menu_Buttons = {}
local Menu_CurrentRes = GetResolution()
local Menu_CurrentLang = GetLanguage()
local Menu_CurrentFont = GetFontValue()
local Menu_ResDropdown = {Show = false, Change = 0}
local Menu_LangDropdown = {Show = false, Change = 0}
local Menu_FontDropdown = {Show = false, Change = 0}
-- ===== LAYOUT DO MENU (tela 640x480) =====
-- Para mover o menu inteiro, mude Menu_Panel.X / Menu_Panel.Y.
local Menu_Panel = {X = 180, Y = 36, W = 280, H = 378}
local Menu_Fields = {
	[1] = {X = Menu_Panel.X + 16,  Y = Menu_Panel.Y + 62,  W = 116, H = 22}, -- Resolucao
	[2] = {X = Menu_Panel.X + 148, Y = Menu_Panel.Y + 62,  W = 116, H = 22}, -- Idioma
	[3] = {X = Menu_Panel.X + 16,  Y = Menu_Panel.Y + 114, W = 116, H = 22}, -- Fonte
}
local Menu_DropH = 18
local Menu_TrackX = Menu_Panel.X + 152
local Menu_TrackY = Menu_Panel.Y + 125
local Menu_RowsY = Menu_Panel.Y + 164
local Menu_RowH = 22
local Menu_RowStep = 24
local Menu_Title = {Por = "CONFIGURAÇÕES", Eng = "SETTINGS", Spn = "CONFIGURACIÓN"}
local Menu_VolumeArea = {X1 = Menu_TrackX - 6, Y1 = Menu_TrackY - 9, X2 = Menu_TrackX + 106, Y2 = Menu_TrackY + 9}
local Menu_VolumeSlider = {}
for i = 0, 10 do Menu_VolumeSlider[i] = Menu_TrackX - 5 + i * 10 end

local Menu_VolumePosition = 0
local Menu_ResDropdownChange = 0
local Menu_ResDropdownCount = 0
local Menu_LangDropdownChange = 0
local Menu_LangDropdownCount = 0
local Menu_FontDropdownChange = 0
local Menu_FontDropdownCount = 0

local Menu_MonsterHealthBar = 0 
local Menu_StaticEffect = 0 
local Menu_DynamicEffect = 0 
local Menu_Glow = 0 
local Menu_Shadow = 0
local Menu_Wings = 0  
local Menu_AutoCtrl = 0


function Menu.Open()
	if UICustomInterface ~= Menu_WindowID then
		Menu_CurrentRes = GetResolution()
		Menu_CurrentLang = GetLanguage()
		Menu_CurrentFont = GetFontValue()
		Menu_VolumePosition = GetVolume()
		UICustomInterface = Menu_WindowID
	end
end

function Menu.Close()
	CloseWindow(UIOptions)
	UICustomInterface = 0
	Menu.SetLangDropdownOff()
	Menu.SetFontDropdownOff()
	Menu.SetResDropdownOff()
	Menu_ResDropdownChange = 0
	Menu_ResDropdownCount = 0
	Menu_LangDropdownChange = 0
	Menu_LangDropdownCount = 0
	Menu_FontDropdownChange = 0
	Menu_FontDropdownCount = 0
end

function Menu.CreateButton(IdBotao, X, Y, W, H)
	if Menu_Buttons[IdBotao] == nil then
		table.insert(Menu_Buttons, IdBotao)
	end
	Menu_Buttons[IdBotao] = {X1 = X, X2 = X+W, Y1 = Y, Y2 = Y+H}
end

function Menu.CheckButton(IdBotao, X, Y)
	if Menu_Buttons[IdBotao] == nil then return false end
	if X >= Menu_Buttons[IdBotao].X1 and X <= Menu_Buttons[IdBotao].X2 and Y >= Menu_Buttons[IdBotao].Y1 and Y <= Menu_Buttons[IdBotao].Y2 then
		return true
	end
	return false
end

-- ===== DESENHO (sem imagens: tudo desenhado por barras) =====
local function mText(x, y, str, w, align, font, r, g, b)
	EnableAlphaTest()
	SetFontType(font)
	SetTextBg(0, 0, 0, 0)
	SetTextColor(r, g, b, 255)
	RenderText3(x, y, str, w, align)
	DisableAlphaBlend()
end

local function mBar(x, y, w, h, r, g, b, a)
	EnableAlphaTest()
	SetBlend()
	glColor4f(r, g, b, a)
	DrawBar(x, y, w, h)
	EndDrawBar()
	GLSwitchBlend()
	glColor3f(1.0, 1.0, 1.0)
	GLSwitch()
	glColor3f(1.0, 1.0, 1.0)
	DisableAlphaBlend()
end

local function mFrame(x, y, w, h, r, g, b, a)
	mBar(x, y, w, 1, r, g, b, a)
	mBar(x, y + h - 1, w, 1, r, g, b, a)
	mBar(x, y, 1, h, r, g, b, a)
	mBar(x + w - 1, y, 1, h, r, g, b, a)
end

local function mInside(x, y, w, h)
	local mx, my = MousePosX(), MousePosY()
	return mx >= x and mx <= x + w and my >= y and my <= y + h
end

local function mTrim(str)
	return (string.gsub(str, "^%s*(.-)%s*$", "%1"))
end

function Menu.DropRect(field, i)
	local f = Menu_Fields[field]
	return f.X, f.Y + f.H + 2 + (i - 1) * Menu_DropH, f.W, Menu_DropH
end

local function mArrow(x, y, open)
	-- seta pequena (triangulo) feita de barras
	for k = 0, 3 do
		if open then
			mBar(x + k, y + 3 - k, 7 - 2 * k, 1, 1.0, 0.82, 0.30, 1.0)
		else
			mBar(x + k, y + k, 7 - 2 * k, 1, 0.80, 0.80, 0.80, 1.0)
		end
	end
end

local function mField(id, label, valueText, isOpen)
	local f = Menu_Fields[id]
	mText(f.X, f.Y - 14, label, f.W, 1, 0, 255, 208, 90)
	Menu.CreateButton(id, f.X, f.Y, f.W, f.H)

	local hover = Menu.CheckButton(id, MousePosX(), MousePosY())
	if isOpen then
		mBar(f.X, f.Y, f.W, f.H, 0.20, 0.16, 0.06, 1.0)
		mFrame(f.X, f.Y, f.W, f.H, 1.0, 0.82, 0.30, 1.0)
	elseif hover then
		mBar(f.X, f.Y, f.W, f.H, 0.17, 0.17, 0.21, 1.0)
		mFrame(f.X, f.Y, f.W, f.H, 0.85, 0.68, 0.22, 1.0)
	else
		mBar(f.X, f.Y, f.W, f.H, 0.12, 0.12, 0.15, 1.0)
		mFrame(f.X, f.Y, f.W, f.H, 0.30, 0.30, 0.36, 1.0)
	end
	mText(f.X + 8, f.Y + 6, valueText, f.W - 28, 1, 1, 240, 240, 240)
	mArrow(f.X + f.W - 14, f.Y + 9, isOpen)
end

local function mToggle(id, row, label, state)
	local x = Menu_Panel.X + 10
	local y = Menu_RowsY + (row - 1) * Menu_RowStep
	local w = Menu_Panel.W - 20
	Menu.CreateButton(id, x, y, w, Menu_RowH)

	if Menu.CheckButton(id, MousePosX(), MousePosY()) then
		mBar(x, y, w, Menu_RowH, 0.16, 0.16, 0.20, 1.0)
	end

	mText(x + 8, y + 6, label, w - 60, 1, 1, 225, 225, 225)

	-- chave liga/desliga
	local tw, th = 28, 12
	local tx = x + w - tw - 8
	local ty = y + math.floor((Menu_RowH - th) / 2)
	if state == 1 then
		mBar(tx, ty, tw, th, 0.90, 0.66, 0.10, 1.0)
		mBar(tx + tw - th + 1, ty + 1, th - 2, th - 2, 1.0, 1.0, 1.0, 1.0)
	else
		mBar(tx, ty, tw, th, 0.26, 0.26, 0.30, 1.0)
		mBar(tx + 1, ty + 1, th - 2, th - 2, 0.62, 0.62, 0.66, 1.0)
	end
end

local function mDropdown(field, options, current, shown, countKey)
	local f = Menu_Fields[field]
	local n = #options
	local vis = math.min(shown, n)
	if vis < 1 then return end
	mBar(f.X, f.Y + f.H + 1, f.W, vis * Menu_DropH + 2, 0.08, 0.08, 0.10, 0.98)
	mFrame(f.X, f.Y + f.H + 1, f.W, vis * Menu_DropH + 2, 1.0, 0.82, 0.30, 1.0)
	for i = 1, vis do
		if shown >= i then
			local dx, dy, dw, dh = Menu.DropRect(field, i)
			local selected = (options[i].Value == current)
			if mInside(dx, dy, dw, dh) then
				mBar(dx + 1, dy + 1, dw - 2, dh - 1, 0.42, 0.33, 0.08, 1.0)
			elseif selected then
				mBar(dx + 1, dy + 1, dw - 2, dh - 1, 0.22, 0.18, 0.06, 1.0)
			end
			mText(dx + 8, dy + 5, options[i].Nome, dw - 12, 1, 0, 255, 255, 255)
		end
	end
end

function Menu.MainProc()
	if UICustomInterface == Menu_WindowID then
		local lang = GetLanguage()
		local T = Menu_Texts[lang]
		local P = Menu_Panel

		-- fundo + moldura + cabecalho
		mBar(P.X - 1, P.Y - 1, P.W + 2, P.H + 2, 0.0, 0.0, 0.0, 0.55)
		mBar(P.X, P.Y, P.W, P.H, 0.06, 0.06, 0.08, 0.97)
		mFrame(P.X, P.Y, P.W, P.H, 0.45, 0.36, 0.12, 1.0)
		mBar(P.X + 1, P.Y + 1, P.W - 2, 34, 0.11, 0.11, 0.14, 1.0)
		mBar(P.X + 1, P.Y + 35, P.W - 2, 2, 0.90, 0.66, 0.10, 1.0)
		mText(P.X, P.Y + 12, Menu_Title[lang] or Menu_Title["Por"], P.W, 3, 1, 255, 208, 90)

		-- botao X (fecha)
		local cx, cy, cw, ch = P.X + P.W - 26, P.Y + 8, 18, 18
		Menu.CreateButton(13, cx, cy, cw, ch)
		if Menu.CheckButton(13, MousePosX(), MousePosY()) then
			mBar(cx, cy, cw, ch, 0.55, 0.12, 0.12, 1.0)
		end
		mText(cx, cy + 4, "X", cw, 3, 1, 255, 255, 255)

		-- campos (dropdown)
		local resName, langName, fontName = "", "", ""
		for i in ipairs(Menu_ResOptions) do if Menu_ResOptions[i].Value == Menu_CurrentRes then resName = Menu_ResOptions[i].Nome end end
		for i in ipairs(Menu_LangOptions) do if Menu_LangOptions[i].Value == Menu_CurrentLang then langName = Menu_LangOptions[i].Nome end end
		for i in ipairs(Menu_FontOptions) do if Menu_FontOptions[i].Value == Menu_CurrentFont then fontName = Menu_FontOptions[i].Nome end end

		mField(1, mTrim(T[1]), resName, Menu_ResDropdown.Show)
		mField(2, mTrim(T[2]), langName, Menu_LangDropdown.Show)
		mField(3, mTrim(T[3]), fontName, Menu_FontDropdown.Show)

		-- volume (barra com marcador)
		mText(Menu_Fields[2].X, Menu_Fields[3].Y - 14, mTrim(string.format(T[4], Menu_VolumePosition)), Menu_Fields[2].W, 1, 0, 255, 208, 90)
		mBar(Menu_TrackX, Menu_TrackY - 2, 100, 4, 0.22, 0.22, 0.27, 1.0)
		if Menu_VolumePosition > 0 then
			mBar(Menu_TrackX, Menu_TrackY - 2, Menu_VolumePosition * 10, 4, 0.90, 0.66, 0.10, 1.0)
		end
		local kx = Menu_VolumeSlider[Menu_VolumePosition] + 1
		mBar(kx, Menu_TrackY - 7, 8, 14, 1.0, 0.88, 0.45, 1.0)
		mFrame(kx, Menu_TrackY - 7, 8, 14, 0.45, 0.36, 0.12, 1.0)

		-- divisor
		mBar(P.X + 14, P.Y + 150, P.W - 28, 1, 0.30, 0.30, 0.36, 1.0)

		-- opcoes (liga/desliga) - ids 5..11, mesma ordem de antes
		mToggle(5, 1, mTrim(T[5]), Menu_MonsterHealthBar)
		mToggle(6, 2, mTrim(T[6]), Menu_StaticEffect)
		mToggle(7, 3, mTrim(T[7]), Menu_DynamicEffect)
		mToggle(8, 4, mTrim(T[8]), Menu_Glow)
		mToggle(9, 5, mTrim(T[9]), Menu_Shadow)
		mToggle(10, 6, mTrim(T[10]), Menu_Wings)
		mToggle(11, 7, mTrim(T[11]), Menu_AutoCtrl)

		-- botao fechar
		local bw, bh = 120, 26
		local bx, by = P.X + math.floor((P.W - bw) / 2), P.Y + P.H - bh - 12
		Menu.CreateButton(12, bx, by, bw, bh)
		local over = Menu.CheckButton(12, MousePosX(), MousePosY())
		if over and CheckPressedKey(Keys.LButton) == 1 then
			mBar(bx, by + 1, bw, bh, 0.30, 0.22, 0.04, 1.0)
		elseif over then
			mBar(bx, by, bw, bh, 0.55, 0.42, 0.08, 1.0)
		else
			mBar(bx, by, bw, bh, 0.30, 0.24, 0.06, 1.0)
		end
		mFrame(bx, by, bw, bh, 1.0, 0.82, 0.30, 1.0)
		mText(bx, by + 8, mTrim(T[12]), bw, 3, 1, 255, 235, 180)

		-- listas (por cima de tudo); a animacao de abertura continua igual
		if Menu_ResDropdown.Show then mDropdown(1, Menu_ResOptions, Menu_CurrentRes, Menu_ResDropdownChange) end
		if Menu_ResDropdownCount == 1 then
			if Menu_ResDropdownChange < #Menu_ResOptions then
				Menu_ResDropdownChange = Menu_ResDropdownChange + 1
				Menu_ResDropdownCount = 0
			end
		else
			Menu_ResDropdownCount = Menu_ResDropdownCount + 1
		end

		if Menu_LangDropdown.Show then mDropdown(2, Menu_LangOptions, Menu_CurrentLang, Menu_LangDropdownChange) end
		if Menu_LangDropdownCount == 1 then
			if Menu_LangDropdownChange < #Menu_LangOptions then
				Menu_LangDropdownChange = Menu_LangDropdownChange + 1
				Menu_LangDropdownCount = 0
			end
		else
			Menu_LangDropdownCount = Menu_LangDropdownCount + 1
		end

		if Menu_FontDropdown.Show then mDropdown(3, Menu_FontOptions, Menu_CurrentFont, Menu_FontDropdownChange) end
		if Menu_FontDropdownCount == 1 then
			if Menu_FontDropdownChange < #Menu_FontOptions then
				Menu_FontDropdownChange = Menu_FontDropdownChange + 1
				Menu_FontDropdownCount = 0
			end
		else
			Menu_FontDropdownCount = Menu_FontDropdownCount + 1
		end

		DisableAlphaBlend()
	end
end

function Menu.KeyListener(key)
	if key == 27 then
		if UICustomInterface == Menu_WindowID then
			Menu.Close()
		end
	end

end

function Menu.ClickEvent()
	if UICustomInterface == Menu_WindowID then		
		if Menu.CheckButton(1, MousePosX(), MousePosY()) then
			if Menu_ResDropdown.Show then Menu.SetResDropdownOff(); return else Menu_ResDropdown.Show = true; Menu_ResDropdownChange = 0; Menu_ResDropdownCount = 0; Menu.SetLangDropdownOff(); Menu.SetFontDropdownOff(); return end
		end
		if Menu.CheckButton(2, MousePosX(), MousePosY()) then
			if Menu_LangDropdown.Show then Menu.SetLangDropdownOff(); return else Menu_LangDropdown.Show = true; Menu_LangDropdownChange = 0; Menu_LangDropdownCount = 0; Menu.SetResDropdownOff(); Menu.SetFontDropdownOff(); return end
		end
		if Menu.CheckButton(3, MousePosX(), MousePosY()) then
			if Menu_FontDropdown.Show then Menu.SetFontDropdownOff(); return else Menu_FontDropdown.Show = true; Menu_FontDropdownChange = 0; Menu_FontDropdownCount = 0; Menu.SetResDropdownOff(); Menu.SetLangDropdownOff(); return end
		end
		
		if Menu_ResDropdown.Show then
			local starty = 105			
			for i in ipairs(Menu_ResOptions) do
				if mInside(Menu.DropRect(1, i)) then
					Menu_CurrentRes = Menu_ResOptions[i].Value
					SetResolution(Menu_CurrentRes)
					Menu.RegisterWindowSetKey("Resolution", Menu_CurrentRes)
					Menu_CurrentFont = GetFontValue()
					-- DEFINE A RESOLUÇÃO ESCOLHIDA NO DROPDOWN
					Menu.SetResDropdownOff()
					return
				end
				starty = starty+15
			end
		end
		
		if Menu_LangDropdown.Show then			
			local starty = 105			
			for i in ipairs(Menu_LangOptions) do
				if mInside(Menu.DropRect(2, i)) then
					Menu_CurrentLang = Menu_LangOptions[i].Value
					Menu.RegisterWindowSetStringKey("LangSelection", Menu_CurrentLang)
					SetLanguage(Menu_CurrentLang)
					-- DEFINE O IDIOMA ESCOLHIDO NO DROPDOWN
					Menu.SetLangDropdownOff()
					return
				end
				starty = starty+15
			end
		end
		
		if Menu_FontDropdown.Show then
			local starty = 160			
			for i in ipairs(Menu_FontOptions) do
				if mInside(Menu.DropRect(3, i)) then
					Menu_CurrentFont = Menu_FontOptions[i].Value
					SetFontValue(Menu_CurrentFont)
					Menu.RegisterWindowSetKey("FontValue", Menu_CurrentFont)
					-- DEFINE A FONTE ESCOLHIDA NO DROPDOWN
					Menu.SetFontDropdownOff()
					return
				end
				starty = starty+15
			end
		end
		
		if Menu.CheckButton(5, MousePosX(), MousePosY()) 
		then
			if Menu_FontDropdown.Show or Menu_ResDropdown.Show or Menu_LangDropdown.Show 
			then 
				return 
			end
			
			if Menu_MonsterHealthBar == 1 
			then 
				Menu_MonsterHealthBar = 0 
			else 
				Menu_MonsterHealthBar = 1 
			end
			
			SetHealthBarSwitch(Menu_MonsterHealthBar)
			Menu.RegisterWindowSetKey("HealthBarDisabled", Menu_MonsterHealthBar)
			return
		end
		
		if Menu.CheckButton(6, MousePosX(), MousePosY()) then
			if Menu_FontDropdown.Show or Menu_ResDropdown.Show or Menu_LangDropdown.Show 
			then 
				return 
			end
			
			if Menu_StaticEffect == 1 
			then 
				Menu_StaticEffect = 0 
				MemorySetByte(0x771310, 0x55)
			else 
				Menu_StaticEffect = 1 
				MemorySetByte(0x771310, 0xC3)
			end
			
			Menu.RegisterWindowSetKey("StaticEffectDisabled", Menu_StaticEffect)
			return
		end
		
		if Menu.CheckButton(7, MousePosX(), MousePosY()) then
			if Menu_FontDropdown.Show or Menu_ResDropdown.Show or Menu_LangDropdown.Show 
			then 
				return 
			end
			
			if Menu_DynamicEffect == 1 
			then 
				Menu_DynamicEffect = 0
				MemorySetByte(0x74CD30, 0x55)
			else 
				Menu_DynamicEffect = 1 
				MemorySetByte(0x74CD30, 0xC3)
			end
			
			Menu.RegisterWindowSetKey("DynamicEffectDisabled", Menu_DynamicEffect)
			return
		end
		
		if Menu.CheckButton(8, MousePosX(), MousePosY()) then
			if Menu_FontDropdown.Show or Menu_ResDropdown.Show or Menu_LangDropdown.Show 
			then 
				return 
			end
			
			if Menu_Glow == 1 
			then 
				Menu_Glow = 0 
				SetGlowSwitch(5)
			else 
				Menu_Glow = 1 
				SetGlowSwitch(0)
			end
			
			Menu.RegisterWindowSetKey("GlowDisabled", Menu_Glow)
			return
		end
		
		if Menu.CheckButton(9, MousePosX(), MousePosY()) then
			if Menu_FontDropdown.Show or Menu_ResDropdown.Show or Menu_LangDropdown.Show 
			then 
				return 
			end
			
			if Menu_Shadow == 1 
			then 
				Menu_Shadow = 0 
				MemorySetByte(0x54A270, 0x55)
			else 
				Menu_Shadow = 1 
				MemorySetByte(0x54A270, 0xC3)
			end
			
			Menu.RegisterWindowSetKey("ShadowDisable", Menu_Shadow)
			return
		end
		
		if Menu.CheckButton(10, MousePosX(), MousePosY()) then
			if Menu_FontDropdown.Show or Menu_ResDropdown.Show or Menu_LangDropdown.Show 
			then 
				return 
			end
			if Menu_Wings == 1 
			then 
				Menu_Wings = 0 
			else 
				Menu_Wings = 1 
			end
			
			Menu.RegisterWindowSetKey("WingDisable", Menu_Wings)
			SetWingSwitch(Menu_Wings)
			return
		end
		
		if Menu.CheckButton(11, MousePosX(), MousePosY()) then
			if Menu_FontDropdown.Show or Menu_ResDropdown.Show or Menu_LangDropdown.Show 
			then 
				return 
			end
			
			if Menu_AutoCtrl == 1
			then
				MemorySetByte(0x0059AF44, 0x7D)
				MemorySetByte(0x0059B239, 0x7D)
				Menu_AutoCtrl = 0 
			else
				MemorySetByte(0x0059AF44, 0xEB)
				MemorySetByte(0x0059B239, 0xEB)
				Menu_AutoCtrl = 1 
			end
			
			Menu.RegisterWindowSetKey("AutoCtrl", Menu_AutoCtrl)
			return
		end
		
		if Menu.CheckButton(12, MousePosX(), MousePosY()) or Menu.CheckButton(13, MousePosX(), MousePosY()) then
			Menu.Close()
			return
		end
		
		if MousePosX() >= Menu_VolumeArea.X1 and MousePosX() <= Menu_VolumeArea.X2 and MousePosY() >= Menu_VolumeArea.Y1 and MousePosY() <= Menu_VolumeArea.Y2 then
			if Menu_ResDropdown.Show or Menu_FontDropdown.Show or Menu_LangDropdown.Show then return end
			
			for i = 0, 10 do
				if MousePosX() >= Menu_VolumeSlider[i] and MousePosX() <= Menu_VolumeSlider[i] + 9 then
					Menu_VolumePosition = i
					-- DEFINE O VOLUME ESCOLHIDO COM CLIQUE DO MOUSE NA BARRA
					SetVolume(i)
					Menu.RegisterWindowSetKey("VolumeLevel", i)
					
					if i <= 0
					then
						Menu.RegisterWindowSetKey("SoundOnOff", 1)
						Menu.RegisterWindowSetKey("MusicOnOff", 1)
					else
						Menu.RegisterWindowSetKey("SoundOnOff", 0)
						Menu.RegisterWindowSetKey("MusicOnOff", 0)
					end
				end
			end
			return
		end		
	end
end

function Menu.SetResDropdownOff()
	Menu_ResDropdown = {Show = false, Change = 0}
end

function Menu.SetLangDropdownOff()
	Menu_LangDropdown = {Show = false, Change = 0}
end

function Menu.SetFontDropdownOff()
	Menu_FontDropdown = {Show = false, Change = 0}
end

function Menu.UpdateMouse()
	if UICustomInterface == Menu_WindowID then
		if mInside(Menu_Panel.X, Menu_Panel.Y, Menu_Panel.W, Menu_Panel.H) then
			DisableClickClient()
			return
		end
	end
end

function Menu.UpdateProc()
	if CheckWindowOpen(UIOptions) == 1 then
		Menu.Open()
	end
end

function Menu.ScrollMouse(Direction)
	if CheckWindowOpen(UIOptions) == 1 then
		if MousePosX() >= Menu_VolumeArea.X1 and MousePosX() <= Menu_VolumeArea.X2 and MousePosY() >= Menu_VolumeArea.Y1 and MousePosY() <= Menu_VolumeArea.Y2 then
			if Menu_ResDropdown.Show or Menu_FontDropdown.Show or Menu_LangDropdown.Show then return end
			
			if Direction > 0 then
				if Menu_VolumePosition < 10 then
					Menu_VolumePosition = Menu_VolumePosition + 1
					-- AUMENTA UM NIVEL DO VOLUME
				end
			else
				if Menu_VolumePosition > 0 then
					Menu_VolumePosition = Menu_VolumePosition - 1
					-- DIMINUI UM NIVEL DO VOLUME
				end
			end
			return
		end
	end
end

function Menu.RegisterWindowGetKey(keyValue)
	return getValueRegKey(keyValue)
end

function Menu.RegisterWindowSetKey(keyValue, value)
	setValueRegKey(keyValue, value)
end

function Menu.RegisterWindowGetStringKey(keyValue, size)
	return getStringRegKey(keyValue, size)
end

function Menu.RegisterWindowSetStringKey(keyValue, value)
	setStringRegKey(keyValue, value)
end

function Menu.FinalBoot()
	local getRegisterFontValue = Menu.RegisterWindowGetKey("FontValue")
	
	if (getRegisterFontValue ~= -1)
	then
		SetFontValue(getRegisterFontValue)
	end
	
	local getHealthBarDisabled = Menu.RegisterWindowGetKey("HealthBarDisabled")
	
	if (getHealthBarDisabled ~= -1)
	then
		Menu_MonsterHealthBar = getHealthBarDisabled
		SetHealthBarSwitch(Menu_MonsterHealthBar)
	else
		Menu_MonsterHealthBar = 0
		SetHealthBarSwitch(Menu_MonsterHealthBar)
	end
	
	local getStaticEffectDisabled = Menu.RegisterWindowGetKey("StaticEffectDisabled")
	
	if (getStaticEffectDisabled ~= -1)
	then
		Menu_StaticEffect = getStaticEffectDisabled
		
		if Menu_StaticEffect == 1
		then
			MemorySetByte(0x771310, 0xC3)
		else
			MemorySetByte(0x771310, 0x55)
		end
	else
		Menu_StaticEffect = 0
		MemorySetByte(0x771310, 0x55)
	end
	
	local getDynamicEffectDisabled = Menu.RegisterWindowGetKey("DynamicEffectDisabled")
	
	if (getDynamicEffectDisabled ~= -1)
	then
		Menu_DynamicEffect = getDynamicEffectDisabled
		
		if Menu_DynamicEffect == 1
		then
			MemorySetByte(0x74CD30, 0xC3)
		else
			MemorySetByte(0x74CD30, 0x55)
		end
	else
		Menu_DynamicEffect = 0
		MemorySetByte(0x74CD30, 0x55)
	end
	
	local getGlowDisabled = Menu.RegisterWindowGetKey("GlowDisabled")
	
	if (getGlowDisabled ~= -1)
	then
		Menu_Glow = getGlowDisabled
		
		if Menu_Glow == 1
		then
			SetGlowSwitch(0)
		else
			SetGlowSwitch(5)
		end
	else
		Menu_Glow = 0
		SetGlowSwitch(5)
	end
	
	local getShadowDisable = Menu.RegisterWindowGetKey("ShadowDisable")
	
	if (getShadowDisable ~= -1)
	then
		Menu_Shadow = getShadowDisable
		
		if Menu_Shadow == 1
		then
			MemorySetByte(0x54A270, 0xC3)
		else
			MemorySetByte(0x54A270, 0x55)
		end
	else
		Menu_Shadow = 0
		MemorySetByte(0x54A270, 0x55)
	end
	
	local getWingDisabled = Menu.RegisterWindowGetKey("WingDisable")
	
	if (getWingDisabled ~= -1)
	then
		Menu_Wings = getWingDisabled
		SetWingSwitch(Menu_Wings)
	else
		Menu_Wings = 0
		SetWingSwitch(Menu_Wings)
	end
	
	local getAutoCtrl = Menu.RegisterWindowGetKey("AutoCtrl")
	
	if (getAutoCtrl ~= -1)
	then
		Menu_AutoCtrl = getAutoCtrl
		
		if Menu_AutoCtrl == 1
		then
			MemorySetByte(0x0059AF44, 0xEB)
			MemorySetByte(0x0059B239, 0xEB)
		else
			MemorySetByte(0x0059AF44, 0x7D)
			MemorySetByte(0x0059B239, 0x7D)
		end
	else
		Menu_AutoCtrl = 0
		MemorySetByte(0x0059AF44, 0x7D)
		MemorySetByte(0x0059B239, 0x7D)
	end
end

function Menu.Start()
	if MENU_OPTIONS_SWITCH == 0
	then
		return
	end
	
	InterfaceController.MainProc(Menu.MainProc)
	InterfaceController.MainProcWorldKey(Menu.KeyListener)
	InterfaceController.InterfaceClickEvent(Menu.ClickEvent)
	InterfaceController.UpdateMouse(Menu.UpdateMouse)
	InterfaceController.UpdateProc(Menu.UpdateProc)
	InterfaceController.ScrollMouse(Menu.ScrollMouse)
	InterfaceController.FinalBoot(Menu.FinalBoot)
end

Menu.Start()

return Menu