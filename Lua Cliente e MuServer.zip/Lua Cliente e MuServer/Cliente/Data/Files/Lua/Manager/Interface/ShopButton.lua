-- VERSAO v7 (botoes desenhados pelo script, sem depender de JPG/OZJ)
--[[
    ShopButton.lua
    Botoes do topo (canto superior esquerdo):

        [Menu]  [Shop]

    - Menu: abre/fecha o menu do ESC (janela UIFastMenu).
    - Shop: abre a loja (Shop.Open() em Customs/Shop/Shop.lua).

    Imagens opcionais (UseTextures = true); por padrao o desenho e feito em Lua:
        Custom\\Interface\\btn_shop.jpg   ID 600106
        Custom\\Interface\\btn_menu.jpg   ID 600107

    CONFIGURACAO (tudo logo abaixo, em ShopButton.Buttons):
        X, Y        posicao do botao
        W, H        tamanho com que a imagem e desenhada
        ImageID     ID da imagem (nil = botao desenhado pelo script, sem imagem)
        UV          trecho da imagem a desenhar: { U, V, UW, VH } (padrao = imagem inteira).
                    Se o icone aparecer cortado, ajuste W/H para o tamanho REAL do .jpg
                    (ou use UV para escolher a parte certa de uma imagem com varios estados).

    O clique e tratado em UpdateMouse com CheckClickClient() (um disparo por clique)
    e DisableClickClient(), entao nao aciona outro botao/o mundo junto.
]]

SHOP_BUTTON_SWITCH = 1

ShopButton = {}

-- Desenho em bronze sem depender dos arquivos JPG/OZJ ou do carregador de imagens.
-- Ative somente se desejar voltar a usar as texturas externas.
ShopButton.UseTextures = false

-- Espaco entre os botoes
ShopButton.Gap = 6

-- Texto ao passar o mouse: desligado (aparece so o botao)
ShopButton.ShowTooltip = false

-- Janela aberta pelo botao Menu: o ESC abre UIOptions (35), que o MenuOptions.lua transforma no menu customizado.
-- (UIFastMenu 34 e o menu da tecla U, desativado no Main.dll.)
-- Janela aberta pelo botao Menu (menu do ESC). Se o seu cliente usar outro ID, troque aqui.
ShopButton.MenuWindowId = UIOptions or 35

-- DIAGNOSTICO: ligue (true), entre no jogo e aperte ESC. Aparece no topo da tela a lista de IDs de
-- janela abertos. O numero que surgir ao abrir o menu do ESC e o valor certo para MenuWindowId
-- (ex.: ShopButton.MenuWindowId = 34). Depois volte para false.
ShopButton.DebugWindows = false

ShopButton.Buttons = {
    {
        Name = "Menu", Tooltip = "MENU",
        X = 8, Y = 8, W = 26, H = 25,
        ImageID = 600107,
        UV = { U = 0.0, V = 0.0, UW = 1.0, VH = 1.0 },
        Action = "OpenMenu",
    },
    {
        Name = "Shop", Tooltip = "SHOP",
        X = 8 + 26 + 6, Y = 8, W = 26, H = 25,     -- tamanho REAL do btn_shop.jpg (26x25)
        ImageID = 600106,
        UV = { U = 0.0, V = 0.0, UW = 1.0, VH = 1.0 },
        Action = "OpenShop",
    },
}

-- O carregador global legado pode ser substituido pelo dispatcher da interface.
-- Registra as texturas aqui para os botoes receberem suas imagens nessa fase.
function ShopButton.LoadImages()
    if not ShopButton.UseTextures then return end
    LoadImage("Custom\\Interface\\btn_shop.jpg", 600106)
    LoadImage("Custom\\Interface\\btn_menu.jpg", 600107)
end

function ShopButton.IsVisible()
    if SHOP_BUTTON_SWITCH ~= 1 then
        return false
    end

    if CheckWindowOpen(UIFullMap) == 1 or CheckWindowOpen(UICashShop) == 1 then
        return false
    end

    return true
end

local function MouseOver(b)
    local mouseX = MousePosX()
    local mouseY = MousePosY()

    return mouseX >= b.X and mouseX <= b.X + b.W
       and mouseY >= b.Y and mouseY <= b.Y + b.H
end

local function DrawImage(b, x, y, w, h)
    local uv = b.UV
    if uv == nil or (uv.U == 0.0 and uv.V == 0.0 and uv.UW == 1.0 and uv.VH == 1.0) then
        RenderImage(b.ImageID, x, y, w, h)
    else
        RenderImage2(b.ImageID, x, y, w, h, uv.U, uv.V, uv.UW, uv.VH, 1, 1, 1.0)
    end
end

local function DrawScriptButton(b, x, y, pressed)
    local shade = pressed and 0.8 or 1.0
    local function bar(dx, dy, w, h, r, g, blue)
        EnableAlphaTest()
        SetBlend()
        glColor4f(r * shade, g * shade, blue * shade, 1.0)
        DrawBar(x + dx, y + dy, w, h)
        EndDrawBar()
        GLSwitchBlend()
        GLSwitch()
        glColor3f(1, 1, 1)
        DisableAlphaBlend()
    end
    -- Contorno, fundo e relevo nas mesmas cores do shop/roleta.
    bar(0, 0, b.W, b.H, .34, .29, .20)
    bar(1, 1, b.W - 2, b.H - 2, .065, .07, .07)
    bar(2, 2, b.W - 4, 1, .64, .53, .33)
    bar(2, b.H - 3, b.W - 4, 1, .17, .15, .10)
    local function gold(dx, dy, w, h)
        bar(dx, dy, w, h, .90, .76, .47)
    end
    -- Icones centralizados na area original de 26x25 pixels.
    local cx, cy = (b.W - 26) / 2, (b.H - 25) / 2
    local function icon(dx, dy, w, h) gold(cx + dx, cy + dy, w, h) end
    if b.Action == "OpenMenu" then
        for _, row in ipairs({7, 11, 15}) do icon(7, row, 12, 2) end
    else
        icon(5, 6, 4, 2)
        for row = 0, 6 do
            icon(8 + math.floor(row / 3), 8 + row, 2, 1)
            icon(19 - math.floor(row / 3), 8 + row, 2, 1)
        end
        icon(9, 8, 11, 1)
        icon(11, 14, 7, 1)
        icon(10, 16, 9, 1)
        icon(10, 18, 2, 2)
        icon(17, 18, 2, 2)
    end
end

function ShopButton.RenderButton(b)
    local over = MouseOver(b)
    local pressed = over and CheckPressedKey(Keys.LButton) == 1
    local x, y = b.X, b.Y
    if pressed then x, y = x + 1, y + 1 end

    if ShopButton.UseTextures and b.ImageID ~= nil then
        EnableAlphaTest()
        local shade = pressed and 0.8 or 1.0
        glColor4f(shade, shade, shade, shade)
        DrawImage(b, x, y, b.W, b.H)
        glColor4f(1.0, 1.0, 1.0, 1.0)
        DisableAlphaBlend()
    else
        DrawScriptButton(b, x, y, pressed)
    end

    if over and ShopButton.ShowTooltip and b.Tooltip ~= nil then
        EnableAlphaTest()
        SetFontType(1)
        SetTextBg(0, 0, 0, 180)
        SetTextColor(255, 255, 255, 255)
        RenderText3(b.X + b.W + 6, b.Y + 16, b.Tooltip, 60, 3)
        DisableAlphaBlend()
    end
end

function ShopButton.Render()
    if not ShopButton.IsVisible() then
        return
    end

    if ShopButton.DebugWindows then
        local open = {}
        for id = 1, 80 do
            if CheckWindowOpen(id) == 1 then
                table.insert(open, tostring(id))
            end
        end
        EnableAlphaTest()
        SetFontType(1)
        SetTextBg(0, 0, 0, 200)
        SetTextColor(255, 255, 0, 255)
        RenderText3(8, 44, "JANELAS ABERTAS: " .. table.concat(open, ", "), 400, 1)
        RenderText3(8, 58, "MenuWindowId=" .. tostring(ShopButton.MenuWindowId)
            .. "  aberto=" .. tostring(CheckWindowOpen(ShopButton.MenuWindowId))
            .. "  cliques no Menu=" .. tostring(ShopButton.DebugClicks or 0), 400, 1)
        DisableAlphaBlend()
    end

    for i = 1, #ShopButton.Buttons do
        ShopButton.RenderButton(ShopButton.Buttons[i])
    end
end

function ShopButton.OpenShop()
    -- O Shop principal esta em Customs/Shop/Shop.lua
    if Shop ~= nil and Shop.Open ~= nil then
        Shop.Open()
    end
end

function ShopButton.OpenMenu()
    local id = ShopButton.MenuWindowId
    ShopButton.DebugClicks = (ShopButton.DebugClicks or 0) + 1

    -- fecha a loja antes de abrir o menu (a loja trava a interface)
    if Shop ~= nil and Shop.IsOpen ~= nil and Shop.IsOpen() then
        Shop.Close()
    end

    -- mesmo efeito de apertar ESC: se o menu ja esta aberto, fecha; senao, abre
    if CheckWindowOpen(id) == 1 then
        CloseWindow(id)
    else
        OpenWindow(id)
    end
end

function ShopButton.UpdateMouse()
    if not ShopButton.IsVisible() then
        return
    end

    if CheckClickClient() ~= 1 then
        return
    end

    for i = 1, #ShopButton.Buttons do
        local b = ShopButton.Buttons[i]
        if MouseOver(b) then
            -- consome o clique: nao aciona outro botao nem o mundo
            DisableClickClient()
            ShopButton[b.Action]()
            return
        end
    end
end

-- Alguns clientes desenham os customs em BeforeMainProc; outros em MainProc.
-- Se ambas as etapas forem chamadas, desenha uma unica vez por quadro.
local beforeRendered = false
function ShopButton.BeforeRender()
    beforeRendered = true
    ShopButton.Render()
end

function ShopButton.MainFallback()
    if not beforeRendered then ShopButton.Render() end
    beforeRendered = false
end

function ShopButton.Init()
    if SHOP_BUTTON_SWITCH ~= 1 then
        return
    end

    if InterfaceController.LoadImages ~= nil then
        InterfaceController.LoadImages(ShopButton.LoadImages)
    end
    if InterfaceController.BeforeMainProc ~= nil then
        InterfaceController.BeforeMainProc(ShopButton.BeforeRender)
    end
    InterfaceController.MainProc(ShopButton.MainFallback)
    InterfaceController.UpdateMouse(ShopButton.UpdateMouse)
end

ShopButton.Init()

return ShopButton
