InterfaceInfos = {}

function InterfaceInfos.Render()
	if	CheckWindowOpen(UIFriendList)		== 1	then	return							end
	if	CheckWindowOpen(UIMoveList)			== 1	then	return							end
	if	CheckWindowOpen(UIParty)			== 1	then	return							end
	if	CheckWindowOpen(UIQuest)			== 1	then	return							end
	if	CheckWindowOpen(UIGuild)			== 1	then	return							end
	if	CheckWindowOpen(UITrade)			== 1	then	return							end
	if	CheckWindowOpen(UIWarehouse)		== 1	then	return							end
	if	CheckWindowOpen(UIChaosBox)			== 1	then	return							end
	if	CheckWindowOpen(UICommandWindow)	== 1	then	return							end
	if	CheckWindowOpen(UIPetInfo)			== 1	then	return							end
	if	CheckWindowOpen(UIShop)				== 1	then	return							end
	if	CheckWindowOpen(UIStore)			== 1	then	return							end
	if	CheckWindowOpen(UIOtherStore)		== 1	then	return							end
	if	CheckWindowOpen(UICharacter)		== 1	then	return							end
	if	CheckWindowOpen(UIOptions)			== 1	then	return							end
	if	CheckWindowOpen(UIHelp)				== 1	then	return							end
	if	CheckWindowOpen(UIFastDial)			== 1	then	return							end
	if	CheckWindowOpen(UISkillTree)		== 1	then	return							end
	if	CheckWindowOpen(UINPC_Titus)		== 1	then	return							end
	if	CheckWindowOpen(UICashShop)			== 1	then	return							end
	if	CheckWindowOpen(UIFullMap)			== 1	then	return							end
	if	CheckWindowOpen(UINPC_Dialog)		== 1	then	return							end
	if	CheckWindowOpen(UIGensInfo)			== 1	then	return							end
	if	CheckWindowOpen(UINPC_Julia)		== 1	then	return							end
	if	CheckWindowOpen(UIExpandInventory)	== 1	then	return							end
	if	CheckWindowOpen(UIExpandWarehouse)	== 1	then	return							end
	if	CheckWindowOpen(UIMuHelper)			== 1	then	return							end
	if	CheckWindowOpen(UIInventory)		== 1	then	return							end
	if	QuestSystem.CheckOpen()				== 1	then	return							end
	if	QuestSystemNpc.CheckOpen()		    == 1	then	return							end

	EnableAlphaTest(1)
	
	SetBlend(1)
		
	GLSwitchBlend(1)
	
	glColor3f(1.0, 1.0, 1.0)
	
	SetFontType(0)
	
	SetTextBg(0, 0, 0, 0)
	
	SetTextColor(150, 150, 150, 150)
	
	--RenderText3(533, 466, string.format('FPS : %02.f', getFPS()), 40, 30, 3)
    --RenderText3(533, 466, string.format('FPS: %02.f | PING: %d', getFPS(), getPing()), 40, 30, ALIGN_CENTER)	
	
	GLSwitch()
	glColor3f(1.0, 1.0, 1.0)
	
	DisableAlphaBlend()

--SetFontType(1)		
-- 	glColor3f(1.0, 1.0, 1.0)
--	SetTextBg(0, 0, 0, 200)
--	SetTextColor(255, 255, 0, 225)
--	RenderText3(11, 90, string.format("X: %d", MousePosX()))
--	RenderText3(11, 100, string.format("Y: %d", MousePosY()))
end

InterfaceController.MainProc(InterfaceInfos.Render)

return InterfaceInfos