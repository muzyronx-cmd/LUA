SALDO_SWITCH = 1
SALDO_PACKET = 0x099
SALDO_PACKET_OPEN = 'SALDO_OPEN'
Saldo = {}

local SALDO_MESSAGES = {}

SALDO_MESSAGES['Por'] = {
[1] = 'Cash:',
[2] = 'Golds:',
[3] = 'JCPoints:',
[4] = 'Horas Online:',
[5] = 'QuestPoint:',


}

SALDO_MESSAGES['Eng'] = {
[1] = 'Cash:',
[2] = 'Golds:',
[3] = 'JCPoints:',
[4] = 'Horas Online:',
[5] = 'QuestPoint:',

}

SALDO_MESSAGES['Spn'] = {
[1] = 'Cash:',
[2] = 'Golds:',
[3] = 'JCPoints:',
[4] = 'Horas Online:',
[5] = 'QuestPoint:',

}

function Saldo.Define()
   Saldo.Moeda = {   
    [1] = {Valor = 0},
    [2] = {Valor = 0},
    [3] = {Valor = 0},
    [4] = {Valor = 0},
    [5] = {Valor = 0},	
   }
   SaldoOpen = 1
end


local SaldoOpen = 0

--RENDER INTERFACE BOX--
function Saldo.Interface(x, y)
    if SaldoOpen == 0
	then
	SetUnlockInterfaces()
	else		
	SetLockInterfaces()

    EnableAlphaTest()

    glColor4f(1.0, 1.0, 1.0, 1.0)
	
    --local PosX = (312 / 2) - (256 / 2)
    --local PosY = 155

	
	EndDrawBar()
	
	
	local PosX = 225
    local PosY = 155
	--Render Texts
	Saldo.RenderText(PosX, PosY)
	
	DisableAlphaBlend()
    end
end

--TEXTS AND BUTTONS	
function Saldo.RenderText(x, y)

    local posY = 0.0
	
	EnableAlphaTest()
	
	
					--buttons renders
    RenderImage(590049, x + -27, y + -33 +  posY, 250, 220)
	RenderImage(590050, x + 70, y + 29  +   posY, 98, 12)
    RenderImage(590050, x + 70, y + 49  +   posY, 98, 12)
    RenderImage(590050, x + 70, y + 69  +   posY, 98, 12)
    RenderImage(590050, x + 70, y + 89 +    posY, 98, 12)
	
	
	--glColor4f(0.0, 0.0, 0.0, 0.7)
	
	GLSwitchBlend()	
	
	glColor3f(1.0, 1.0, 1.0)
	
	
	SetFontType(1)
	
	SetTextBg(0, 0, 0, 0)
	
	SetTextColor(255, 255, 255, 255)
	
RenderText3(x + 2, y + -15+ posY, string.format('SALDOS'), 200, 3)
	
	SetTextColor(255, 255, 255, 255)
	

    RenderText3(x + 65, y + 30 +  posY, SALDO_MESSAGES[GetLanguage()][1], 200, 7)
	RenderText3(x + 65, y + 50 +  posY, SALDO_MESSAGES[GetLanguage()][2], 200, 7)
	RenderText3(x + 65, y + 70 +  posY, SALDO_MESSAGES[GetLanguage()][3], 200, 7)
	RenderText3(x + 65, y + 90 + posY, SALDO_MESSAGES[GetLanguage()][4], 200, 7)

	
	RenderText3(x + 115, y + 31 + posY, string.format("%d",  Saldo.Moeda[1].Valor), 200, 7)
    RenderText3(x + 115, y + 51 + posY, string.format("%d",  Saldo.Moeda[2].Valor), 200, 7)
    RenderText3(x + 115, y + 71 + posY, string.format("%d",  Saldo.Moeda[3].Valor), 200, 7)
    RenderText3(x + 115, y + 91 + posY, string.format("%d", Saldo.Moeda[4].Valor), 200, 7)
	
    posY = posY + 15


	GLSwitch()
	glColor3f(1.0, 1.0, 1.0)
	
	DisableAlphaBlend()
end


--PACKET GS
function Saldo.Protocol(Packet, PacketName)
    if Packet == SALDO_PACKET then
        if PacketName == "UpdateSaldo" then
            Saldo.Moeda[1].Valor = GetDwordPacket(PacketName, -1)
            Saldo.Moeda[2].Valor = GetDwordPacket(PacketName, -1)
            Saldo.Moeda[3].Valor = GetDwordPacket(PacketName, -1)
            Saldo.Moeda[4].Valor = GetDwordPacket(PacketName, -1)
            ClearPacket(PacketName)
			SaldoOpen = 1
            return 1
        end
    end
end


function Saldo.ClosedOK()
    if SaldoOpen == 1
	then
	      	if MousePosX() >=  428 and MousePosY() >= 133 and MousePosX() <= 438 and MousePosY() <=142 + 5
	      then
			     SaldoOpen = 0
		         SetUnlockInterfaces()
	        end
			
	  end
	  
	  --local WindowWidth = GetWindowWidth()
	  --
      --m_PosX = 80 + 79
      --
      --if (WindowWidth == 800)
      --then
      --    m_PosX = 112 + 79
      --elseif (WindowWidth == 1024)
      --then
      --  m_PosX = 96 + 79
      --end
end

function Saldo.Open()
    if SaldoOpen == 1
    then
        return
    end

    local packetString = string.format("%s_%s", SALDO_PACKET_OPEN, UserGetName())
    CreatePacket(packetString, SALDO_PACKET)
    SendPacket(packetString)
    ClearPacket(packetString)
end


function Saldo.Close()
    SaldoOpen = 0
end

function Saldo.UpdateKeyEvent()
    if SaldoOpen == 0
    then
        return
    end
	
	
	--local WindowWidth = GetWindowWidth()
	--
    --m_PosX = 80 + 79
    --
    --if (WindowWidth == 800)
    --then
    --    m_PosX = 112 + 79
    --elseif (WindowWidth == 1024)
    --then
    --  m_PosX = 96 + 79
    --end

    if CheckPressedKey(Keys.Escape) == 1
    then
        Saldo.Close()
    end

    if CheckWindowOpen(UIInventory) 		    == 1
        or CheckWindowOpen(UIFriendList) 		== 1
        or CheckWindowOpen(UIMoveList)			== 1
        or CheckWindowOpen(UIParty) 			== 1
        or CheckWindowOpen(UIQuest) 			== 1
        or CheckWindowOpen(UIGuild) 			== 1
        or CheckWindowOpen(UITrade) 			== 1
        or CheckWindowOpen(UIWarehouse) 		== 1
        or CheckWindowOpen(UIChaosBox)			== 1
        or CheckWindowOpen(UICommandWindow) 	== 1
        or CheckWindowOpen(UIPetInfo)	 		== 1
        or CheckWindowOpen(UIShop)				== 1
        or CheckWindowOpen(UIStore) 			== 1
        or CheckWindowOpen(UIOtherStore) 		== 1
        or CheckWindowOpen(UICharacter) 		== 1
        or CheckWindowOpen(UIOptions) 			== 1
        or CheckWindowOpen(UIHelp)				== 1
        or CheckWindowOpen(UIFastDial)			== 1
        or CheckWindowOpen(UISkillTree) 		== 1
        or CheckWindowOpen(UINPC_Titus) 		== 1
        or CheckWindowOpen(UICashShop)			== 1
        or CheckWindowOpen(UIFullMap) 			== 1
        or CheckWindowOpen(UINPC_Dialog)		== 1
        or CheckWindowOpen(UIGensInfo)			== 1
        or CheckWindowOpen(UINPC_Julia)		    == 1
        or CheckWindowOpen(UIExpandInventory)	== 1
        or CheckWindowOpen(UIExpandWarehouse)	== 1
        or CheckWindowOpen(UIMuHelper)			== 1


    then
        Saldo.Close()
    end
end


function Saldo.Init()
    if SALDO_SWITCH ~= 1
    then
        return
    end
InterfaceController.MainProc(Saldo.Interface)
InterfaceController.InterfaceClickEvent(Saldo.ClosedOK)
InterfaceController.ClientProtocol(Saldo.Protocol)
InterfaceController.UpdateKey(Saldo.UpdateKeyEvent)
Saldo.Define()
end

Saldo.Init()

return Saldo