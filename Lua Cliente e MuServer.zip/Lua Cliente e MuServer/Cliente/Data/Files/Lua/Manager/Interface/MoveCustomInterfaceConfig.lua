moveCustomConfigMap = {
	{name = 'Lorencia', index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},
	{name = 'Noria',    index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},
	{name = 'Devias',   index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},

	{name = 'Dungeon',   index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},
	{name = 'Losttower', index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},
	{name = 'Atlans',  	 index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},

	{name = 'Tarkan', index = 7, IX = 208, IY = 219, alignText = {[0] = 208, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},
    {name = 'Icarus', index = 8, IX = 273, IY = 219, alignText = {[0] = 273, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 10, cdX = 17, cdY = 17, listMove = false},
    {name = 'Arena',  index = 9, IX = 338, IY = 219, alignText = {[0] = 338, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},  
	{name = 'Blood Arena', index = 10, IX = 208, IY = 250, alignText = {[0] = 208, [1] = 259}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 125, cdY = 125, listMove = true},
	{name = 'Especiais', index = 11, IX = 273, IY = 250, alignText = {[0] = 273, [1] = 259}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 125, cdY = 125, listMove = true},	
}


moveCustomConfigMoves = {}
moveCustomConfigMoves['Lorencia'] = {
    {title = 'Bar',        index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 124, cdY = 128},
	{title = 'Mago',       index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 145, cdY = 112},
	{title = 'Ferreiro',   index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 138, cdY = 146},

	{title = 'Lorencia 2', index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 76,  cdY = 155},
	{title = 'Lorencia 4', index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 161, cdY = 176},
	{title = 'Cemitério',  index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 140, cdY = 225},

    {title = 'Baú de Baixo', index = 7, IX = 208, IY = 219, alignText = {[0] = 208, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 148, cdY = 111},
    {title = 'Baú de Cima',  index = 8, IX = 273, IY = 219, alignText = {[0] = 273, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 147, cdY = 143},
    {title = 'Centro',       index = 9, IX = 338, IY = 219, alignText = {[0] = 338, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 0, cdX = 145, cdY = 127},	
}

moveCustomConfigMoves['Noria'] = {
    {title = 'Noria',         index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 174, cdY = 116},
    {title = 'Noria 2',       index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 15,  cdY = 15},
    {title = 'Noria 3',       index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 235, cdY = 135},

    {title = 'Baú',           index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 172, cdY = 98},
    {title = 'NpcMr',         index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 193, cdY = 114},
    {title = 'Chaos Machine', index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 184, cdY = 102},
}


moveCustomConfigMoves['Devias'] = {
    {title = 'Devias',       index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 207, cdY = 38},
    {title = 'Igreja',       index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 209, cdY = 25},
    {title = 'Guild Master', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 216, cdY = 45},

    {title = 'Devias 2',     index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 24,  cdY = 26},
    {title = 'Devias 3',     index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 226, cdY = 231},
    {title = 'Devias 4',     index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 71,  cdY = 181},

    {title = 'Guardian',     index = 7, IX = 208, IY = 219, alignText = {[0] = 208, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 210, cdY = 55},
}

moveCustomConfigMoves['Dungeon'] = {
    {title = 'Dungeon',   index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 1, cdX = 108, cdY = 244},
    {title = 'Dungeon 2', index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 1, cdX = 50,  cdY = 205},
    {title = 'Dungeon 3', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 1, cdX = 215, cdY = 225},

    {title = 'Dungeon 4', index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 1, cdX = 100, cdY = 50},
}

moveCustomConfigMoves['Losttower'] = {
    {title = 'Losttower', index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 4, cdX = 206, cdY = 78},
    {title = 'Losttower 2', index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 4, cdX = 240, cdY = 240},
	{title = 'Losttower 3', index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 4, cdX = 86,  cdY = 167},
	{title = 'Losttower 4', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 4, cdX = 90,  cdY = 90},

    {title = 'Losttower 5', index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 4, cdX = 128, cdY = 53},
	{title = 'Losttower 6', index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 4, cdX = 55,  cdY = 55},
	{title = 'Losttower 7', index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 4, cdX = 08,  cdY = 86},
}

moveCustomConfigMoves['Atlans'] = {
    {title = 'Atlans', index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 7, cdX = 22,  cdY = 17},
	{title = 'Atlans 2', index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 7, cdX = 226, cdY = 53},
	{title = 'Atlans 3', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 7, cdX = 63, cdY = 163},
}

moveCustomConfigMoves['Tarkan'] = {
    {title = 'Tarkan',   index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 8, cdX = 191, cdY = 67},
    {title = 'Tarkan 2', index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 8, cdX = 30,  cdY = 225},
    {title = 'Tarkan 3', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 8, cdX = 50,  cdY = 160},
    {title = 'Tarkan 4', index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 8, cdX = 95,  cdY = 35},
    {title = 'Tarkan 5', index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 8, cdX = 160, cdY = 125},
}

moveCustomConfigMoves['Arena'] = {
    {title = 'Arena 1', index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 55, cdY = 80},
	{title = 'Arena 2', index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 38, cdY = 44},
	{title = 'Arena 3', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 38, cdY = 66},

    {title = 'Arena 4', index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 38, cdY = 84},
	{title = 'Arena 5', index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 20, cdY = 83},
	{title = 'Arena 6', index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 20, cdY = 65},
	
    {title = 'Portao', index = 7, IX = 208, IY = 219, alignText = {[0] = 208, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 63, cdY = 119},
    {title = 'Arena 7', index = 8, IX = 273, IY = 219, alignText = {[0] = 273, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 20, cdY = 47},
    {title = 'Arena 8', index = 9, IX = 338, IY = 219, alignText = {[0] = 338, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 40, cdY = 10},

}

moveCustomConfigMoves['Blood Arena'] = {
    {title = 'B Arena 1', index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 55, cdY = 80},
	{title = 'B Arena 2', index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 38, cdY = 44},
	{title = 'B Arena 3', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 38, cdY = 66},

    {title = 'B Arena 4', index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 38, cdY = 84},
	{title = 'B Arena 5', index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 20, cdY = 83},
	{title = 'B Arena 6', index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 20, cdY = 65},
	
    {title = 'B Portao', index = 7, IX = 208, IY = 219, alignText = {[0] = 208, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 63, cdY = 119},
    {title = 'B Arena 7', index = 8, IX = 273, IY = 219, alignText = {[0] = 273, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 20, cdY = 47},
    {title = 'B Arena 8', index = 9, IX = 338, IY = 219, alignText = {[0] = 338, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 84, cdX = 40, cdY = 10},

}
moveCustomConfigMoves['Especiais'] = {
    {title = 'NpcPk [Arena]', index = 1, IX = 208, IY = 157, alignText = {[0] = 208, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 6, cdX = 57, cdY = 166},
    {title = 'NpcMr [Noria]', index = 2, IX = 273, IY = 157, alignText = {[0] = 273, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 193, cdY = 114},
    {title = 'Chaos Machine', index = 3, IX = 338, IY = 157, alignText = {[0] = 338, [1] = 165}, wdth = 60, heigth = 25, mapNumber = 3, cdX = 184, cdY = 102},
    {title = 'Guild Master', index = 4, IX = 208, IY = 188, alignText = {[0] = 208, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 216, cdY = 45},
    {title = 'Guardião de Brindes', index = 5, IX = 273, IY = 188, alignText = {[0] = 273, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 210,  cdY = 55},
    {title = 'Igreja', index = 6, IX = 338, IY = 188, alignText = {[0] = 338, [1] = 197}, wdth = 60, heigth = 25, mapNumber = 2, cdX = 209, cdY = 25},
    {title = 'Arena Dragon', index = 7, IX = 208, IY = 219, alignText = {[0] = 208, [1] = 228}, wdth = 60, heigth = 25, mapNumber = 85, cdX = 50, cdY = 77},
}