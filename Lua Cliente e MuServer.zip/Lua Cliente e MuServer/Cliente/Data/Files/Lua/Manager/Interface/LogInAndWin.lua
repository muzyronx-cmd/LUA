--[[
Configs
]]--

LOG_IN_AND_WIN_SWITCH = 0

--Days player will get reward, obs: min is 5 days!
--don't have limit max of days you can put every number
LOG_IN_AND_WIN_MAX_DAYS = 31

--packet number
LOG_IN_AND_WIN_PACKET = 2
--packet name
LOG_IN_AND_WIN_PACKET_NAME = 'GET_REWARD_LOG_IN'

LOG_IN_AND_WIN_REWARD_BY_DAYS = { }

LOG_IN_AND_WIN_REWARD_BY_DAYS[1] =    { Day = 1,   RewardName = '[1]Reward Lovers Box',        Quantity = 1,        RewardGet =      '[1]Reward Lovers Box'  }  
LOG_IN_AND_WIN_REWARD_BY_DAYS[2] =    { Day = 2,   RewardName = '[2] Reward Lovers Box',       Quantity = 2,        RewardGet =      '[2] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[3] =    { Day = 3,   RewardName = '[3] Reward Lovers Box',       Quantity = 3,        RewardGet =      '[3] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[4] =    { Day = 4,   RewardName = '[4] Reward Lovers Box',       Quantity = 4,        RewardGet =      '[4] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[5] =    { Day = 5,   RewardName = '[5] Reward Lovers Box',       Quantity = 5,        RewardGet =      '[5] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[6] =    { Day = 6,   RewardName = '[6] Reward Lovers Box',       Quantity = 6,        RewardGet =      '[6] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[7] =    { Day = 7,   RewardName = '[7] Reward Lovers Box',       Quantity = 7,        RewardGet =      '[7] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[8] =    { Day = 8,   RewardName = '[8] Reward Lovers Box',       Quantity = 8,        RewardGet =      '[8] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[9] =    { Day = 9,   RewardName = '[9] Reward Lovers Box',       Quantity = 9,        RewardGet =      '[9] Reward Lovers Box' } 
LOG_IN_AND_WIN_REWARD_BY_DAYS[10] =   { Day = 10,  RewardName = '[10] Reward Lovers Box',      Quantity = 10,       RewardGet =      '[10] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[11] =   { Day = 11,  RewardName = '[11] Reward Lovers Box',      Quantity = 11,       RewardGet =      '[11] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[12] =   { Day = 12,  RewardName = '[12] Reward Lovers Box',      Quantity = 12,       RewardGet =      '[12] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[13] =   { Day = 13,  RewardName = '[13] Reward Lovers Box',      Quantity = 13,       RewardGet =      '[13] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[14] =   { Day = 14,  RewardName = '[14] Reward Lovers Box',      Quantity = 14,       RewardGet =      '[14] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[15] =   { Day = 15,  RewardName = '[15] Reward Lovers Box',      Quantity = 15,       RewardGet =      '[15] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[16] =   { Day = 16,  RewardName = '[16] Reward Lovers Box',      Quantity = 16,       RewardGet =      '[16] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[17] =   { Day = 17,  RewardName = '[17] Reward Lovers Box',      Quantity = 17,       RewardGet =      '[17] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[18] =   { Day = 18,  RewardName = '[18] Reward Lovers Box',      Quantity = 18,       RewardGet =      '[18] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[19] =   { Day = 19,  RewardName = '[19] Reward Lovers Box',      Quantity = 19,       RewardGet =      '[19] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[20] =   { Day = 20,  RewardName = '[20] Reward Lovers Box',      Quantity = 20,       RewardGet =      '[20] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[21] =   { Day = 21,  RewardName = '[21] Reward Lovers Box',      Quantity = 21,       RewardGet =      '[21] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[22] =   { Day = 22,  RewardName = '[22] Reward Lovers Box',      Quantity = 22,       RewardGet =      '[22] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[23] =   { Day = 23,  RewardName = '[23] Reward Lovers Box',      Quantity = 23,       RewardGet =      '[23] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[24] =   { Day = 24,  RewardName = '[24] Reward Lovers Box',      Quantity = 24,       RewardGet =      '[24] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[25] =   { Day = 25,  RewardName = '[25] Reward Lovers Box',      Quantity = 25,       RewardGet =      '[25] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[26] =   { Day = 26,  RewardName = '[26] Reward Lovers Box',      Quantity = 26,       RewardGet =      '[26] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[27] =   { Day = 27,  RewardName = '[27] Reward Lovers Box',      Quantity = 27,       RewardGet =      '[27] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[28] =   { Day = 28,  RewardName = '[28] Reward Lovers Box',      Quantity = 28,       RewardGet =      '[28] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[29] =   { Day = 29,  RewardName = '[29] Reward Lovers Box',      Quantity = 29,       RewardGet =      '[29] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[30] =   { Day = 30,  RewardName = '[30] Reward Lovers Box',      Quantity = 30,       RewardGet =      '[30] Reward Lovers Box'}
LOG_IN_AND_WIN_REWARD_BY_DAYS[31] =   { Day = 31,  RewardName = '[31] Reward Lovers Box',      Quantity = 31,       RewardGet =      '[31] Reward Lovers Box'}

LOG_IN_AND_WIN_MESSAGES = {}

LOG_IN_AND_WIN_MESSAGES['Por'] = {
[1] = 'Logue e Ganhe',
[2] = 'Dia %d',
[3] = 'SUPER BRINDE',
[4] = 'PARABÉNS',
[5] = 'SUA RECOMPENSA DE HOJE É:',
[6] = 'Jogue e Ganhe Recompensas Diárias!',
[10] = 'RESGATAR',
}

LOG_IN_AND_WIN_MESSAGES['Eng'] = {
[1] = 'Log in and Win',
[2] = 'Day %d',
[3] = 'SUPER TOAST',
[4] = 'CONGRATULATIONS',
[5] = 'YOUR REWARD FOR TODAY IS:',
[6] = 'Play HopeMu every day and win free gifts!',
[10] = 'RESGATAR',
}

LOG_IN_AND_WIN_MESSAGES['Spn'] = {
[1] = 'Iniciar sesión y ganar',
[2] = 'Día %d',
[3] = 'SUPER TOSTADA',
[4] = 'FELICIDADES',
[5] = 'TU RECOMPENSA POR HOY ES:',
[6] = '¡Juega a HopeMu todos los días y gana regalos gratis!',
[10] = 'RESGATAR',
}


--[[
System, if you don't know how this work, don't touch!
]]--
LogInAndWin = {}

LogInAndWinVisible = 0
LogInAndWinHide = 0
LogInAndWinDayPlayer = 0

local InterfaceIndex_1 = -1
local InterfaceIndex_2 = -1
local InterfaceIndex_3 = -1
local InterfaceIndex_4 = -1
local InterfaceIndex_5 = -1
local InterfaceIndex_6 = -1
local InterfaceIndex_7 = -1
local InterfaceIndex_8 = -1

function LogInAndWin.GetScaleImage(x)
	local resolution = GetResolution()
	
	if resolution == 4 or resolution == 5 or resolution == 7
	then
		return math.floor(((x * 85) / 100))
	elseif resolution == 6 or resolution == 8
	then
		return math.floor(((x * 80) / 100))
	end
	
	return x
end

function LogInAndWin.GetScalePosX(x)
	local resolution = GetResolution()
	
	if resolution == 4 or resolution == 5 or resolution == 7
	then
		return x + math.floor(((x * 15) / 100))
	elseif resolution == 6 or resolution == 8
	then
		return x + math.floor(((x * 20) / 100))
	end
	
	return x
end

function LogInAndWin.GetScaleFontX(x)
	local resolution = GetResolution()
	
	if resolution == 4 or resolution == 5 or resolution == 7
	then
		return x - math.floor(((x * 28) / 100))
	elseif resolution == 6 or resolution == 8
	then
		return x - math.floor(((x * 37) / 100))
	end
	
	return x
end

function LogInAndWin.ImagesOn(x)
	local resolution = GetResolution()
	
	if resolution == 4 or resolution == 5 or resolution == 7
	then
		return x - math.floor(((x * 15) / 100))
	elseif resolution == 6 or resolution == 8
	then
		return x - math.floor(((x * 20) / 100))
	end
	
	return x
end

function LogInAndWin.GetScaleMouseX(x)
	local resolution = GetResolution()
	
	if resolution == 4 or resolution == 5 or resolution == 7
	then
		return math.floor(((x * 90) / 100))
	elseif resolution == 6 or resolution == 8
	then
		return math.floor(((x * 87) / 100))
	end
	
	return x
end

function LogInAndWin.CheckAnotherInterfaceOpen()
	if CheckWindowOpen(UIMuHelper) ~= 0 
		or CheckWindowOpen(UIExpandWarehouse) ~= 0 
		or CheckWindowOpen(UIExpandInventory) ~= 0 
		or CheckWindowOpen(UIChaosBox) ~= 0 
		or CheckWindowOpen(UITrade) ~= 0 
		or CheckWindowOpen(UIQuest) ~= 0 
		or CheckWindowOpen(UICashShop) ~= 0 
		or CheckWindowOpen(UIOptions) ~= 0 
	then
		return 1
	end
	
	return 0
end

function LogInAndWin.GetReward()
	local packetIdentification = string.format('%s-%s', LOG_IN_AND_WIN_PACKET_NAME, UserGetName())
	
	CreatePacket(packetIdentification, LOG_IN_AND_WIN_PACKET)
	
	SetWordPacket(packetIdentification, LogInAndWinDayPlayer)
	
	SendPacket(packetIdentification)
	
	ClearPacket(packetIdentification)
end

function LogInAndWin.UpdateMouse()
	if LogInAndWinVisible == 0 or LogInAndWinHide == 1
	then
		return
	end
	
	if LogInAndWin.CheckAnotherInterfaceOpen() ~= 0 
	then
		return
	end
	
	local posX = LogInAndWin.GetScalePosX(math.floor((640 / 2) - 180))
	local posY = 80
	
	if (MousePosX() >= posX + LogInAndWin.GetScaleImage(150) and MousePosX() <= posX + LogInAndWin.GetScaleImage(150) + 50)
	and (MousePosY() >= posY + 245 and MousePosY() <= posY + 245 + 30)
	then
		if (CheckClickClient() == 1)
		then
			LogInAndWin.GetReward()
			LogInAndWinVisible = 0
			DisableClickClient()
		end
	end

	if (MousePosX() >= posX and MousePosX() <= LogInAndWin.GetScaleMouseX(posX + 360))
		and (MousePosY() >= posY + 80 and MousePosY() <= posY + 250)
	then
		DisableClickClient()
	end
end

function LogInAndWin.UpdateKeyEvent()
	if LogInAndWinVisible == 0
	then
		return
	end
	
	if (CheckPressedKey(Keys.Escape) == 1)
	then
		LogInAndWinHide = 0
		LogInAndWinVisible = 0
	end
end

function LogInAndWin.Render()
	if LogInAndWinVisible == 0 or LogInAndWinHide == 1
	then
		return
	end
	
	if LogInAndWin.CheckAnotherInterfaceOpen() ~= 0 
	then
		return
	end
	
	EnableAlphaTest()
	
	--local posX = LogInAndWin.GetScalePosX(math.floor((640 / 2) - 180))
	--local posY = 80
	
	--RenderImage2(InterfaceIndex_1, posX, posY, LogInAndWin.GetScaleImage(520), 380, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
	
	RenderImage(31344, posX, posY, LogInAndWin.GetScaleImage(381), 555, 0.028000, 0.002000, 0.837000, 0.889000, 1, 1, 1.0)
	
	StartPosImg = posX + 20
	
	ImgPos = 0
	
	local StartPosition = 1
	local EndPosition = 5
	
	if (LogInAndWinDayPlayer) >= LOG_IN_AND_WIN_MAX_DAYS
	then
		StartPosition = LOG_IN_AND_WIN_MAX_DAYS - 5
		EndPosition = LOG_IN_AND_WIN_MAX_DAYS - 1
	elseif LogInAndWinDayPlayer > EndPosition
	then
		local dif = LogInAndWinDayPlayer - EndPosition
		StartPosition = StartPosition + dif
		EndPosition = EndPosition + dif
		
		
		--make the day always print before the previous day if it is greater than 5
		local difEnd = LOG_IN_AND_WIN_MAX_DAYS - EndPosition
		
		if difEnd > 1
		then
			StartPosition = StartPosition + 1
			EndPosition = EndPosition + 1
		end
	else
		if LOG_IN_AND_WIN_MAX_DAYS > 5 and LogInAndWinDayPlayer > 3
		then
			local difEnd = LOG_IN_AND_WIN_MAX_DAYS - EndPosition
			
			if difEnd > 1
			then
				StartPosition = StartPosition + 1
				EndPosition = EndPosition + 1
			end
		end
	end
	
	for i = StartPosition, EndPosition do
		local ImageWidth = LogInAndWin.GetScaleImage(72)
		
		if LogInAndWinDayPlayer == i
		then
			if ImgPos == 0
			then
				RenderImage2(InterfaceIndex_4, StartPosImg, posY + 115, ImageWidth, 62, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
			else
				RenderImage2(InterfaceIndex_5, StartPosImg, posY + 115, ImageWidth, 62, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
			end
		else
			if ImgPos == 0
			then
				RenderImage2(InterfaceIndex_6, StartPosImg, posY + 115, ImageWidth, 62, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
			else
				RenderImage2(InterfaceIndex_2, StartPosImg, posY + 115, ImageWidth, 62, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
			end
		end
		
		SetFontType(2)
	
		SetTextColor(255, 255, 255, 255)
		
		SetTextBg(0, 0, 0, 0)
		
		RenderText3(StartPosImg + 10, posY + 90, string.format('%d', LOG_IN_AND_WIN_REWARD_BY_DAYS[i].Quantity), 30, 3)
		
		if LogInAndWinDayPlayer == i
		then
			SetTextColor(178, 34, 34, 255)
		else
			SetTextColor(255,255,255, 255)
		end
		
		SetFontType(0)
		
		RenderText3(StartPosImg + 10, posY + 112, string.format('%s', LOG_IN_AND_WIN_REWARD_BY_DAYS[i].RewardName), 30, 3)
		
		SetTextColor(255, 255, 255, 255)
		
		RenderText3(StartPosImg + 11, posY + 135, string.format(LOG_IN_AND_WIN_MESSAGES[GetLanguage()][2], i), 0, 0)
		RenderText3(posX + LogInAndWin.GetScaleFontX(110), posY + 242, LOG_IN_AND_WIN_MESSAGES[GetLanguage()][10], 160, 3)
		
		StartPosImg = StartPosImg + LogInAndWin.ImagesOn(48)
		
		ImgPos = ImgPos + 1
	end
	
	--Finally Brind
	SetFontType(1)
	
	SetTextColor(255, 215, 0, 255)
	
	SetTextBg(0, 0, 0, 0)
	
	RenderText3(StartPosImg + 25, posY + 90, LOG_IN_AND_WIN_MESSAGES[GetLanguage()][3], 0, 0)
	
	RenderImage2(InterfaceIndex_3, StartPosImg + 15, posY + 180, LogInAndWin.GetScaleImage(72), 62, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
	
	SetFontType(2)
	
	SetTextColor(128,0,128, 255)
	
	SetTextBg(0, 0, 0, 0)
	
	RenderText3(StartPosImg + 13, posY + 96, string.format('%d', LOG_IN_AND_WIN_REWARD_BY_DAYS[LOG_IN_AND_WIN_MAX_DAYS].Quantity), LogInAndWin.GetScaleImage(72), 3)
	
	SetFontType(0)
	
	SetTextColor(255,20,147, 255)
	
	RenderText3(StartPosImg + 3, posY + 117, string.format('%s', LOG_IN_AND_WIN_REWARD_BY_DAYS[LOG_IN_AND_WIN_MAX_DAYS].RewardName), LogInAndWin.GetScaleImage(100), 3)
	
	SetFontType(1)
	
	SetTextColor(255, 215, 0, 255)
	
	RenderText3(StartPosImg, posY + 135, string.format(LOG_IN_AND_WIN_MESSAGES[GetLanguage()][2], LOG_IN_AND_WIN_MAX_DAYS), LogInAndWin.GetScaleImage(100), 3)
	
	--Print brind today
	SetFontType(2)
	
	SetTextColor(255, 215, 0, 255)
	
	SetTextBg(0, 0, 0, 0)
	
	RenderText3(posX + LogInAndWin.GetScaleImage(130), posY + 150, string.format(LOG_IN_AND_WIN_MESSAGES[GetLanguage()][4]), LogInAndWin.GetScaleImage(100), 3)
	
	SetFontType(1)
	
	SetTextColor(255, 255, 255, 255)
	
	RenderText3(posX + LogInAndWin.GetScaleImage(105), posY + 170, LOG_IN_AND_WIN_MESSAGES[GetLanguage()][5], LogInAndWin.GetScaleImage(150), 3)
	
	--separation
	RenderImage2(InterfaceIndex_8, posX + LogInAndWin.GetScaleImage(55), posY + 185, LogInAndWin.GetScaleImage(500), 30, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
	
	RenderImage2(InterfaceIndex_8, posX + LogInAndWin.GetScaleImage(55), posY + 210, LogInAndWin.GetScaleImage(500), 30, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
	
	--Text Get Reward
	SetFontType(2)
	
	SetTextColor(255, 255, 255, 255)
	
	local TextReward = string.format('%d %s', LOG_IN_AND_WIN_REWARD_BY_DAYS[LogInAndWinDayPlayer].Quantity, LOG_IN_AND_WIN_REWARD_BY_DAYS[LogInAndWinDayPlayer].RewardGet)
	
	RenderText3(posX + LogInAndWin.GetScaleImage(100), posY + 185, TextReward, LogInAndWin.GetScaleImage(170), 3)
	
	--Text play game every day
	SetFontType(1)
	
	SetTextColor(255, 215, 0, 255)
	
	local PlayGame = string.format(LOG_IN_AND_WIN_MESSAGES[GetLanguage()][6])
	
	RenderText3(posX + LogInAndWin.GetScaleImage(55), posY + 230, PlayGame, LogInAndWin.GetScaleImage(250), 3)
	
	--"ok button"
	RenderImage2(InterfaceIndex_7, posX + LogInAndWin.GetScaleImage(150), posY + 245, LogInAndWin.GetScaleImage(110), 32, 1.0, 1.0, 1.0, 1.0, 1, 1, 1.0)
	
	--Text
	SetFontType(2)
	
	SetTextColor(255, 215, 0, 255)
	
	SetTextBg(0, 0, 0, 0)
	
	RenderText3(posX + LogInAndWin.GetScaleFontX(110), posY + 40, LOG_IN_AND_WIN_MESSAGES[GetLanguage()][1], 150, 3)
	
	DisableAlphaBlend()
end

function LogInAndWin.Protocol(Packet, PacketName)
	if Packet == LOG_IN_AND_WIN_PACKET
	then
		local packetIdentification = string.format('%s-%s', LOG_IN_AND_WIN_PACKET_NAME, UserGetName())
		
		if PacketName == packetIdentification
		then
			LogInAndWinDayPlayer = GetWordPacket(packetIdentification, -1) + 1
			LogInAndWinVisible = 1
			LogInAndWinHide = 0
			
			ClearPacket(packetIdentification)
		end
	end
end

function LogInAndWin.LoadImages()
	InterfaceIndex_1 = LoadImageByDir("Interface///background_ogocx.tga")
end

function LogInAndWin.Init()
	if LOG_IN_AND_WIN_SWITCH == 0
	then
		return
	end
	
	InterfaceController.ClientProtocol(LogInAndWin.Protocol)
	InterfaceController.LoadImages(LogInAndWin.LoadImages)
	InterfaceController.MainProc(LogInAndWin.Render)
	InterfaceController.UpdateMouse(LogInAndWin.UpdateMouse)
	InterfaceController.UpdateKey(LogInAndWin.UpdateKeyEvent)
end

LogInAndWin.Init()

return LogInAndWin