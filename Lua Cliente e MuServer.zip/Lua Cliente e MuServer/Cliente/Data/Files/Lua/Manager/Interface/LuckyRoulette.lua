-- Somente apresentacao; precos, moedas, premios e sorteios vem do MuServer.
LuckyRouletteUI = {}
local U=LuckyRouletteUI
local S={Open=false,List={},Selected=1,Page=0,Browse=1,Token=0,Message='',Waiting=false}
local PACKET,IMAGE=218,620120
local gold,white,muted,green={230,193,119},{222,222,214},{148,147,133},{151,210,155}
local controls,icons,labels={},{},{}
local X,Y,W,H=80,54,480,356
local function inside(x,y,w,h) return MousePosX()>=x and MousePosX()<=x+w and MousePosY()>=y and MousePosY()<=y+h end
local function bar(x,y,w,h,c)
    EnableAlphaTest(); SetBlend(); glColor4f(unpack(c)); DrawBar(x,y,w,h); EndDrawBar()
    GLSwitchBlend(); GLSwitch(); glColor3f(1,1,1); DisableAlphaBlend()
end
local function text(x,y,s,w,c)
    EnableAlphaTest(); SetFontType(1); SetTextBg(0,0,0,0); SetTextColor(c[1],c[2],c[3],255)
    RenderText3(x,y,s,w,3); DisableAlphaBlend()
end
local function frame(x,y,w,h,selected)
    bar(x,y,w,h,selected and {.73,.56,.26,1} or {.34,.29,.20,1})
    bar(x+1,y+1,w-2,h-2,{.065,.07,.07,.96})
    bar(x+2,y+2,w-4,1,selected and {.87,.70,.38,1} or {.48,.41,.28,1})
end
local function symbol(x,y,w,h,label,c)
    -- Native font baselines vary by resolution; draw centered strokes instead.
    local width=label=='X' and 9 or 6
    local left,top=x+(w-width)/2,y+(h-9)/2
    for row=0,8 do
        if label=='X' then
            bar(left+row,top+row,1,1,c)
            if row~=4 then bar(left+8-row,top+row,1,1,c) end
        else
            local column=label=='<' and math.abs(row-4) or 4-math.abs(row-4)
            bar(left+column,top+row,2,1,c)
        end
    end
end
local function button(x,y,w,h,label,selected,disabled,action,subtitle)
    local icon=label=='<' or label=='>' or label=='X'
    local hover=not disabled and inside(x,y,w,h)
    frame(x,y,w,h,icon and hover or selected)
    if icon then
        local close=label=='X'
        local fill=hover and (close and {.34,.12,.08,1} or {.35,.25,.10,1}) or {.14,.12,.09,1}
        bar(x+2,y+2,w-4,h-4,fill)
        bar(x+3,y+3,w-6,1,hover and {.77,.60,.32,1} or {.40,.33,.21,1})
        bar(x+3,y+h-4,w-6,1,{.055,.045,.03,1})
        symbol(x,y+1,w,h,label,{0,0,0,.8})
        symbol(x,y,w,h,label,disabled and {.31,.29,.24,1} or hover and {1,.85,.52,1} or {.82,.67,.39,1})
    else
        if selected then
            bar(x+2,y+2,w-4,h-4,{.36,.26,.10,.8})
            bar(x+2,y+3,2,h-6,{.90,.71,.32,1})
        end
        if hover then bar(x+2,y+2,w-4,h-4,{.65,.50,.22,.25}) end
        text(x+4,y+(subtitle and 6 or (h-10)/2),label,w-8,disabled and muted or gold)
        if subtitle then text(x+4,y+20,subtitle,w-8,disabled and muted or white) end
    end
    if not disabled then controls[#controls+1]={X=x,Y=y,W=w,H=h,Action=action} end
end
local function itemName(x,y,name,w,c)
    -- Keep short names complete without shrinking the native font.
    if #name<=14 then text(x,y,name,w,c); return end
    local split
    for i=1,math.min(15,#name) do if name:sub(i,i)==' ' then split=i end end
    if not split then split=15 end
    text(x,y,name:sub(1,split-1),w,c)
    local rest=name:sub(split):gsub('^%s+','')
    text(x,y+10,#rest>15 and rest:sub(1,12)..'...' or rest,w,c)
end
local function send(action)
    local r=S.List[S.Selected]
    local n='LRQ-'..UserGetName(); CreatePacket(n,PACKET)
    SetBytePacket(n,action); SetDwordPacket(n,S.Token); SetBytePacket(n,r and r.ID or 0)
    SendPacket(n); ClearPacket(n)
end
local function request(action)
    if S.Waiting or S.Spin or (S.Uncertain and action~=4) then return end
    -- Set state before sending: response handlers may run immediately.
    S.Waiting=true; S.Sent=os.time(); S.Action=action; S.Recovering=false
    S.Message=action==4 and 'Conferindo resultado no servidor...' or 'Aguardando servidor...'
    send(action)
end
local function hide()
    S.Open=false; S.Spin=nil; S.Waiting=false; controls={}; icons={}; labels={}
    DisableClickClient(); SetUnlockInterfaces()
end
function U.Close()
    if not S.Open then return end
    send(0)
    hide()
end
local function readstr(n) return GetCharPacketLength(n,-1,GetBytePacket(n,-1)) end
local function readItem(n,name)
    return {Name=name,Item=GetWordPacket(n,-1),Level=GetBytePacket(n,-1),
        Durability=GetBytePacket(n,-1),Skill=GetBytePacket(n,-1),Luck=GetBytePacket(n,-1),
        Option=GetBytePacket(n,-1),Excellent=GetBytePacket(n,-1)}
end
function U.Protocol(id,n)
    if id~=PACKET then return false end
    if n~='LR-'..UserGetName() then ClearPacket(n); return true end
    local kind=GetBytePacket(n,-1)
    if kind==1 then
        S={Open=true,List={},Expected=GetBytePacket(n,-1),Selected=1,Page=0,Browse=1,Token=0,Message='Carregando...',Waiting=true,Sent=os.time(),ConfirmOpen=true,Heartbeat=os.time()}
        controls={}; SetLockInterfaces(); DisableClickClient()
    elseif kind==2 and S.Open then
        local r={ID=GetBytePacket(n,-1),Name=readstr(n),Currency=readstr(n),Price=GetDwordPacket(n,-1),Items={}}
        local count=GetBytePacket(n,-1)
        for i=1,count do r.Items[i]=readItem(n,readstr(n)) end
        S.List[#S.List+1]=r
    elseif kind==3 and S.Open then
        controls={}
        S.Token=GetDwordPacket(n,-1); S.Message=readstr(n)
        local result
        if GetBytePacket(n,-1)==1 then
            local roulette,prize=GetBytePacket(n,-1),GetBytePacket(n,-1)
            result=readItem(n,readstr(n)); result.Roulette=roulette; result.Prize=prize
        end
        S.Result=result
        if result then
            for i,r in ipairs(S.List) do if r.ID==result.Roulette then S.Selected=i; S.Page=math.floor((i-1)/4); S.Browse=result.Prize end end
            if S.Action==1 then S.Spin={Start=os.clock(),Duration=4,Target=result.Prize} end
        end
        S.Uncertain=GetBytePacket(n,-1)==1
        S.Waiting=false; S.Action=nil; S.Heartbeat=os.time()
    elseif kind==4 and S.Open then
        -- The server ended the NPC session; never leave actionable stale buttons.
        hide()
    end
    ClearPacket(n); return true
end
local function itemCard(x,y,w,h,item,artHeight,size,c)
    local equipment=item.Item<6656
    -- CreateItem W/H alone do not resize custom BMDs; its final argument is scale.
    local scale=equipment and math.min(.52,artHeight/110) or math.min(1,artHeight/25)
    icons[#icons+1]={X=x+w/2,Y=y+artHeight/2,Item=item,Size=size,Scale=scale}
    -- Draw this opaque caption AFTER all models, so custom bounds cannot hide names.
    labels[#labels+1]={X=x+2,Y=y+artHeight,W=w-4,H=h-artHeight-2,Item=item,Color=c}
end
local function pagination(x,y,page,count,size,change)
    if count<=size then return end
    if page>0 then button(x,y,24,18,'<',false,false,function() change(page-1) end) end
    text(x+26,y+4,tostring(page+1)..' / '..math.ceil(count/size),108,muted)
    if (page+1)*size<count then button(x+136,y,24,18,'>',false,false,function() change(page+1) end) end
end
local function updateConnection()
    local now=os.time()
    if S.Waiting then
        if now-(S.Sent or now)>8 and not S.Recovering then
            -- Read-only reconciliation: never resend a debit or an item delivery.
            S.Recovering=true; S.Sent=now; S.Message='Conferindo resultado no servidor...'; send(4)
        elseif S.Recovering and now-S.Sent>12 then
            S.Waiting=false; S.Uncertain=true; S.Message='Sem resposta. Clique em ATUALIZAR.'
        end
    elseif not S.Spin and now-(S.Heartbeat or now)>=20 then
        S.Heartbeat=now; send(3)
    end
end
function U.Render()
    if not S.Open then return end
    updateConnection()
    if not S.Open then return end
    controls={}; icons={}; labels={}
    local hovered
    local x,y,w,h=X,Y,W,H
    bar(x+3,y+4,w,h,{0,0,0,.5}); frame(x,y,w,h,true)
    EnableAlphaTest(); glColor4f(1,1,1,1); RenderImage2(IMAGE,x+3,y+3,w-6,h-6,0,0,1,1,1,1,1); DisableAlphaBlend()
    bar(x+3,y+3,w-6,h-6,{.035,.04,.045,.55})
    bar(x+3,y+3,w-6,34,{.055,.055,.055,.95})
    text(x,y+8,'ROLETA DA SORTE',w,gold)
    text(x,y+22,'Escolha. Gire. Conquiste.',w,muted)
    bar(x+12,y+37,w-24,1,{.49,.39,.21,1})
    button(x+w-27,y+8,19,19,'X',false,false,U.Close)

    -- Left: roulette selection only. Prizes are browsed in the central reel.
    text(x+12,y+47,'ESCOLHA SUA ROLETA',160,gold)
    for slot=1,4 do
        local i=S.Page*4+slot; local r=S.List[i]
        if r then button(x+12,y+62+(slot-1)*33,160,30,r.Name,i==S.Selected,S.Waiting or S.Spin~=nil,
            function() S.Selected=i; S.Browse=1 end,r.Price==0 and 'GRATUITA' or r.Price..' '..r.Currency..' / giro') end
    end
    pagination(x+12,y+197,S.Page,#S.List,4,function(page) S.Page=page end)
    bar(x+182,y+47,1,280,{.38,.31,.20,1})
    local r=S.List[S.Selected]
    if r then
        local rx=x+194
        frame(rx,y+47,274,270)
        text(rx+8,y+58,r.Name,258,gold)
        text(rx+8,y+76,r.Price==0 and 'Giro gratuito' or 'Valor do giro: '..r.Price..' '..r.Currency,258,white)
        bar(rx+16,y+96,242,1,{.36,.29,.17,1})
        local active=S.Spin
        local highlighted=((S.Browse or 1)-1)%#r.Items+1
        if active then
            local t=math.min(1,(os.clock()-active.Start)/active.Duration)
            local steps=5*#r.Items+active.Target-1
            highlighted=(math.floor(steps*(1-(1-t)^3)))%#r.Items+1
            if t>=1 then S.Browse=highlighted; S.Spin=nil; active=nil end
        end
        text(rx+8,y+106,active and 'SORTEANDO SEU PREMIO...' or 'PREMIOS DA ROLETA',258,muted)
        for slot=-1,1 do
            local i=(highlighted+slot-1)%#r.Items+1
            local xx=rx+12+(slot+1)*84
            local yy=y+(slot==0 and 127 or 132)
            frame(xx,yy,80,82,slot==0)
            if slot==0 then
                bar(xx+2,yy+2,76,78,{.39,.28,.10,.7})
                bar(xx+12,yy-3,56,2,{.84,.65,.30,1})
                bar(xx+12,yy+83,56,2,{.84,.65,.30,1})
            end
            itemCard(xx,yy,80,82,r.Items[i],55,slot==0 and 33 or 27,slot==0 and gold or white)
            if inside(xx,yy,80,82) then hovered=r.Items[i] end
        end
        if active then
            local progress=math.min(1,(os.clock()-active.Start)/active.Duration)
            bar(rx+22,y+222,230,2,{.16,.15,.12,1}); bar(rx+22,y+222,230*progress,2,{.72,.55,.25,1})
        elseif #r.Items>1 then
            local function browse(direction)
                if S.Waiting or S.Spin then return end
                S.Browse=(highlighted-1+direction)%#r.Items+1
            end
            button(rx+12,y+216,22,16,'<',false,S.Waiting,function() browse(-1) end)
            text(rx+38,y+220,'Item '..highlighted..' / '..#r.Items,198,muted)
            button(rx+240,y+216,22,16,'>',false,S.Waiting,function() browse(1) end)
        end
        local label=S.Uncertain and 'ATUALIZAR' or S.Spin and 'GIRANDO...' or S.Waiting and 'AGUARDE...' or S.Result and 'PREMIO DISPONIVEL' or 'GIRAR AGORA'
        button(rx+34,y+233,206,30,label,true,S.Waiting or S.Spin~=nil or (not S.Uncertain and (S.Result~=nil or #S.List~=S.Expected)),
            function() request(S.Uncertain and 4 or 1) end)
        if S.Result and not S.Spin then
            frame(rx+12,y+271,90,43,true)
            itemCard(rx+12,y+271,90,43,S.Result,22,20,green)
            if inside(rx+12,y+271,90,43) then hovered=S.Result end
            button(rx+112,y+281,150,27,'RESGATAR PREMIO',true,S.Waiting or S.Uncertain,function() request(2) end)
        else text(rx+8,y+287,'O premio aparecera aqui apos o giro.',258,muted) end
    end
    bar(x+190,y+330,w-202,1,{.36,.29,.17,1})
    text(x+190,y+338,hovered and (hovered.Name..' +'..hovered.Level) or S.Message,w-202,hovered and gold or white)
    for _,q in ipairs(icons) do
        local size=q.Size
        local yy=q.Y-size/2
        if q.Item.Item>=15 and q.Item.Item<2560 then yy=yy+17*q.Scale
        elseif q.Item.Item>=2560 and q.Item.Item<3072 then yy=yy+10*q.Scale end
        DisableAlphaBlend()
        CreateItem(q.X-size/2,yy,size,size,q.Item.Item,q.Item.Level,0,0,q.Scale)
        EndDrawBar()
    end
    for _,q in ipairs(labels) do
        bar(q.X,q.Y,q.W,q.H,{.055,.06,.06,1})
        bar(q.X,q.Y,q.W,1,{.34,.29,.20,1})
        itemName(q.X,q.Y+2,q.Item.Name,q.W,q.Color)
    end
    if hovered then
        ShowItemDescription(MousePosX()+100,MousePosY()+90,hovered.Item,hovered.Level,
            hovered.Skill,hovered.Luck,hovered.Option,hovered.Durability,hovered.Excellent,0)
    end
    if S.Flash and os.clock()<S.Flash then bar(x+12,y+37,w-24,1,{1,.8,.3,1}) end
    if S.ConfirmOpen and not S.Waiting and #S.List==S.Expected then S.ConfirmOpen=false; send(3) end
end
function U.UpdateMouse()
    if not S.Open then return end
    local click=CheckClickClient()==1
    -- Consume every mouse update, including held clicks and clicks outside the modal.
    -- Rendering occurs at a different stage and cannot stop world movement on its own.
    DisableClickClient()
    if not click then return end
    for _,c in ipairs(controls) do
        if inside(c.X,c.Y,c.W,c.H) then
            S.Flash=os.clock()+.15
            c.Action()
            -- No second callback can reuse controls from before this click/response.
            controls={}
            return
        end
    end
end
function U.Keys()
    if not S.Open then return end
    if CheckPressedKey(Keys.Escape)==1 then U.Close() end
end
local beforeRendered=false
function U.BeforeRender() beforeRendered=true; U.Render() end
function U.MainFallback()
    if not beforeRendered then U.Render() end
    beforeRendered=false
end
InterfaceController.BeforeMainProc(U.BeforeRender)
InterfaceController.MainProc(U.MainFallback)
InterfaceController.UpdateMouse(U.UpdateMouse)
InterfaceController.ClientProtocol(U.Protocol)
InterfaceController.UpdateKey(U.Keys)
InterfaceController.LoadImages(function() LoadImage('Custom\\Interface\\roulette_inventory.jpg',IMAGE) end)
return U
