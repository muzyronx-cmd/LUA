-- Acabamento inspirado na janela do personagem: pedra escura e bronze discreto.
InvasionNotifications = {}
local state = {Name = nil, Events = {}, Open = false, Selected = 1, Page = 0,
    LastPoll = nil, Received = nil, Toast = nil, ToastUntil = 0, Known = {}, ActiveCount = 0}

local function config() return INVASION_NOTIFICATIONS_CONFIG end

local function inside(x, y, w, h)
    return MousePosX() >= x and MousePosX() <= x + w
        and MousePosY() >= y and MousePosY() <= y + h
end

local function bar(x, y, w, h, color)
    EnableAlphaTest()
    SetBlend()
    glColor4f(unpack(color))
    DrawBar(x, y, w, h)
    EndDrawBar()
    GLSwitchBlend()
    GLSwitch()
    glColor3f(1, 1, 1)
    DisableAlphaBlend()
end

local function text(x, y, label, w, color, align)
    EnableAlphaTest()
    SetFontType(1)
    SetTextBg(0, 0, 0, 0)
    SetTextColor(color[1], color[2], color[3], 255)
    RenderText3(x, y, label, w, align or 3)
    DisableAlphaBlend()
end

local gold, white, green = {235, 204, 137}, {225, 220, 207}, {112, 224, 117}

local function frame(x, y, w, h, background)
    local border = config().Colors.Border
    bar(x, y, w, h, border)
    bar(x + 1, y + 1, w - 2, h - 2, background)
    -- Relevo claro em cima e sombra embaixo, como os botoes classicos.
    bar(x + 2, y + 2, w - 4, 1, config().Colors.BorderLight)
    bar(x + 2, y + h - 3, w - 4, 1, config().Colors.BorderShadow)
end

local function image(id, x, y, w, h)
    EnableAlphaTest()
    glColor4f(1, 1, 1, 1)
    RenderImage(id, x, y, w, h)
    glColor3f(1, 1, 1)
    DisableAlphaBlend()
end

local function button(x, y, w, h, label)
    local colors, theme = config().Colors, config().Window
    frame(x, y, w, h, colors.Background)
    if theme and theme.UseClientTextures then
        image(theme.BackgroundImage, x + 3, y + 3, w - 6, h - 6)
    end
    if inside(x, y, w, h) then bar(x + 2, y + 2, w - 4, h - 4, colors.Hover) end
    text(x + 2, y + math.floor((h - 10) / 2), label, w - 4, gold)
end

local function window(x, y, w, h)
    local colors, theme = config().Colors, config().Window
    frame(x, y, w, h, colors.Panel)
    if theme and theme.UseClientTextures then
        image(theme.BackgroundImage, x + 4, y + 4, w - 8, h - 8)
    else
        -- Alternativa sem textura, nas mesmas cores da janela.
        for i = 0, 11 do
            local step = i / 11
            local top = math.floor(i * (h - 6) / 12)
            local bottom = math.floor((i + 1) * (h - 6) / 12)
            bar(x + 3, y + 3 + top, w - 6, bottom - top,
                {colors.Panel[1] + 0.025 * (1 - step), colors.Panel[2] + 0.025 * (1 - step),
                    colors.Panel[3] + 0.02 * (1 - step), 1})
        end
        bar(x + 4, y + 4, w - 8, 22, colors.Background)
    end
    bar(x + 4, y + 4, w - 8, 22, {0.025, 0.025, 0.022, 0.55})
    -- Filetes duplos em bronze e cantos chanfrados como a janela do print.
    local light, shadow = colors.BorderLight, colors.BorderShadow
    bar(x + 3, y + 26, w - 6, 1, colors.Border)
    bar(x + 3, y + 27, w - 6, 1, shadow)
    bar(x + 3, y + h - 29, w - 6, 1, shadow)
    bar(x + 3, y + h - 28, w - 6, 1, colors.Border)
    bar(x + 3, y + 7, 1, h - 14, light)
    bar(x + w - 4, y + 7, 1, h - 14, light)
    bar(x + 7, y + 3, w - 14, 1, shadow)
    bar(x + 7, y + h - 4, w - 14, 1, light)
    for _, corner in ipairs({{x, y, 1, 1}, {x + w - 1, y, -1, 1},
        {x, y + h - 1, 1, -1}, {x + w - 1, y + h - 1, -1, -1}}) do
        local cx, cy, dx, dy = unpack(corner)
        for step = 0, 5 do
            bar(cx + dx * (step + 1), cy + dy * (6 - step), 1, 1, light)
        end
    end
end

function InvasionNotifications.Geometry()
    local c = config()
    local b, p = c.Button, c.Panel
    return {BX = math.floor((c.CanvasWidth - b.Width) / 2) + b.OffsetX,
        BY = b.Y, BW = b.Width, BH = b.Height,
        X = math.floor((c.CanvasWidth - p.Width) / 2) + b.OffsetX,
        Y = p.Y, W = p.Width, H = p.Height}
end

function InvasionNotifications.IsVisible()
    if not config() or not config().Enabled then return false end
    local name = UserGetName()
    if not name or name == "" then return false end
    if CheckWindowOpen(UIFullMap) == 1 or CheckWindowOpen(UICashShop) == 1
        or CheckWindowOpen(UIOptions) == 1 then return false end
    if Shop and Shop.IsOpen and Shop.IsOpen() then return false end
    return true
end

local function reset(name)
    state.Name, state.Events, state.Known = name, {}, {}
    state.Open, state.Selected, state.Page = false, 1, 0
    state.LastPoll, state.Received, state.Toast = nil, nil, nil
    state.ActiveCount = 0
end

function InvasionNotifications.Update()
    if not config() or not config().Enabled then return end
    local name = UserGetName()
    if name ~= state.Name then reset(name) end
    if not name or name == "" then return end
    local now = os.time()
    if state.Received and now - state.Received > config().StaleSeconds then
        state.Events, state.Known, state.Received, state.Toast = {}, {}, nil, nil
    end
    if not state.LastPoll or now - state.LastPoll >= config().PollSeconds then
        state.LastPoll = now
        local packet = "INVN2_GET-" .. name
        CreatePacket(packet, config().Packet)
        SendPacket(packet)
        ClearPacket(packet)
    end
end

local function readText(packet)
    local length = GetBytePacket(packet, -1)
    if length == 0 then return "" end
    return GetCharPacketLength(packet, -1, length)
end

function InvasionNotifications.Protocol(packet, packetName)
    local name = UserGetName()
    if not config() or not config().Enabled or not name or name == ""
        or packet ~= config().Packet or packetName ~= "INVN2_DATA-" .. name then return end
    local count = GetBytePacket(packetName, -1)
    local more = GetBytePacket(packetName, -1) == 1
    local activeCount = GetWordPacket(packetName, -1)
    if count > 8 then ClearPacket(packetName); return true end
    local events, known, names = {}, {}, {}
    local selected = state.Events[state.Selected]
    for i = 1, count do
        local event = {Id = GetDwordPacket(packetName, -1), Name = readText(packetName),
            Seconds = GetDwordPacket(packetName, -1), Monsters = {}}
        event.Active = GetBytePacket(packetName, -1) == 1
        local groups = GetBytePacket(packetName, -1)
        event.MoreGroups = GetBytePacket(packetName, -1) == 1
        if groups > 16 then ClearPacket(packetName); return true end
        for j = 1, groups do
            event.Monsters[j] = {Name = readText(packetName),
                Alive = GetWordPacket(packetName, -1), Total = GetWordPacket(packetName, -1)}
        end
        events[i] = event
        if event.Active then
            known[event.Id] = true
            if not state.Known[event.Id] then names[#names + 1] = event.Name end
        end
    end
    ClearPacket(packetName)
    local now = os.time()
    if #names > 0 then
        state.Toast = "Invasao ativa: " .. names[1]
        if #names > 1 then state.Toast = state.Toast .. " (+" .. (#names - 1) .. ")" end
        state.ToastUntil = now + config().ToastSeconds
    end
    state.Events, state.Known, state.Received, state.More = events, known, now, more
    state.ActiveCount = activeCount
    state.Selected = 1
    if selected then
        for i, event in ipairs(events) do
            if event.Id == selected.Id then state.Selected = i; break end
        end
    end
    if not selected or not events[state.Selected] or events[state.Selected].Id ~= selected.Id then
        state.Page = 0
    end
    local event = events[state.Selected]
    local pages = event and math.ceil(#event.Monsters / config().Panel.Rows) or 1
    state.Page = math.min(state.Page, math.max(0, pages - 1))
    return true
end

-- Lista de todas as invasoes (aparece quando a invasao selecionada ainda nao iniciou)
local LIST_HEADER_Y, LIST_FIRST_Y, LIST_ROW_H = 78, 92, 13

local function listRowY(g, i)
    return g.Y + LIST_FIRST_Y + (i - 1) * LIST_ROW_H
end

local function shortTime(seconds)
    local h, m = math.floor(seconds / 3600), math.floor(seconds / 60) % 60
    if h > 0 then return string.format("%dh %02dm", h, m) end
    if m > 0 then return string.format("%dm %02ds", m, seconds % 60) end
    return seconds .. "s"
end

local function clip(label, maximum)
    if #label > maximum then return label:sub(1, maximum - 2) .. ".." end
    return label
end

function InvasionNotifications.StartLabel(seconds)
    if seconds <= 0 then return "Aguardando inicio da invasao..." end
    local hours, minutes = math.floor(seconds / 3600), math.floor(seconds / 60) % 60
    if hours > 0 then
        local duration = hours .. (hours == 1 and " hora" or " horas")
        if minutes > 0 then duration = duration .. " e " .. minutes .. " min" end
        return (hours == 1 and minutes == 0 and "Falta " or "Faltam ") .. duration .. " para iniciar"
    end
    if minutes > 0 then
        return (minutes == 1 and "Falta 1 minuto" or "Faltam " .. minutes .. " minutos") .. " para iniciar"
    end
    return (seconds == 1 and "Falta 1 segundo" or "Faltam " .. seconds .. " segundos") .. " para iniciar"
end

function InvasionNotifications.Render()
    -- Consulta tambem no ciclo de desenho, sem depender somente de UpdateProc.
    -- O mesmo limitador por tempo evita duplicar pedidos quando ambos rodam.
    InvasionNotifications.Update()
    if not InvasionNotifications.IsVisible() then return end
    local g = InvasionNotifications.Geometry()
    local suffix = state.Received and tostring(state.ActiveCount) or "?"
    button(g.BX, g.BY, g.BW, g.BH, "Invasoes (" .. suffix .. ")")
    if not state.Open then
        if state.Toast and os.time() < state.ToastUntil then
            frame(g.X - 20, g.Y, g.W + 40, 26, config().Colors.Background)
            text(g.X - 16, g.Y + 8, state.Toast, g.W + 32, gold)
        end
        return
    end
    window(g.X, g.Y, g.W, g.H)
    text(g.X + 22, g.Y + 9, "INVASOES", g.W - 44, config().Colors.Title)
    button(g.X + g.W - 22, g.Y + 4, 18, 18, "X")
    local event = state.Events[state.Selected]
    if not event then
        text(g.X + 8, g.Y + 60, state.Received and "Nenhuma invasao agendada." or
            "Aguardando dados do servidor...", g.W - 16, white)
        return
    end
    button(g.X + 8, g.Y + 29, 18, 18, "<")
    button(g.X + g.W - 26, g.Y + 29, 18, 18, ">")
    text(g.X + 28, g.Y + 34, event.Name, g.W - 56, gold)
    local seconds = math.max(0, event.Seconds - math.max(0, os.time() - state.Received))
    local rows = config().Panel.Rows
    if not event.Active then
        text(g.X + 8, g.Y + 58, InvasionNotifications.StartLabel(seconds), g.W - 16, gold)
        text(g.X + 10, g.Y + LIST_HEADER_Y, "Invasao", g.W - 90, gold, 1)
        text(g.X + g.W - 76, g.Y + LIST_HEADER_Y, "Inicia em", 66, gold)
        local elapsed = math.max(0, os.time() - state.Received)
        for i, item in ipairs(state.Events) do
            local y = listRowY(g, i)
            if i == state.Selected then
                bar(g.X + 6, y - 2, g.W - 12, LIST_ROW_H, config().Colors.Hover)
            elseif inside(g.X + 6, y - 2, g.W - 12, LIST_ROW_H) then
                bar(g.X + 6, y - 2, g.W - 12, LIST_ROW_H, {0.14, 0.13, 0.10, 0.5})
            end
            text(g.X + 10, y, clip(item.Name, 22), g.W - 90, white, 1)
            if item.Active then
                text(g.X + g.W - 76, y, "ATIVA", 66, green)
            else
                text(g.X + g.W - 76, y, shortTime(math.max(0, item.Seconds - elapsed)), 66, gold)
            end
        end
    else
        text(g.X + 8, g.Y + 53, string.format("Ativa - Tempo restante: %02d:%02d", math.floor(seconds / 60), seconds % 60), g.W - 16, green)
        text(g.X + 10, g.Y + 73, "Monstros", g.W - 70, gold, 1)
        text(g.X + g.W - 65, g.Y + 73, "Vivos/Total", 55, gold)
        for row = 1, rows do
            local monster = event.Monsters[state.Page * rows + row]
            if not monster then break end
            local y = g.Y + 90 + (row - 1) * 13
            text(g.X + 10, y, monster.Name, g.W - 74, white, 1)
            text(g.X + g.W - 62, y, monster.Alive .. "/" .. monster.Total, 52,
                monster.Alive > 0 and green or {130, 125, 115})
        end
    end
    local pages = math.max(1, math.ceil(#event.Monsters / rows))
    button(g.X + 8, g.Y + g.H - 25, 22, 18, "<")
    button(g.X + g.W - 30, g.Y + g.H - 25, 22, 18, ">")
    text(g.X + 33, g.Y + g.H - 20,
        string.format("Invasao %d/%d%s - Pag. %d/%d%s", state.Selected, #state.Events,
            state.More and "+" or "", state.Page + 1, pages, event.MoreGroups and "+" or ""),
        g.W - 66, gold)
end

function InvasionNotifications.UpdateMouse()
    if not InvasionNotifications.IsVisible() then return end
    if CheckClickClient() ~= 1 then return end
    local g = InvasionNotifications.Geometry()
    if inside(g.BX, g.BY, g.BW, g.BH) then
        DisableClickClient()
        state.Open = not state.Open
        return
    end
    if not state.Open or not inside(g.X, g.Y, g.W, g.H) then return end
    DisableClickClient() -- Cliques no painel nao atravessam para o mundo.
    if inside(g.X + g.W - 22, g.Y + 4, 18, 18) then state.Open = false; return end
    local count = #state.Events
    if count == 0 then return end
    if inside(g.X + 8, g.Y + 29, 18, 18) then
        state.Selected, state.Page = (state.Selected - 2) % count + 1, 0
    elseif inside(g.X + g.W - 26, g.Y + 29, 18, 18) then
        state.Selected, state.Page = state.Selected % count + 1, 0
    else
        local current = state.Events[state.Selected]
        if current and not current.Active then
            for i = 1, #state.Events do
                if inside(g.X + 6, listRowY(g, i) - 2, g.W - 12, LIST_ROW_H) then
                    state.Selected, state.Page = i, 0
                    return
                end
            end
        end
        local pages = math.max(1, math.ceil(#state.Events[state.Selected].Monsters / config().Panel.Rows))
        if inside(g.X + 8, g.Y + g.H - 25, 22, 18) then
            state.Page = math.max(0, state.Page - 1)
        elseif inside(g.X + g.W - 30, g.Y + g.H - 25, 22, 18) then
            state.Page = math.min(pages - 1, state.Page + 1)
        end
    end
end

function InvasionNotifications.UpdateKey()
    if state.Open and InvasionNotifications.IsVisible() and CheckPressedKey(Keys.Escape) == 1 then
        state.Open = false
        DisableClickClient()
    end
end

function InvasionNotifications.LoadImages()
    local theme = config() and config().Window
    if theme and theme.UseClientTextures then
        LoadImage(theme.BackgroundFile, theme.BackgroundImage)
    end
end

InterfaceController.LoadImages(InvasionNotifications.LoadImages)
InterfaceController.MainProc(InvasionNotifications.Render)
InterfaceController.UpdateProc(InvasionNotifications.Update)
InterfaceController.UpdateMouse(InvasionNotifications.UpdateMouse)
InterfaceController.UpdateKey(InvasionNotifications.UpdateKey)
InterfaceController.ClientProtocol(InvasionNotifications.Protocol)
return InvasionNotifications
