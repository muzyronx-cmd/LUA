-- Intencionalmente vazio: toda a interface do bau agora esta em
-- Manager/Customs/System/WareHouse.lua (arquivo que o cliente realmente carrega).
-- Mantido para nao duplicar desenho/eventos caso este arquivo tambem seja carregado.
WharehouseInterface = WharehouseInterface or {}
return WharehouseInterface
